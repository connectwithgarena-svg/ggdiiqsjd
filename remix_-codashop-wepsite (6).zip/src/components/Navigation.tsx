import { PageRoute } from '../types';
import ggDiamondsLogo from '../assets/images/ggdiamonds.png';

interface NavigationProps {
  currentRoute: PageRoute;
  setRoute: (route: PageRoute) => void;
  loggedInUser: string | null;
  onOpenProfile: () => void;
  onOpenLoginModal: () => void;
}

export default function Navigation({ currentRoute: _currentRoute, setRoute, loggedInUser, onOpenProfile, onOpenLoginModal }: NavigationProps) {
  return (
    <header className="sticky top-0 z-50 w-full bg-white/95 backdrop-blur-md border-b border-gray-100 shadow-xs">
      <div className="max-w-4xl mx-auto px-3 sm:px-4 md:px-6 h-14 sm:h-16 flex items-center justify-between gap-2">
        {/* Brand Logo and Title */}
        <div 
          onClick={() => setRoute('home')} 
          className="flex items-center gap-2 sm:gap-3 cursor-pointer select-none min-w-0 group"
        >
          {/* Logo Container with perfect aspect ratio, high rendering clarity across screen densities */}
          <div className="relative flex items-center justify-center shrink-0 w-8 h-8 sm:w-9 sm:h-9 md:w-10 md:h-10 transition-transform duration-200 group-hover:scale-105">
            <img 
              src={ggDiamondsLogo} 
              alt="GGDIAMOND Logo" 
              loading="eager"
              decoding="async"
              className="w-full h-full object-contain drop-shadow-2xs select-none" 
            />
          </div>

          {/* Vertical Accent Divider */}
          <div className="w-[2px] h-4 sm:h-6 bg-amber-500 rounded-full shrink-0 opacity-90"></div>

          {/* Text Title with Adaptive Responsive Scaling */}
          <div className="flex flex-col justify-center min-w-0">
            <span className="text-gray-900 font-[900] text-xs sm:text-sm md:text-base tracking-tight truncate leading-none uppercase select-none">
              Diamond Top Up Center
            </span>
          </div>
        </div>

        {/* Right Action Area */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* User Logged In Profile Tag */}
          {loggedInUser ? (
            <button
              onClick={onOpenProfile}
              className="bg-red-50 hover:bg-red-100 transition-colors text-[#ee2c24] border border-red-200 px-2.5 sm:px-3.5 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5 shadow-2xs cursor-pointer max-w-[120px] sm:max-w-[200px]"
            >
              <span className="w-2 h-2 rounded-full bg-[#ee2c24] shrink-0 animate-pulse"></span>
              <span className="truncate leading-none">{loggedInUser}</span>
            </button>
          ) : (
            <button
              onClick={onOpenLoginModal}
              className="bg-[#ee2c24] hover:bg-red-600 active:scale-95 text-white px-3 sm:px-4 py-1.5 rounded-lg text-xs font-bold transition-all shadow-2xs cursor-pointer shrink-0"
            >
              Login
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
