import { motion } from 'motion/react';

export default function PageLoader() {
  return (
    <motion.div
      key="loader"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 9999,
        background: 'rgba(0,0,0,0.82)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '16px',
        pointerEvents: 'all',
      }}
    >
      {/* Bouncing Diamond */}
      <motion.div
        animate={{ y: [0, -18, 0] }}
        transition={{ duration: 0.7, repeat: Infinity, ease: 'easeInOut' }}
        style={{ fontSize: '48px', lineHeight: 1 }}
      >
        💎
      </motion.div>

      {/* Progress Bar */}
      <div style={{
        width: '160px',
        height: '4px',
        borderRadius: '999px',
        background: 'rgba(255,255,255,0.12)',
        overflow: 'hidden',
      }}>
        <motion.div
          animate={{ x: ['-100%', '100%'] }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
          style={{
            width: '60%',
            height: '100%',
            borderRadius: '999px',
            background: 'linear-gradient(90deg, #ee2c24, #ff6b35)',
          }}
        />
      </div>

      {/* Text */}
      <motion.p
        animate={{ opacity: [0.4, 1, 0.4] }}
        transition={{ duration: 1.4, repeat: Infinity, ease: 'easeInOut' }}
        style={{
          color: 'white',
          fontSize: '13px',
          fontWeight: 600,
          letterSpacing: '0.08em',
          margin: 0,
        }}
      >
        Loading...
      </motion.p>
    </motion.div>
  );
}
