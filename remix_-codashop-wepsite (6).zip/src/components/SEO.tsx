import { useEffect } from 'react';

interface SEOProps {
  title: string;
  description: string;
  keywords?: string;
  canonical?: string;
  schema?: Record<string, any>;
}

export default function SEO({ 
  title, 
  description, 
  keywords = "Free Fire diamond top-up, cheap FF MAX diamonds, instant delivery Free Fire diamonds, double diamond top-up, buy Free Fire diamonds online, Free Fire recharge, FF UID top-up India, Garena Free Fire topup, ggdiamond",
  canonical = 'https://www.ggdiamond.shop/', 
  schema 
}: SEOProps) {
  useEffect(() => {
    // 1. Update Document Title
    const formattedTitle = title.includes('ggdiamond.shop') 
      ? title 
      : `${title} | Free Fire Diamond Top-Up - ggdiamond.shop`;
    document.title = formattedTitle;

    // 2. Helper to set or create meta tags by attribute name/property
    const setMetaTag = (selector: string, attr: string, key: string, content: string) => {
      let tag = document.querySelector(selector);
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute(attr, key);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };

    // Update Meta Description
    setMetaTag('meta[name="description"]', 'name', 'description', description);

    // Update Meta Keywords
    setMetaTag('meta[name="keywords"]', 'name', 'keywords', keywords);

    // Update Open Graph tags
    setMetaTag('meta[property="og:title"]', 'property', 'og:title', formattedTitle);
    setMetaTag('meta[property="og:description"]', 'property', 'og:description', description);
    setMetaTag('meta[property="og:url"]', 'property', 'og:url', canonical);
    setMetaTag('meta[property="og:type"]', 'property', 'og:type', 'website');
    setMetaTag('meta[property="og:site_name"]', 'property', 'og:site_name', 'ggdiamond.shop');

    // Update Twitter Cards
    setMetaTag('meta[property="twitter:title"]', 'property', 'twitter:title', formattedTitle);
    setMetaTag('meta[property="twitter:description"]', 'property', 'twitter:description', description);
    setMetaTag('meta[property="twitter:url"]', 'property', 'twitter:url', canonical);
    setMetaTag('meta[property="twitter:card"]', 'property', 'twitter:card', 'summary_large_image');

    // 3. Update Canonical Link
    let canonicalLink = document.querySelector('link[rel="canonical"]');
    if (!canonicalLink) {
      canonicalLink = document.createElement('link');
      canonicalLink.setAttribute('rel', 'canonical');
      document.head.appendChild(canonicalLink);
    }
    canonicalLink.setAttribute('href', canonical);

    // 4. Inject Dynamic Route-Specific JSON-LD Schema
    const dynamicSchemaId = 'seo-dynamic-schema-jsonld';
    let schemaScript = document.getElementById(dynamicSchemaId) as HTMLScriptElement | null;
    if (schemaScript) {
      schemaScript.remove();
    }

    if (schema) {
      schemaScript = document.createElement('script');
      schemaScript.id = dynamicSchemaId;
      schemaScript.type = 'application/ld+json';
      schemaScript.text = JSON.stringify(schema);
      document.head.appendChild(schemaScript);
    }

    return () => {
      const existingScript = document.getElementById(dynamicSchemaId);
      if (existingScript) {
        existingScript.remove();
      }
    };
  }, [title, description, keywords, canonical, schema]);

  return null;
}
