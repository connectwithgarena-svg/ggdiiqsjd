import { PageRoute } from '../types';

interface FooterProps {
  setRoute: (route: PageRoute) => void;
  onOpenHelpCenter: () => void;
}

export default function Footer({ setRoute, onOpenHelpCenter }: FooterProps) {
  return (
    <footer className="w-full bg-white border-t border-gray-100 py-10 px-4 mt-auto">
      <div className="max-w-4xl mx-auto flex flex-col items-center gap-6">
        {/* Secure Trust Badge */}
        <div className="flex items-center gap-2 text-gray-400 text-xs font-semibold">
          <svg className="w-4 h-4 text-emerald-500" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
          </svg>
          GGDIAMOND Diamond Top Up Center
        </div>

        {/* Dynamic Navigation Links - Uses standard <a href> so search engine and policy crawlers can discover all routes */}
        <nav aria-label="Legal & Information Links" className="flex flex-wrap justify-center items-center gap-x-4 gap-y-2 text-xs sm:text-sm font-medium text-gray-500 max-w-xl text-center">
          <a 
            href="/"
            onClick={(e) => { e.preventDefault(); setRoute('home'); }} 
            className="hover:text-[#ee2c24] transition-colors cursor-pointer"
          >
            Home
          </a>
          <span className="text-gray-200">|</span>
          <a 
            href="/about"
            onClick={(e) => { e.preventDefault(); setRoute('about'); }} 
            className="hover:text-[#ee2c24] transition-colors cursor-pointer"
          >
            About Us
          </a>
          <span className="text-gray-200">|</span>
          <a 
            href="/faq"
            onClick={(e) => { e.preventDefault(); setRoute('faq'); }} 
            className="hover:text-[#ee2c24] transition-colors cursor-pointer"
          >
            FAQ
          </a>
          <span className="text-gray-200">|</span>
          <a 
            href="/contact"
            onClick={(e) => { e.preventDefault(); setRoute('contact'); }} 
            className="hover:text-[#ee2c24] transition-colors cursor-pointer"
          >
            Contact Us
          </a>
          <span className="text-gray-200">|</span>
          <a 
            href="/terms"
            onClick={(e) => { e.preventDefault(); setRoute('terms'); }} 
            className="hover:text-[#ee2c24] transition-colors cursor-pointer"
          >
            Terms &amp; Conditions
          </a>
          <span className="text-gray-200">|</span>
          <a 
            href="/privacy"
            onClick={(e) => { e.preventDefault(); setRoute('privacy'); }} 
            className="hover:text-[#ee2c24] transition-colors cursor-pointer"
          >
            Privacy Policy
          </a>
          <span className="text-gray-200">|</span>
          <a 
            href="/refund"
            onClick={(e) => { e.preventDefault(); setRoute('refund'); }} 
            className="hover:text-[#ee2c24] transition-colors cursor-pointer"
          >
            Refund Policy
          </a>
          <span className="text-gray-200">|</span>
          <a 
            href="/antifraud"
            onClick={(e) => { e.preventDefault(); setRoute('antifraud'); }} 
            className="hover:text-[#ee2c24] transition-colors cursor-pointer"
          >
            Anti-Fraud
          </a>
          <span className="text-gray-200">|</span>
          <a 
            href="/payment"
            onClick={(e) => { e.preventDefault(); setRoute('payment'); }} 
            className="hover:text-[#ee2c24] transition-colors cursor-pointer"
          >
            Payment Policy
          </a>
        </nav>

        {/* Footer legal text */}
        <div className="text-center text-xs text-gray-400 space-y-1.5">
          <p>© GGDIAMOND. All rights reserved.</p>
          <p>GG Diamond is an independent reseller. Not affiliated with, endorsed by or operated by Garena. Free Fire is a trademark of Garena.</p>
          <p className="text-[10px]">All transaction services are powered by secure global payment gateways. Double bonus rewards are limited to promotional periods only.</p>
        </div>
      </div>
    </footer>
  );
}
