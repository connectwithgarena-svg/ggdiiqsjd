import { motion, AnimatePresence } from 'motion/react';
import { X, Clock, ShieldCheck, Lock, Zap, CheckCircle } from 'lucide-react';
import popupImg from '../assets/images/popupimg.png';

interface WelcomePopupProps {
  isOpen: boolean;
  onClose: () => void;
  onClaim: () => void;
}

export default function WelcomePopup({ isOpen, onClose, onClaim }: WelcomePopupProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          {/* Backdrop blur overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />

          {/* Modal Card */}
          <motion.div
            initial={{ scale: 0.95, y: 10, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.95, y: 10, opacity: 0 }}
            transition={{ type: 'spring', damping: 30, stiffness: 350 }}
            className="relative w-full max-w-[350px] overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-2xl flex flex-col z-10"
          >
            {/* Close Button on top of image */}
            <button
              onClick={onClose}
              className="absolute top-3 right-3 z-50 rounded-full bg-black/40 hover:bg-black/60 p-1.5 text-white backdrop-blur-xs transition-all cursor-pointer"
              aria-label="Close"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Special Image / Banner Area - HERO */}
            <div className="relative w-full aspect-[4/3] bg-gray-50 overflow-hidden flex items-center justify-center border-b border-gray-100">
              <img
                src={popupImg}
                alt="Limited Offer Banner"
                loading="eager"
                decoding="async"
                fetchPriority="high"
                className="w-full h-full object-cover transition-transform duration-700 hover:scale-102"
                onError={(e) => {
                  (e.target as HTMLImageElement).style.display = 'none';
                }}
              />
              <div className="absolute inset-x-0 bottom-0 h-12 bg-gradient-to-t from-black/30 to-transparent" />
            </div>

            {/* Content box - streamlined & high class */}
            <div className="p-5 space-y-4">
              <div className="text-center space-y-2">
                <div className="inline-flex items-center gap-1 bg-amber-50 border border-amber-200/50 text-amber-800 text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                  <Clock className="w-3 h-3 text-amber-600" />
                  Limited-time Bonus
                </div>
                
                <h4 className="text-base font-black text-gray-900 tracking-tight leading-snug">
                  100% First-Time Bonus
                </h4>
                
                <p className="text-[11px] text-gray-500 font-semibold leading-relaxed px-1">
                  Get double Diamonds credited directly to your player profile in under 60 seconds using your UID.
                </p>
              </div>

              {/* Trust Badge Strip */}
              <div className="flex items-center justify-center gap-4 py-2 border-y border-gray-50 text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                  Verified
                </span>
                <span className="w-1 h-1 rounded-full bg-gray-200" />
                <span className="flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5 text-emerald-500" />
                  SSL Secure
                </span>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2">
                <button
                  onClick={onClaim}
                  className="w-full bg-[#ee2c24] hover:bg-red-600 active:scale-[0.98] text-white py-3 px-5 rounded-xl font-black text-xs uppercase tracking-wider shadow-md shadow-red-500/10 hover:shadow-red-500/25 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Zap className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />
                  Claim Double Bonus Now
                </button>
                <button
                  onClick={onClose}
                  className="w-full bg-transparent hover:bg-gray-50 text-gray-400 hover:text-gray-600 py-1.5 rounded-lg text-[11px] font-extrabold tracking-wide uppercase transition-colors cursor-pointer"
                >
                  Explore Regular Packs
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
