import { useState, useEffect } from 'react';
import { CheckCircle2, ThumbsUp, Star, PenTool, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export interface CustomerReviewItem {
  id: string;
  name: string;
  initial: string;
  rating: number;
  msg: string;
  packageText: string;
  packagePrice: string;
  likes: number;
  upiRef: string;
  verified: boolean;
}

const avatarColors = [
  "bg-emerald-500", "bg-rose-500", "bg-indigo-500", "bg-amber-500", 
  "bg-teal-500", "bg-sky-500", "bg-orange-500"
];

// Fallback pool in case network request fails
const DEFAULT_CLIENT_REVIEWS: CustomerReviewItem[] = [
  {
    id: "rev-101",
    name: "Aryan Sharma",
    initial: "A",
    rating: 5,
    msg: "Bhai 100% working hai, 2180 diamonds 2 minute ke andar ID me credit ho gaye. Payment UPI se smooth tha.",
    packageText: "1,090 + 1,090 Diamonds",
    packagePrice: "₹550",
    likes: 42,
    upiRef: "UPI-428190371822",
    verified: true
  },
  {
    id: "rev-102",
    name: "Rohan Varma",
    initial: "R",
    rating: 5,
    msg: "Double diamond bonus package sach me deliver hua. UID check karne ke baad turant receive hua. Trusted service.",
    packageText: "2,220 + 2,220 Diamonds (Offer)",
    packagePrice: "₹750",
    likes: 38,
    upiRef: "UPI-428190184912",
    verified: true
  },
  {
    id: "rev-103",
    name: "Faizan Khan",
    initial: "F",
    rating: 5,
    msg: "Instant top up service. Level 72 ID par safe recharge hua without any issue. Best pricing in India.",
    packageText: "4,210 + 4,210 Diamonds (Offer)",
    packagePrice: "₹1,100",
    likes: 29,
    upiRef: "UPI-428189920148",
    verified: true
  },
  {
    id: "rev-104",
    name: "Santhosh Kumar",
    initial: "S",
    rating: 5,
    msg: "Super fast topup. Got double diamond bonus directly in my Free Fire account. Support response was also quick.",
    packageText: "1,090 + 1,090 Diamonds",
    packagePrice: "₹550",
    likes: 24,
    upiRef: "UPI-428189745190",
    verified: true
  },
  {
    id: "rev-105",
    name: "Vikram Rathore",
    initial: "V",
    rating: 5,
    msg: "Pehle doubt tha but trial ke liye ₹550 wala package try kiya. Turant diamond add ho gaye. Thanks GGDIAMOND.",
    packageText: "1,090 + 1,090 Diamonds",
    packagePrice: "₹550",
    likes: 35,
    upiRef: "UPI-428189492104",
    verified: true
  },
  {
    id: "rev-106",
    name: "Rahul Meena",
    initial: "R",
    rating: 5,
    msg: "Genuine gaming recharge portal. Diamonds instantly reflect ho gaye game me. Recommended for all players.",
    packageText: "6,580 + 6,580 Diamonds (Offer)",
    packagePrice: "₹1,400",
    likes: 27,
    upiRef: "UPI-428189284193",
    verified: true
  },
  {
    id: "rev-107",
    name: "Aditya Patil",
    initial: "A",
    rating: 5,
    msg: "Topup completed in under 90 seconds. Bonus diamonds received properly on Player UID.",
    packageText: "2,220 + 2,220 Diamonds (Offer)",
    packagePrice: "₹750",
    likes: 19,
    upiRef: "UPI-428188941029",
    verified: true
  },
  {
    id: "rev-108",
    name: "Mohd Danish",
    initial: "M",
    rating: 5,
    msg: "Safe payment through Google Pay UPI. Diamonds credited without password or login sharing.",
    packageText: "1,090 + 1,090 Diamonds",
    packagePrice: "₹550",
    likes: 31,
    upiRef: "UPI-428188612984",
    verified: true
  }
];

// Strictly maintain ascending time order from Top (30s) down to Bottom (under 15m)
// Position 0 (Top): 30s - 45s ago
// Position 1: ~2m ago
// Position 2: ~6m ago
// Position 3 (Bottom): ~12m - 14m ago
const SLOT_TIME_LABELS = [
  "30s ago",
  "2m ago",
  "6m ago",
  "12m ago"
];

interface ReviewFeedProps {
  onWriteReview: () => void;
}

export default function ReviewFeed({ onWriteReview }: ReviewFeedProps) {
  const [allReviews, setAllReviews] = useState<CustomerReviewItem[]>(DEFAULT_CLIENT_REVIEWS);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [likedIds, setLikedIds] = useState<Record<string, boolean>>({});
  const [isPaused, setIsPaused] = useState(false);

  // Exactly 4 cards visible at any time so the page stays compact and strictly ordered
  const VISIBLE_COUNT = 4;

  // 1. Fetch real verified reviews from backend API
  useEffect(() => {
    fetch('/api/reviews')
      .then(res => res.ok ? res.json() : null)
      .then(data => {
        if (data && data.reviews && Array.isArray(data.reviews) && data.reviews.length > 0) {
          setAllReviews(data.reviews);
        }
      })
      .catch(() => {
        // fallback to default
      });
  }, []);

  // 2. Timely auto-rotation: shifts the feed every 10 seconds smoothly
  useEffect(() => {
    if (isPaused || allReviews.length <= VISIBLE_COUNT) return;

    const interval = setInterval(() => {
      setCurrentIndex(prev => (prev + 1) % allReviews.length);
    }, 10000); // 10 seconds rotation

    return () => clearInterval(interval);
  }, [isPaused, allReviews.length]);

  // Compute the 4 visible reviews, always attaching slot-based strictly ascending time
  const visibleReviews = [];
  for (let i = 0; i < Math.min(VISIBLE_COUNT, allReviews.length); i++) {
    const idx = (currentIndex + i) % allReviews.length;
    visibleReviews.push({
      ...allReviews[idx],
      timeAgo: SLOT_TIME_LABELS[i] || `${Math.min(14, (i + 1) * 3)}m ago`
    });
  }

  const handleLike = (id: string) => {
    if (likedIds[id]) return;
    setLikedIds(prev => ({ ...prev, [id]: true }));
    setAllReviews(prev => prev.map(r => r.id === id ? { ...r, likes: r.likes + 1 } : r));
  };

  const handleNext = () => {
    setCurrentIndex(prev => (prev + 1) % allReviews.length);
  };

  const handlePrev = () => {
    setCurrentIndex(prev => (prev - 1 + allReviews.length) % allReviews.length);
  };

  return (
    <div 
      className="w-full bg-white rounded-2xl p-4 sm:p-6 shadow-xs border border-gray-100 flex flex-col gap-4 sm:gap-5"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Header */}
      <div className="flex items-center justify-between gap-3 border-b border-dashed border-gray-100 pb-3">
        <div className="flex items-center gap-2">
          <span className="flex h-2.5 w-2.5 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          <span className="text-xs sm:text-sm font-black tracking-wider text-emerald-600 uppercase">
            LIVE ACTIVITY
          </span>
        </div>

        <span className="text-[11px] sm:text-xs font-black tracking-wider text-slate-500 uppercase">
          RECENT VERIFIED TOP-UP ACTIVITY
        </span>
      </div>

      {/* Review List (Always strictly 4 items, ordered 30s -> 2m -> 6m -> 12m) */}
      <div className="flex flex-col gap-3 min-h-[360px]">
        <AnimatePresence mode="popLayout">
          {visibleReviews.map((rev) => {
            const color = avatarColors[Math.abs(rev.name.charCodeAt(0) % avatarColors.length)];
            const isLiked = !!likedIds[rev.id];

            return (
              <motion.div
                key={rev.id}
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.35, ease: "easeOut" }}
                className="p-3.5 rounded-xl border border-gray-100 bg-gray-50/60 space-y-2 text-left transition-all hover:bg-gray-50 hover:border-gray-200"
              >
                {/* Header row */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className={`w-8 h-8 rounded-full ${color} text-white flex items-center justify-center font-black text-xs uppercase shadow-xs shrink-0`}>
                      {rev.initial}
                    </div>
                    <div className="text-left min-w-0">
                      <div className="flex items-center gap-1">
                        <span className="text-xs font-black text-gray-900 truncate max-w-[130px] sm:max-w-[180px]">{rev.name}</span>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 fill-emerald-50 shrink-0" />
                      </div>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <div className="flex text-amber-400">
                          {[...Array(rev.rating || 5)].map((_, i) => (
                            <Star key={i} className="w-2.5 h-2.5 fill-current" />
                          ))}
                        </div>
                        {/* Strictly ordered: Top is 30s, descending down to under 15m */}
                        <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-1.5 py-0.2 rounded">
                          {rev.timeAgo}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-0.5 shrink-0">
                    <span className="text-[9px] bg-emerald-50 text-emerald-700 font-black px-2 py-0.5 rounded-full border border-emerald-100 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-emerald-600" />
                      Verified Buyer
                    </span>
                    <span className="text-[9px] font-mono text-gray-400 tracking-tight">
                      {rev.upiRef}
                    </span>
                  </div>
                </div>

                {/* Package Tag & Price */}
                <div className="flex items-center justify-between bg-amber-50/70 border border-amber-100/80 px-2.5 py-1 rounded-lg text-[10px] font-extrabold text-amber-800">
                  <div className="flex items-center gap-1.5">
                    <img
                      src="https://static.wixstatic.com/media/fa21d6_28cb860923fa474abd20749b7cfc313e~mv2.webp/v1/fill/w_32,h_32,al_c,q_75/fa21d6_28cb860923fa474abd20749b7cfc313e~mv2.webp"
                      alt="♦"
                      loading="lazy"
                      decoding="async"
                      className="w-3.5 h-3.5 object-contain"
                    />
                    <span>{rev.packageText}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="text-gray-400 font-normal">Paid</span>
                    <span className="text-gray-900 font-black">{rev.packagePrice}</span>
                  </div>
                </div>

                {/* Customer Comment */}
                <p className="text-xs text-gray-700 leading-relaxed font-medium">
                  "{rev.msg}"
                </p>

                {/* Footer status / likes */}
                <div className="flex items-center justify-between pt-1.5 border-t border-gray-100 text-[10px] text-gray-400 font-semibold">
                  <button 
                    onClick={() => handleLike(rev.id)}
                    className={`flex items-center gap-1 transition-colors cursor-pointer ${isLiked ? 'text-emerald-600 font-bold' : 'hover:text-gray-700'}`}
                  >
                    <ThumbsUp className={`w-3 h-3 ${isLiked ? 'text-emerald-500 fill-emerald-100' : 'text-gray-400'}`} />
                    Helpful ({rev.likes})
                  </button>
                  <div className="flex items-center gap-1.5 text-[9px] text-gray-400">
                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                    Delivered via Player UID
                  </div>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Write a Review Button */}
      <button
        onClick={onWriteReview}
        className="w-full border-2 border-dashed border-gray-200 text-gray-600 hover:border-[#ee2c24] hover:text-[#ee2c24] py-3 px-4 rounded-xl font-bold text-xs uppercase tracking-wider transition-all duration-300 cursor-pointer flex items-center justify-center gap-2 bg-white hover:bg-red-50/20"
      >
        <PenTool className="w-4 h-4" />
        Write a Review
      </button>
    </div>
  );
}
