export interface CustomerReview {
  id: string;
  name: string;
  initial: string;
  rating: number;
  date: string;
  msg: string;
  packageText: string;
  packagePrice: string;
  likes: number;
  verified: boolean;
}

export const initialReviewsData: CustomerReview[] = [
  {
    id: "rev-101",
    name: "Aryan Sharma",
    initial: "A",
    rating: 5,
    date: "18 Sep 2026",
    msg: "Bhai 100% working hai, 2180 diamonds 2 minute ke andar ID me credit ho gaye. Payment UPI se smooth tha.",
    packageText: "1,090 + 1,090 Diamonds",
    packagePrice: "₹550",
    likes: 38,
    verified: true
  },
  {
    id: "rev-102",
    name: "Rohan Varma",
    initial: "R",
    rating: 5,
    date: "17 Sep 2026",
    msg: "Double diamond bonus package sach me deliver hua. UID check karne ke baad turant receive hua. Trusted service.",
    packageText: "2,220 + 2,220 Diamonds (Offer)",
    packagePrice: "₹750",
    likes: 42,
    verified: true
  },
  {
    id: "rev-103",
    name: "Faizan Khan",
    initial: "F",
    rating: 5,
    date: "16 Sep 2026",
    msg: "Instant top up service. Level 72 ID par safe recharge hua without any issue. Best pricing in India.",
    packageText: "4,210 + 4,210 Diamonds (Offer)",
    packagePrice: "₹1,100",
    likes: 29,
    verified: true
  },
  {
    id: "rev-104",
    name: "Santhosh Kumar",
    initial: "S",
    rating: 5,
    date: "15 Sep 2026",
    msg: "Super fast topup. Got double diamond bonus directly in my Free Fire account. Support response was also quick.",
    packageText: "1,090 + 1,090 Diamonds",
    packagePrice: "₹550",
    likes: 19,
    verified: true
  },
  {
    id: "rev-105",
    name: "Vikram Rathore",
    initial: "V",
    rating: 5,
    date: "14 Sep 2026",
    msg: "Pehle doubt tha but trial ke liye ₹550 wala package try kiya. Turant diamond add ho gaye. Thanks GGDIAMOND.",
    packageText: "1,090 + 1,090 Diamonds",
    packagePrice: "₹550",
    likes: 31,
    verified: true
  },
  {
    id: "rev-106",
    name: "Rahul Meena",
    initial: "R",
    rating: 5,
    date: "12 Sep 2026",
    msg: "Genuine gaming recharge portal. Diamonds instantly reflect ho gaye game me. Recommended for all players.",
    packageText: "6,580 + 6,580 Diamonds (Offer)",
    packagePrice: "₹1,400",
    likes: 24,
    verified: true
  }
];
