import { GATEWAY_BASE_URL } from './regions';
import { PlayerData } from '../types';

/**
 * Fetches Garena player profile details using regional gateway.
 * Throws an error if network fails or player does not exist.
 */
export async function loginPlayer(uid: string, region: string): Promise<PlayerData> {
  const trimmedUid = uid.trim();

  // Blocked/Test UIDs - block and prompt to enter valid UID
  if (trimmedUid === '11111111') {
    throw new Error('Please enter your Player UID');
  }

  const url = `${GATEWAY_BASE_URL}?s=${encodeURIComponent(region)}&u=${encodeURIComponent(trimmedUid)}`;
  
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error('Network error encountered. Garena gateway timed out.');
  }
  
  const data = await res.json() as PlayerData;
  if (!data || !data.basicInfo) {
    throw new Error(`UID "${trimmedUid}" could not be located in Garena's ${region.toUpperCase()} server.`);
  }
  
  return data;
}
