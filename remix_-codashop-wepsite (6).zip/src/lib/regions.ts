// Note: 'gatway' is the actual registered domain (typo intentional — do not "fix" it)
export const GATEWAY_BASE_URL = 'https://gatway-seven.vercel.app/gateway';

export interface RegionItem {
  value: string;
  label: string;
}

export const REGIONS_MAP: RegionItem[] = [
  { value: 'ind', label: '🇮🇳 India Region' },
  { value: 'sg', label: '🇸🇬 Singapore Region' },
  { value: 'id', label: '🇮🇩 Indonesia Region' },
  { value: 'pk', label: '🇵🇰 Pakistan Region' },
  { value: 'bd', label: '🇧🇩 Bangladesh Region' },
  { value: 'br', label: '🇧🇷 Brazil Region' },
  { value: 'na', label: '🇺🇸 North America' },
  { value: 'latam', label: '🇲🇽 LATAM Region' },
  { value: 'us', label: '🇺🇸 United States' },
  { value: 'th', label: '🇹🇭 Thailand Region' },
  { value: 'vn', label: '🇻🇳 Vietnam Region' },
  { value: 'my', label: '🇲🇾 Malaysia Region' },
  { value: 'tw', label: '🇹🇼 Taiwan Region' },
  { value: 'me', label: '🇦🇪 Middle East' },
  { value: 'eu', label: '🇪🇺 Europe Region' },
  { value: 'cis', label: '🇷🇺 CIS Region' }
];
