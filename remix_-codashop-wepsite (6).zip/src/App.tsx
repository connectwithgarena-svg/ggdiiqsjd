import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, AlertTriangle, ShieldCheck, Mail, MessageCircle, HelpCircle, User, 
  Heart, ThumbsUp, Sparkles, CheckCircle2, Lock, ArrowRight, ArrowLeft,
  Loader2, Send
} from 'lucide-react';

// Type definitions
import { PlayerData, PackageItem, PageRoute } from './types';

// SEO / Components / Pages
import SEO from './components/SEO';
import Navigation from './components/Navigation';
import Footer from './components/Footer';
import WelcomePopup from './components/WelcomePopup';
import ReviewFeed from './components/ReviewFeed';
import PageLoader from './components/PageLoader';

import Home from './pages/Home';
import DiamondPackages from './pages/DiamondPackages';
import Checkout from './pages/Checkout';
import About from './pages/About';
import Contact from './pages/Contact';
import FAQ from './pages/FAQ';
import Privacy from './pages/Privacy';
import Terms from './pages/Terms';
import Bonus from './pages/Bonus';
import Refund from './pages/Refund';
import AntiFraud from './pages/AntiFraud';
import PaymentPolicy from './pages/PaymentPolicy';
import Verify from './pages/Verify';

import { REGIONS_MAP } from './lib/regions';
import { loginPlayer } from './lib/loginPlayer';
import ffUidGuideImg from './assets/images/ff.jpg';

// Increment this version whenever you want to forcefully logout ALL devices globally
const CURRENT_AUTH_SESSION_VERSION = 'v2_force_logout_2026';
const INACTIVITY_TIMEOUT_MS = 5 * 60 * 1000; // 5 minutes of total inactivity

export default function App() {
  // Routing state
  const [route, setRouteState] = useState<PageRoute>('home');
  const [isPageLoading, setIsPageLoading] = useState(false);

  // Player global state
  const [uid, setUid] = useState<string>('');
  const [playerData, setPlayerData] = useState<PlayerData | null>(null);
  const [selectedPackage, setSelectedPackage] = useState<PackageItem | null>(null);
  const [playerRegion, setPlayerRegion] = useState<string>('');

  // Modal active flags
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [welcomePopupOpen, setWelcomePopupOpen] = useState(false);

  // Header login states
  const [loginUid, setLoginUid] = useState<string>('');
  const [loginRegion, setLoginRegion] = useState<string>('ind');
  const [loginLoading, setLoginLoading] = useState<boolean>(false);
  const [loginStatusMessage, setLoginStatusMessage] = useState<string>('');

  // Success screen state (loaded from payment links redirects)
  const [successState, setSuccessState] = useState<{
    avatar: string;
    nick: string;
    uid: string;
    lvl: string;
    price: string;
    dia: string;
  } | null>(null);

  const [failureState, setFailureState] = useState<boolean>(false);

  // Custom Route Transitioning State Hook
  const setRoute = (newRoute: PageRoute) => {
    setRouteState(newRoute);
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Sync path URL to keep sitemaps and URLs friendly
    const path = newRoute === 'home' ? '/' : `/${newRoute}`;
    window.history.pushState({ route: newRoute }, '', path);
  };

  const navigateTo = (newRoute: PageRoute) => {
    if (newRoute === route) return;
    setIsPageLoading(true);
    setTimeout(() => {
      setRoute(newRoute);
      window.scrollTo({ top: 0, behavior: 'instant' });
      setTimeout(() => setIsPageLoading(false), 250);
    }, 450);
  };

  // Synchronize path URL on mount & handle browser Back/Forward navigation
  useEffect(() => {
    const handleUrlSync = () => {
      const path = window.location.pathname.toLowerCase();
      const urlParams = new URLSearchParams(window.location.search);
      const payStatus = urlParams.get('status');

      // Check for success parameters
      if (payStatus === 'success') {
        const timestampStr = localStorage.getItem('ff_timestamp');
        const now = Date.now();
        const isStale = !timestampStr || (now - parseInt(timestampStr, 10)) > 30 * 60 * 1000; // 30 minutes

        if (isStale) {
          handleOpenErrorModal('Payment success state is expired or invalid.');
          setRouteState('home');
          window.history.replaceState({}, document.title, window.location.pathname);
          return;
        }

        const cachedAvatar = localStorage.getItem('ff_avatar_url') || '/assets/icon.png';
        const cachedNick = localStorage.getItem('ff_nick') || 'Player';
        const cachedUid = localStorage.getItem('ff_uid') || '---';
        const cachedLvl = localStorage.getItem('ff_lvl') || '--';
        const cachedPrice = localStorage.getItem('ff_price') || '0';
        const cachedDia = localStorage.getItem('ff_dia') || '0';

        setSuccessState({
          avatar: cachedAvatar,
          nick: cachedNick,
          uid: cachedUid,
          lvl: cachedLvl,
          price: cachedPrice,
          dia: cachedDia,
        });

        // Fire Facebook Pixel Purchase event — only on real payment success
        if (typeof (window as any).fbq === 'function') {
          (window as any).fbq('track', 'Purchase', {
            currency: 'INR',
            value: parseFloat(cachedPrice) || 0,
            content_name: `Free Fire ${cachedDia} Diamonds`,
            content_type: 'product',
            content_ids: ['ff_diamonds'],
            num_items: 1,
          });
        }

        // Clean up parameters safely without refreshing page
        window.history.replaceState({}, document.title, window.location.pathname);
        return;
      } else if (payStatus === 'failed' || payStatus === 'cancel') {
        setFailureState(true);
        window.history.replaceState({}, document.title, window.location.pathname);
      }

      // Check routes
      if (path.includes('about')) {
        setRouteState('about');
      } else if (path.includes('diamond')) {
        setRouteState('diamond');
      } else if (path.includes('checkout')) {
        setRouteState('checkout');
      } else if (path.includes('contact')) {
        setRouteState('contact');
      } else if (path.includes('faq')) {
        setRouteState('faq');
      } else if (path.includes('privacy')) {
        setRouteState('privacy');
      } else if (path.includes('terms')) {
        setRouteState('terms');
      } else if (path.includes('refund')) {
        setRouteState('refund');
      } else if (path.includes('antifraud') || path.includes('fraud')) {
        setRouteState('antifraud');
      } else if (path.includes('payment')) {
        setRouteState('payment');
      } else if (path.includes('verify')) {
        const params = new URLSearchParams(window.location.search);
        if (params.get('token') === 'FF2024VERIFY') {
          setRouteState('verify');
        } else {
          setRouteState('home');
        }
      } else if (path.includes('bonus') || urlParams.has('bonus')) {
        setRouteState('bonus');
      } else {
        setRouteState('home');
      }
    };

    handleUrlSync();
    window.addEventListener('popstate', handleUrlSync);

    // Dynamic Welcome Popup — 10-minute cooldown per device
    const POPUP_COOLDOWN_MS = 10 * 60 * 1000; // 10 minutes
    const timer = setTimeout(() => {
      const urlParams = new URLSearchParams(window.location.search);
      if (urlParams.get('status')) return; // never show on payment return

      const lastShown = localStorage.getItem('popup_last_shown');
      const now = Date.now();
      const shouldShow = !lastShown || now - parseInt(lastShown, 10) > POPUP_COOLDOWN_MS;

      if (shouldShow) {
        localStorage.setItem('popup_last_shown', String(now));
        setWelcomePopupOpen(true);
      }
    }, 1500);

    return () => {
      window.removeEventListener('popstate', handleUrlSync);
      clearTimeout(timer);
    };
  }, []);

  // Player logout handler
  const handleLogout = () => {
    localStorage.removeItem('ff_logged_in');
    localStorage.removeItem('ff_uid');
    localStorage.removeItem('ff_nick');
    localStorage.removeItem('ff_avatar_url');
    localStorage.removeItem('ff_lvl');
    localStorage.removeItem('ff_region');
    localStorage.removeItem('ff_player_data');
    localStorage.removeItem('ff_last_activity');
    
    // Reset app state
    setUid('');
    setPlayerData(null);
    setPlayerRegion('ind');
    
    // Navigate back to home
    setRoute('home');
  };

  // Restore login session from localStorage on mount (with Version & Inactivity Check)
  useEffect(() => {
    const savedVersion = localStorage.getItem('ff_auth_session_version');
    
    // If session version doesn't match or is missing, force-logout and clear old session
    if (savedVersion !== CURRENT_AUTH_SESSION_VERSION) {
      handleLogout();
      localStorage.setItem('ff_auth_session_version', CURRENT_AUTH_SESSION_VERSION);
      return;
    }

    const isLoggedIn = localStorage.getItem('ff_logged_in') === 'true';
    if (isLoggedIn) {
      const lastActivity = parseInt(localStorage.getItem('ff_last_activity') || '0', 10);
      const now = Date.now();

      // If user was inactive for > 5 mins while away/closed, logout immediately
      if (lastActivity && now - lastActivity > INACTIVITY_TIMEOUT_MS) {
        handleLogout();
        return;
      }

      const storedUid = localStorage.getItem('ff_uid') || '';
      const storedRegion = localStorage.getItem('ff_region') || 'ind';
      const storedDataStr = localStorage.getItem('ff_player_data');
      if (storedUid && storedDataStr) {
        try {
          const parsedData = JSON.parse(storedDataStr) as PlayerData;
          setUid(storedUid);
          setPlayerData(parsedData);
          setPlayerRegion(storedRegion);
          localStorage.setItem('ff_last_activity', String(now));
        } catch (e) {
          console.error("Failed to restore player session:", e);
        }
      }
    }
  }, []);

  // Track User Activity & 5-minute inactivity live logout
  useEffect(() => {
    if (!playerData) return;

    let inactivityTimer: NodeJS.Timeout;

    const recordActivity = () => {
      localStorage.setItem('ff_last_activity', String(Date.now()));
      clearTimeout(inactivityTimer);
      // Set timer to automatically logout if no activity happens for 5 minutes
      inactivityTimer = setTimeout(() => {
        handleLogout();
      }, INACTIVITY_TIMEOUT_MS);
    };

    // Initial timer setup
    recordActivity();

    // Active user interaction events (Clicks, Mouse movements, Touches, Keypress, Scroll)
    const activityEvents = ['mousedown', 'mousemove', 'keydown', 'touchstart', 'scroll', 'click'];
    
    // Throttle event listeners to avoid performance overhead
    let throttleTimeout: NodeJS.Timeout | null = null;
    const handleUserInteraction = () => {
      if (!throttleTimeout) {
        throttleTimeout = setTimeout(() => {
          recordActivity();
          throttleTimeout = null;
        }, 1000);
      }
    };

    activityEvents.forEach((event) => {
      window.addEventListener(event, handleUserInteraction, { passive: true });
    });

    // Check on tab visibility change (e.g. when user switches back to tab after being away)
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        const lastActivity = parseInt(localStorage.getItem('ff_last_activity') || '0', 10);
        if (lastActivity && Date.now() - lastActivity > INACTIVITY_TIMEOUT_MS) {
          handleLogout();
        } else {
          recordActivity();
        }
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      clearTimeout(inactivityTimer);
      if (throttleTimeout) clearTimeout(throttleTimeout);
      activityEvents.forEach((event) => {
        window.removeEventListener(event, handleUserInteraction);
      });
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [playerData]);

  // Player login success coordinator
  const handleLoginSuccess = (data: PlayerData, loginUid: string, region: string) => {
    const now = Date.now();
    setUid(loginUid);
    setPlayerData(data);
    setPlayerRegion(region);

    localStorage.setItem('ff_auth_session_version', CURRENT_AUTH_SESSION_VERSION);
    localStorage.setItem('ff_logged_in', 'true');
    localStorage.setItem('ff_uid', loginUid);
    localStorage.setItem('ff_nick', data.basicInfo.nickname);
    localStorage.setItem('ff_avatar_url', `https://gatway-seven.vercel.app/gateway?img=${data.basicInfo.headPic || '902000162'}`);
    localStorage.setItem('ff_lvl', String(data.basicInfo.level));
    localStorage.setItem('ff_region', region);
    localStorage.setItem('ff_player_data', JSON.stringify(data));
    localStorage.setItem('ff_last_activity', String(now));

    setActiveModal('vModal'); // Open Account details modal automatically
  };

  const handleOpenUIDGuide = () => {
    setActiveModal('guideModal');
  };

  const handleOpenErrorModal = (msg: string) => {
    setErrorMessage(msg);
    setActiveModal('errorModal');
  };

  const handleHeaderLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginUid.trim()) {
      handleOpenErrorModal('Please enter your Player UID');
      return;
    }

    setLoginLoading(true);
    setLoginStatusMessage('Connecting to game servers...');

    const verifierTimeout = setTimeout(() => {
      setLoginStatusMessage('Verifying Player UID against regional registry...');
    }, 800);

    try {
      const data = await loginPlayer(loginUid, loginRegion);
      clearTimeout(verifierTimeout);
      setLoginStatusMessage('Login Successful!');
      
      // Call the parent handler
      handleLoginSuccess(data, loginUid.trim(), loginRegion);
      // Clear inputs
      setLoginUid('');
      setLoginStatusMessage('');
    } catch (err: any) {
      clearTimeout(verifierTimeout);
      console.error(err);
      setLoginStatusMessage('');
      handleOpenErrorModal(err.message || 'Network error encountered. Gateway timed out. Please try again.');
    } finally {
      setLoginLoading(false);
    }
  };

  // Modal Closures
  const handleCloseModals = () => {
    setActiveModal(null);
  };

  // SEO configuration based on active route
  const getSEOMeta = () => {
    switch (route) {
      case 'diamond':
        return {
          title: 'Select Diamond Packages - Cheap FF MAX Diamonds',
          description: 'Buy cheap FF MAX diamonds with 100% Double Diamond bonus! Instant Free Fire diamond top-up starting at ₹550 for 2180 diamonds. 100% safe & InStock.',
          keywords: 'Free Fire diamond top-up, cheap FF MAX diamonds, instant delivery Free Fire diamonds, double diamond top-up, buy Free Fire diamonds online, FF UID top-up India, 9th anniversary diamonds',
          canonical: 'https://www.ggdiamond.shop/diamond',
          schema: {
            "@context": "https://schema.org",
            "@type": "Product",
            "name": "Free Fire & Free Fire MAX Diamond Top-Up",
            "alternateName": "Cheap FF MAX Diamonds - Instant Delivery",
            "image": [
              "https://www.ggdiamond.shop/assets/ff_banner.jpg",
              "https://static.wixstatic.com/media/fa21d6_28cb860923fa474abd20749b7cfc313e~mv2.webp/v1/fill/w_100,h_100,al_c,q_80/fa21d6_28cb860923fa474abd20749b7cfc313e~mv2.webp"
            ],
            "description": "Select Free Fire and Free Fire MAX diamond recharge packages. Instant delivery via Player UID with 100% double diamond promotional bonus.",
            "category": "Gaming / In-Game Currency",
            "brand": {
              "@type": "Brand",
              "name": "Garena Free Fire"
            },
            "offers": {
              "@type": "AggregateOffer",
              "priceCurrency": "INR",
              "lowPrice": "550",
              "highPrice": "7500",
              "offerCount": "6",
              "availability": "https://schema.org/InStock",
              "itemCondition": "https://schema.org/NewCondition",
              "priceValidUntil": "2027-12-31",
              "url": "https://www.ggdiamond.shop/diamond"
            }
          }
        };
      case 'checkout':
        return {
          title: 'Secure Checkout - Instant Free Fire Diamond Delivery via UID',
          description: 'Confirm your Free Fire Player UID and complete secure payment via UPI, Debit Card, Credit Card or NetBanking. Instant automated diamond credit to your Free Fire wallet.',
          keywords: 'Secure Free Fire Top-Up, Free Fire UID Top-Up, Free Fire Recharge, Instant Game Recharge, Double Diamond Top-Up Checkout, cheap FF MAX diamonds',
          canonical: 'https://www.ggdiamond.shop/checkout'
        };
      case 'about':
        return {
          title: 'About Us - GGDIAMOND Diamond Top Up Center',
          description: 'Learn about ggdiamond.shop — India\'s most trusted Free Fire & Free Fire MAX diamond top-up platform with instant UID delivery, zero ban risk, and 100% double bonus.',
          keywords: 'Free Fire diamond top-up, cheap FF MAX diamonds, instant delivery Free Fire diamonds, about ggdiamond.shop, secure Free Fire top up',
          canonical: 'https://www.ggdiamond.shop/about'
        };
      case 'contact':
        return {
          title: 'Help Center & 24/7 Support - Free Fire Diamond Top-Up',
          description: 'Contact our 24/7 Free Fire diamond recharge support desk for assistance with UID logins, double diamond bonuses, and instant UPI transactions.',
          keywords: 'Free Fire top-up support, diamond recharge help, instant game recharge assistance, double diamond support ggdiamond',
          canonical: 'https://www.ggdiamond.shop/contact'
        };
      case 'faq':
        return {
          title: 'FAQs - Free Fire Diamond Top-Up & Instant Delivery',
          description: 'Frequently asked questions about Free Fire diamond recharge, instant delivery guarantees, double diamond bonus eligibility, and anti-ban security.',
          keywords: 'Free Fire diamond top-up FAQ, cheap FF MAX diamonds FAQ, instant delivery Free Fire diamonds, double diamond top-up FAQ',
          canonical: 'https://www.ggdiamond.shop/faq',
          schema: {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [
              {
                "@type": "Question",
                "name": "How do I top-up Free Fire diamonds using my Player UID?",
                "acceptedAnswer": {
                  "@type": "Answer",
                  "text": "Simply enter your Free Fire or Free Fire MAX Player UID into the login box, select your regional server, verify your in-game nickname and level fetched live from the server, choose your diamond package with 100% bonus, and complete payment for instant delivery."
                }
              },
              {
                "@type": "Question",
                "name": "How long does instant diamond delivery take?",
                "acceptedAnswer": {
                  "@type": "Answer",
                  "text": "Diamonds are credited to your Free Fire ID instantly within 5 to 30 seconds after payment confirmation via our automated top-up gateway connection."
                }
              },
              {
                "@type": "Question",
                "name": "Is my Free Fire account 100% safe from bans?",
                "acceptedAnswer": {
                  "@type": "Answer",
                  "text": "Yes, 100% safe. We only require your in-game Player UID. We never ask for passwords, OTPs, or login credentials. All deliveries follow verified top-up protocols with zero ban risk."
                }
              },
              {
                "@type": "Question",
                "name": "Why are diamonds cheaper with 100% bonus on ggdiamond.shop?",
                "acceptedAnswer": {
                  "@type": "Answer",
                  "text": "We provide special promotional pricing and double diamond bonuses (100% bonus rewards) directly connected to verified top-up protocols, giving players maximum value."
                }
              }
            ]
          }
        };
      case 'privacy':
        return {
          title: 'Privacy Policy - Free Fire UID Top-Up Security',
          description: 'We respect player profile privacy and data security. Review our data protection practices for Free Fire diamond top-up orders at ggdiamond.shop.',
          keywords: 'Free Fire Privacy Policy, ggdiamond privacy, secure gaming top-up data',
          canonical: 'https://www.ggdiamond.shop/privacy'
        };
      case 'terms':
        return {
          title: 'Terms & Conditions - Free Fire Diamond Recharge',
          description: 'Terms of service, double diamond campaign rules, player UID guidelines, and delivery liability policies for ggdiamond.shop.',
          keywords: 'Free Fire Top-Up Terms, ggdiamond terms, refund policy free fire',
          canonical: 'https://www.ggdiamond.shop/terms'
        };
      case 'refund':
        return {
          title: 'Refund & Cancellation Policy - Diamond Top-Up',
          description: 'Comprehensive refund guidelines, failed payment auto-reversal protocols, and cancellation procedures for Free Fire recharge orders.',
          keywords: 'Free Fire Refund Policy, diamond refund garena, top-up refund procedures',
          canonical: 'https://www.ggdiamond.shop/refund'
        };
      case 'antifraud':
        return {
          title: 'Anti-Fraud & Abuse Prevention Policy',
          description: 'Our zero-tolerance policy against payment fraud, chargeback abuse, and unauthorized transactions on Free Fire diamond top-ups.',
          keywords: 'Free Fire Top-up Anti Fraud, secure payment prevention, top-up blacklist rules',
          canonical: 'https://www.ggdiamond.shop/antifraud'
        };
      case 'payment':
        return {
          title: 'Payment Policy - Instant UPI & NetBanking Top-Up',
          description: 'Accepted payment methods including UPI, PhonePe, Google Pay, Paytm, cards, and net banking with encrypted 256-bit SSL checkout.',
          keywords: 'Free Fire Payment Policy, secure UPI top-up, instant payment safety',
          canonical: 'https://www.ggdiamond.shop/payment'
        };
      default:
        return {
          title: 'Free Fire Diamond Top-Up | Cheap FF MAX Diamonds Instant Delivery',
          description: 'Buy cheap FF MAX diamonds with instant delivery! GGDIAMOND Diamond Top Up Center with 100% Double Diamond Bonus starting at ₹550 for 2180 diamonds. Safe, automated & instant.',
          keywords: 'Free Fire diamond top-up, cheap FF MAX diamonds, instant delivery Free Fire diamonds, double diamond top-up, buy Free Fire diamonds online, Free Fire recharge, FF UID top-up India, Garena Free Fire topup, ggdiamond',
          canonical: 'https://www.ggdiamond.shop/',
          schema: {
            "@context": "https://schema.org",
            "@type": "Product",
            "name": "Free Fire Diamond Top-Up - Cheap FF MAX Diamonds",
            "alternateName": "Free Fire MAX Instant Diamond Recharge",
            "image": [
              "https://www.ggdiamond.shop/assets/ff_banner.jpg",
              "https://static.wixstatic.com/media/fa21d6_28cb860923fa474abd20749b7cfc313e~mv2.webp/v1/fill/w_100,h_100,al_c,q_80/fa21d6_28cb860923fa474abd20749b7cfc313e~mv2.webp"
            ],
            "description": "Instant Free Fire & Free Fire MAX diamond top-up with 100% double diamond promotional bonus. 100% secure, zero ban risk, instant automated delivery.",
            "category": "Gaming / In-Game Currency",
            "brand": {
              "@type": "Brand",
              "name": "Garena Free Fire"
            },
            "offers": {
              "@type": "AggregateOffer",
              "priceCurrency": "INR",
              "lowPrice": "550",
              "highPrice": "7500",
              "offerCount": "6",
              "availability": "https://schema.org/InStock",
              "itemCondition": "https://schema.org/NewCondition",
              "priceValidUntil": "2027-12-31",
              "url": "https://www.ggdiamond.shop/"
            },
            "aggregateRating": {
              "@type": "AggregateRating",
              "ratingValue": "4.9",
              "reviewCount": "18450",
              "bestRating": "5",
              "worstRating": "1"
            }
          }
        };
    }
  };

  const meta = getSEOMeta();

  return (
    <>
      <AnimatePresence>
        {isPageLoading && <PageLoader key="loader" />}
      </AnimatePresence>

      <div className="min-h-screen bg-[#f2f2f2] text-gray-800 flex flex-col font-sans select-none antialiased">
      {/* SEO configuration injection */}
      <SEO 
        title={meta.title} 
        description={meta.description} 
        keywords={meta.keywords}
        canonical={meta.canonical}
        schema={meta.schema}
      />

      {/* Header Sticky Navigation */}
      <Navigation
        currentRoute={route}
        setRoute={navigateTo}
        loggedInUser={playerData?.basicInfo.nickname || null}
        onOpenProfile={() => setActiveModal('profileModal')}
        onOpenLoginModal={() => setActiveModal('loginModal')}
      />

      {/* Main Content Layout container */}
      <main className="flex-1 w-full max-w-lg mx-auto px-4 py-6 flex flex-col justify-start">
        {successState ? (
          /* TRANSACTION SUCCESS SCREEN - LIGHT THEME */
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
            className="relative overflow-hidden rounded-3xl text-center"
            style={{ background: '#ffffff', boxShadow: '0 8px 40px rgba(0,0,0,0.10)' }}
          >
            {/* Top green strip */}
            <div style={{ height: 5, background: 'linear-gradient(90deg,#34d399,#10b981,#059669)' }} />

            {/* Header */}
            <div style={{ background: 'linear-gradient(135deg,#ecfdf5 0%,#f0fdf4 100%)', padding: '32px 24px 24px', textAlign: 'center', borderBottom: '1px solid #d1fae5' }}>
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: 'spring', stiffness: 300 }}
                style={{ width: 76, height: 76, borderRadius: '50%', background: 'linear-gradient(135deg,#059669,#34d399)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px', boxShadow: '0 6px 24px rgba(5,150,105,0.32)', fontSize: 34 }}
              >
                ✅
              </motion.div>
              <div style={{ fontSize: 22, fontWeight: 900, color: '#064e3b', letterSpacing: -0.5 }}>Payment Successful! 🎉</div>
              <div style={{ fontSize: 12, color: '#10b981', fontWeight: 600, marginTop: 4 }}>Transaction verified &amp; processed securely</div>
            </div>

            {/* Player Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              style={{ margin: '20px 20px 0', background: '#f9fafb', border: '1.5px solid #e5e7eb', borderRadius: 16, padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 14 }}
            >
              <img
                src={successState.avatar}
                alt={`Free Fire verified player ${successState.nick} (UID ${successState.uid})`}
                style={{ width: 62, height: 62, borderRadius: 14, objectFit: 'cover', border: '2.5px solid #fbbf24', boxShadow: '0 2px 12px rgba(251,191,36,0.3)', flexShrink: 0 }}
                onError={(e) => { (e.target as HTMLImageElement).src = '/assets/icon.png'; }}
              />
              <div style={{ textAlign: 'left' }}>
                <div style={{ fontSize: 15, fontWeight: 800, color: '#111' }}>{successState.nick}</div>
                <div style={{ fontSize: 11, color: '#6b7280', marginTop: 2, fontWeight: 500 }}>UID: <span style={{ color: '#374151', fontWeight: 700 }}>{successState.uid}</span></div>
                <div style={{ display: 'inline-block', background: '#fef3c7', color: '#92400e', fontSize: 10, fontWeight: 700, borderRadius: 6, padding: '2px 8px', marginTop: 5, border: '1px solid #fde68a' }}>⚔️ Level {successState.lvl}</div>
              </div>
            </motion.div>

            {/* Diamond Box */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              style={{ margin: '14px 20px 0', background: 'linear-gradient(135deg,#fff8e1,#fffde7)', border: '1.5px solid #fde68a', borderRadius: 16, padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 14 }}
            >
              <span style={{ fontSize: 38 }}>💎</span>
              <div>
                <div style={{ fontSize: 28, fontWeight: 900, color: '#b45309', letterSpacing: -1 }}>
                  {successState.dia} <span style={{ color: '#9ca3af', fontSize: 13, fontWeight: 600 }}>Diamonds</span>
                </div>
                <div style={{ fontSize: 11, color: '#78716c', fontWeight: 600 }}>Successfully Purchased</div>
              </div>
            </motion.div>

            {/* Thank you message */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              style={{ margin: '14px 20px 0', textAlign: 'center' }}
            >
              <p style={{ fontSize: 13, color: '#374151', lineHeight: 1.7, fontWeight: 500 }}>
                Thanks for purchasing diamonds! 🎉<br />
                Your <strong style={{ color: '#059669' }}>{successState.dia} 💎 Diamonds</strong> have been successfully<br />
                credited to your Free Fire account<br />
                <strong>UID: {successState.uid}</strong>
              </p>
            </motion.div>

            {/* Home Button */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              style={{ margin: '20px 20px 24px' }}
            >
              <button
                onClick={() => { setSuccessState(null); navigateTo('home'); }}
                style={{ width: '100%', background: 'linear-gradient(135deg,#059669,#10b981)', color: '#fff', fontSize: 14, fontWeight: 800, padding: '16px', borderRadius: 14, border: 'none', cursor: 'pointer', letterSpacing: 0.5, boxShadow: '0 6px 18px rgba(5,150,105,0.35)' }}
              >
                🏠 Back to Home
              </button>
            </motion.div>
          </motion.div>
        ) : failureState ? (
          /* FAILED PAYMENT SCREEN - LIGHT THEME */
          (() => {
            const fNick = localStorage.getItem('ff_nick') || 'Player';
            const fUid = localStorage.getItem('ff_uid') || '---';
            const fLvl = localStorage.getItem('ff_lvl') || '--';
            const fAvatar = localStorage.getItem('ff_avatar_url') || '/assets/icon.png';
            const fDia = localStorage.getItem('ff_dia') || '0';
            return (
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, ease: 'easeOut' }}
                className="relative overflow-hidden rounded-3xl text-center"
                style={{ background: '#ffffff', boxShadow: '0 8px 40px rgba(0,0,0,0.10)' }}
              >
                {/* Top red strip */}
                <div style={{ height: 5, background: 'linear-gradient(90deg,#f87171,#ef4444,#dc2626)' }} />

                {/* Header */}
                <div style={{ background: 'linear-gradient(135deg,#fff5f5 0%,#fef2f2 100%)', padding: '32px 24px 24px', textAlign: 'center', borderBottom: '1px solid #fee2e2' }}>
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.2, type: 'spring', stiffness: 300 }}
                    style={{ width: 76, height: 76, borderRadius: '50%', background: 'linear-gradient(135deg,#ef4444,#f87171)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px', boxShadow: '0 6px 24px rgba(239,68,68,0.32)', fontSize: 34 }}
                  >
                    ❌
                  </motion.div>
                  <div style={{ fontSize: 21, fontWeight: 900, color: '#7f1d1d', letterSpacing: -0.5, lineHeight: 1.3 }}>
                    Hey {fNick},<br />You Are Missing 💎!
                  </div>
                  <div style={{ fontSize: 12, color: '#ef4444', fontWeight: 600, marginTop: 6 }}>Payment was not completed</div>
                </div>

                {/* Player Card */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  style={{ margin: '20px 20px 0', background: '#f9fafb', border: '1.5px solid #e5e7eb', borderRadius: 16, padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 14 }}
                >
                  <img
                    src={fAvatar}
                    alt={`Free Fire player ${fNick} (UID: ${fUid})`}
                    style={{ width: 62, height: 62, borderRadius: 14, objectFit: 'cover', border: '2.5px solid #fbbf24', boxShadow: '0 2px 12px rgba(251,191,36,0.3)', flexShrink: 0 }}
                    onError={(e) => { (e.target as HTMLImageElement).src = '/assets/icon.png'; }}
                  />
                  <div style={{ textAlign: 'left' }}>
                    <div style={{ fontSize: 15, fontWeight: 800, color: '#111' }}>{fNick}</div>
                    <div style={{ fontSize: 11, color: '#6b7280', marginTop: 2, fontWeight: 500 }}>UID: <span style={{ color: '#374151', fontWeight: 700 }}>{fUid}</span></div>
                    <div style={{ display: 'inline-block', background: '#fef3c7', color: '#92400e', fontSize: 10, fontWeight: 700, borderRadius: 6, padding: '2px 8px', marginTop: 5, border: '1px solid #fde68a' }}>⚔️ Level {fLvl}</div>
                  </div>
                </motion.div>

                {/* Missing Diamond Box */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  style={{ margin: '14px 20px 0', background: 'linear-gradient(135deg,#fff1f2,#fff5f5)', border: '1.5px solid #fecaca', borderRadius: 16, padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 14 }}
                >
                  <span style={{ fontSize: 38 }}>💎</span>
                  <div>
                    <div style={{ fontSize: 28, fontWeight: 900, color: '#dc2626', letterSpacing: -1 }}>{fDia} Diamonds</div>
                    <div style={{ fontSize: 11, color: '#9ca3af', fontWeight: 600 }}>Still pending — top up now to claim!</div>
                  </div>
                </motion.div>

                {/* Trust Badge */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 }}
                  style={{ margin: '14px 20px 0', background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 12, padding: '10px 14px', textAlign: 'center' }}
                >
                  <p style={{ fontSize: 11, color: '#166534', fontWeight: 700, lineHeight: 1.6 }}>
                    ✅ 100% Trusted Website for Top Up Game Currency 💎<br />
                    in Free Fire — Instant Delivery, Secure Payments
                  </p>
                </motion.div>

                {/* Buttons */}
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 }}
                  style={{ margin: '16px 20px 24px', display: 'flex', flexDirection: 'column', gap: 10 }}
                >
                  <button
                    onClick={() => { setFailureState(false); navigateTo('diamond'); }}
                    style={{ background: 'linear-gradient(135deg,#ee2c24,#f97316)', color: '#fff', fontSize: 13, fontWeight: 800, padding: '15px', borderRadius: 14, border: 'none', cursor: 'pointer', boxShadow: '0 6px 18px rgba(238,44,36,0.35)' }}
                  >
                    💎 Top Up Now
                  </button>
                  <button
                    onClick={() => { setFailureState(false); navigateTo('home'); }}
                    style={{ background: '#f3f4f6', color: '#374151', fontSize: 13, fontWeight: 700, padding: '14px', borderRadius: 14, border: '1.5px solid #e5e7eb', cursor: 'pointer' }}
                  >
                    🏠 Back to Home
                  </button>
                </motion.div>
              </motion.div>
            );
          })()
        ) : (
          /* STANDARD DYNAMIC PAGE VIEWS */
          <div className="space-y-6">
            {route === 'home' && (
              <Home
                isLoggedIn={!!playerData}
                uid={uid}
                playerData={playerData}
                playerRegion={playerRegion}
                onLoginSuccess={handleLoginSuccess}
                onLogout={handleLogout}
                onOpenUIDGuide={handleOpenUIDGuide}
                onOpenErrorModal={handleOpenErrorModal}
                setRoute={navigateTo}
              />
            )}

            {route === 'diamond' && (
              <DiamondPackages
                loggedInUser={playerData?.basicInfo.nickname || null}
                setRoute={navigateTo}
                onSelectPackage={(pkg) => setSelectedPackage(pkg)}
                onOpenErrorModal={handleOpenErrorModal}
              />
            )}

            {route === 'checkout' && (
              <Checkout
                playerData={playerData}
                selectedPackage={selectedPackage}
                uid={uid}
                setRoute={navigateTo}
                onOpenCancelModal={() => setActiveModal('cancelModal')}
              />
            )}

            {route === 'about' && <About />}

            {route === 'contact' && <Contact />}

            {route === 'faq' && <FAQ />}

            {route === 'privacy' && <Privacy />}

            {route === 'terms' && <Terms />}

            {route === 'refund' && <Refund />}

            {route === 'antifraud' && <AntiFraud />}

            {route === 'payment' && <PaymentPolicy />}

            {route === 'verify' && <Verify />}

            {route === 'bonus' && <Bonus />}

            {/* Customer reviews section embedded into Home page/catalogue parameters */}
            {(route === 'home' || route === 'diamond' || route === 'checkout') && (
              <div className="pt-8 sm:pt-12">
                <ReviewFeed onWriteReview={() => setActiveModal('reviewAlertModal')} />
              </div>
            )}
          </div>
        )}
      </main>

      {/* Master Informational Footer */}
      <Footer 
        setRoute={navigateTo} 
        onOpenHelpCenter={() => setActiveModal('helpCenterModal')} 
      />

      {/* Premium Welcome popup campaign */}
      <WelcomePopup
        isOpen={welcomePopupOpen}
        onClose={() => setWelcomePopupOpen(false)}
        onClaim={() => {
          setWelcomePopupOpen(false);
          navigateTo('home');
        }}
      />

      {/* ====================================
          MODAL INTERFACES ACCORDING TO SPECS
          ==================================== */}
      <AnimatePresence>
        {activeModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop blur */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={handleCloseModals}
              className="absolute inset-0 bg-black/75 backdrop-blur-xs"
            />

            {/* Dynamic Modal Cards */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 15 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0, y: 15 }}
              className="relative w-full max-w-sm max-h-[90vh] bg-white rounded-2xl shadow-2xl border border-gray-100 z-10 flex flex-col overflow-hidden"
            >
              {/* Header */}
              <div className="p-4 border-b border-gray-100 bg-gray-50 flex items-center justify-between text-left shrink-0">
                <h3 className="font-extrabold text-sm uppercase tracking-wider text-gray-800">
                  {activeModal === 'vModal' && 'Account details verified'}
                  {activeModal === 'profileModal' && 'Player Profile'}
                  {activeModal === 'errorModal' && 'Access Denied'}
                  {activeModal === 'guideModal' && 'Player UID Guide'}
                  {activeModal === 'cancelModal' && '⚠️ Transaction Incomplete'}
                  {activeModal === 'reviewAlertModal' && 'Authentication Required'}
                  {activeModal === 'helpCenterModal' && 'Help & Support Center'}
                  {activeModal === 'loginModal' && 'Sign In Player Profile'}
                </h3>
                <button
                  onClick={handleCloseModals}
                  className="p-1 rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-100 cursor-pointer transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Body Content */}
              <div className="p-5 text-left text-xs sm:text-sm text-gray-500 font-semibold space-y-4 overflow-y-auto flex-1">
                {/* 1. vModal (Player Verification summary details) */}
                {activeModal === 'vModal' && playerData && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between border-b border-gray-50 pb-2">
                        <span>Nickname</span>
                        <span className="font-black text-gray-800 uppercase flex items-center gap-1">
                          <img
                            src={`https://gatway-seven.vercel.app/gateway?img=${playerData.basicInfo.headPic || '902000162'}`}
                            alt="Avatar"
                            loading="lazy"
                            decoding="async"
                            className="w-5 h-5 rounded-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = '/assets/icon.png';
                            }}
                          />
                          {playerData.basicInfo.nickname}
                        </span>
                      </div>
                      <div className="flex items-center justify-between border-b border-gray-50 pb-2">
                        <span>Player UID</span>
                        <span className="font-bold text-gray-800">{playerData.basicInfo.accountId || uid}</span>
                      </div>
                      <div className="flex items-center justify-between border-b border-gray-50 pb-2">
                        <span>Server Region</span>
                        <span className="font-bold text-gray-800 uppercase">{playerRegion}</span>
                      </div>
                      <div className="flex items-center justify-between border-b border-gray-50 pb-2">
                        <span>Level</span>
                        <span className="font-bold text-gray-800">{playerData.basicInfo.level}</span>
                      </div>
                      <div className="flex items-center justify-between border-b border-gray-50 pb-2">
                        <span>Likes</span>
                        <span className="font-bold text-emerald-600 flex items-center gap-1">
                          <Heart className="w-3.5 h-3.5 fill-emerald-500 text-emerald-500" />
                          {(playerData.basicInfo.liked || 0).toLocaleString()}
                        </span>
                      </div>
                    </div>

                    {/* Bio signature */}
                    <div className="space-y-1">
                      <p className="text-[10px] text-gray-400 uppercase tracking-wider">Player Signature</p>
                      <p className="bg-gray-50 p-2.5 rounded-lg text-xs italic font-medium text-gray-500 border border-gray-100">
                        "{playerData.socialInfo?.signature || 'No Signature Set'}"
                      </p>
                    </div>

                    {/* Clothes inventory equipped grid */}
                    {playerData.profileInfo?.clothes && playerData.profileInfo.clothes.length > 0 && (
                      <div className="space-y-1.5">
                        <p className="text-[10px] text-gray-400 uppercase tracking-wider">Equipped Items</p>
                        <div className="grid grid-cols-4 gap-2">
                          {playerData.profileInfo.clothes.map((id, index) => (
                            <div 
                              key={index} 
                              className="bg-gray-50 p-1 rounded-lg border border-gray-100 aspect-square overflow-hidden flex items-center justify-center"
                            >
                              <img
                                src={`https://gatway-seven.vercel.app/gateway?img=${id}`}
                                alt="Equipped Item"
                                loading="lazy"
                                decoding="async"
                                className="w-full h-full object-contain"
                                onError={(e) => {
                                  (e.target as HTMLDivElement).parentElement!.style.display = 'none';
                                }}
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    <button
                      onClick={() => {
                        handleCloseModals();
                        navigateTo('diamond');
                      }}
                      className="w-full bg-[#ee2c24] hover:bg-red-600 text-white font-extrabold py-3.5 px-4 rounded-xl text-xs uppercase tracking-wider shadow-md shadow-red-500/15 cursor-pointer flex items-center justify-center gap-1"
                    >
                      Continue
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                )}

                {/* 2. profileModal (Full account parameters lookup click) */}
                {activeModal === 'profileModal' && playerData && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between border-b border-gray-50 pb-2">
                        <span>Gamer Handle</span>
                        <span className="font-black text-[#ee2c24]">{playerData.basicInfo.nickname}</span>
                      </div>
                      <div className="flex items-center justify-between border-b border-gray-50 pb-2">
                        <span>Gamer Level</span>
                        <span className="font-bold text-gray-800">{playerData.basicInfo.level}</span>
                      </div>
                      <div className="flex items-center justify-between border-b border-gray-50 pb-2">
                        <span>Server Region</span>
                        <span className="font-bold text-gray-800 uppercase">{playerRegion}</span>
                      </div>
                      <div className="flex items-center justify-between border-b border-gray-50 pb-2">
                        <span>Total Likes</span>
                        <span className="font-bold text-gray-800">👍 {(playerData.basicInfo.liked || 0).toLocaleString()}</span>
                      </div>
                      <div className="flex items-center justify-between border-b border-gray-50 pb-2">
                        <span>Guild Affiliation</span>
                        <span className="font-bold text-[#ee2c24] uppercase">
                          {playerData.clanBasicInfo?.clanName || 'No Guild Affiliation'}
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-col gap-2">
                      <button
                        onClick={handleCloseModals}
                        className="w-full bg-gray-50 hover:bg-gray-100 text-gray-700 font-bold py-3 rounded-xl text-xs uppercase tracking-wide cursor-pointer border border-gray-200"
                      >
                        Close Profile
                      </button>
                      <button
                        onClick={() => {
                          handleCloseModals();
                          handleLogout();
                        }}
                        className="w-full bg-red-50 hover:bg-red-100 text-[#ee2c24] border border-red-100 font-bold py-3 rounded-xl text-xs uppercase tracking-wide cursor-pointer transition-colors"
                      >
                        Logout Session
                      </button>
                    </div>
                  </div>
                )}

                {/* 3. errorModal (Account lookup warning alert) */}
                {activeModal === 'errorModal' && (
                  <div className="text-center space-y-4 pt-1">
                    <div className="p-2.5 bg-red-50 text-[#ee2c24] rounded-full inline-block">
                      <AlertTriangle className="w-10 h-10 animate-bounce" />
                    </div>
                    <p className="text-xs font-semibold text-gray-500 leading-relaxed">
                      {errorMessage}
                    </p>
                    <div className="bg-gray-50 border border-gray-100 p-3 rounded-lg text-[10px] text-gray-400 font-bold uppercase tracking-wider text-center">
                      Verify Server Region &amp; UID parameters carefully.
                    </div>
                    <button
                      onClick={handleCloseModals}
                      className="w-full bg-[#ee2c24] hover:bg-red-600 text-white font-extrabold py-3 rounded-xl text-xs uppercase tracking-wider shadow-md shadow-red-500/10 cursor-pointer"
                    >
                      Try Again
                    </button>
                  </div>
                )}

                {/* 4. guideModal (How to find UID popup image) */}
                {activeModal === 'guideModal' && (
                  <div className="space-y-4 text-left">
                    <img
                      src={ffUidGuideImg}
                      alt="UID Location Guide screenshot"
                      loading="lazy"
                      decoding="async"
                      className="w-full rounded-xl border border-gray-200 shadow-xs"
                    />
                    <div className="bg-gray-50 p-3.5 rounded-xl border border-gray-100 space-y-2 text-xs text-gray-600 font-semibold leading-relaxed">
                      <p className="font-extrabold text-gray-800 text-xs">How to find your Player UID:</p>
                      <ul className="list-decimal list-inside space-y-1.5 text-[11px]">
                        <li>Open the Free Fire game on your mobile device.</li>
                        <li>Tap your player profile avatar card in the top-left corner of the main lobby screen.</li>
                        <li>Under your nickname, you will find your <b>UID / Player ID</b> (e.g., 123456789).</li>
                        <li>Click the small <b>Copy</b> button next to the ID number and paste it in the box on this website to login.</li>
                      </ul>
                    </div>
                    <button
                      onClick={handleCloseModals}
                      className="w-full bg-[#ee2c24] hover:bg-red-600 text-white font-extrabold py-3 rounded-xl text-xs uppercase tracking-wider shadow-md cursor-pointer"
                    >
                      Got It, Back to Login
                    </button>
                  </div>
                )}

                {/* 5. cancelModal (Warning if payment is not completed) */}
                {activeModal === 'cancelModal' && (
                  <div className="text-center space-y-4">
                    <div className="p-2.5 bg-amber-50 text-amber-500 rounded-full inline-block">
                      <AlertTriangle className="w-10 h-10 animate-pulse" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-base font-black text-gray-900 tracking-tight leading-none uppercase">Cart is waiting</h4>
                      <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Double rewards promotion is active</p>
                    </div>
                    <p className="text-xs font-semibold text-gray-500 leading-relaxed max-w-sm">
                      Your <b className="text-[#ee2c24] uppercase font-black">Double Diamonds</b> are currently locked in the queue waiting for checkout approval! Complete topup to authorize immediate transfer.
                    </p>
                    <div className="flex gap-2.5 pt-1.5">
                      <button
                        onClick={handleCloseModals}
                        className="flex-1 bg-gray-50 hover:bg-gray-100 text-gray-500 font-bold py-3 rounded-xl text-xs uppercase tracking-wide cursor-pointer border border-gray-200"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => {
                          handleCloseModals();
                          navigateTo('diamond');
                        }}
                        className="flex-1 bg-[#ee2c24] hover:bg-red-600 text-white font-extrabold py-3 rounded-xl text-xs uppercase tracking-wider shadow-md cursor-pointer"
                      >
                        Try Again
                      </button>
                    </div>
                  </div>
                )}

                {/* 6. reviewAlertModal (Constraint when trying to write reviews without topups) */}
                {activeModal === 'reviewAlertModal' && (
                  <div className="text-center space-y-4">
                    <div className="p-2.5 bg-rose-50 text-[#ee2c24] rounded-full inline-block">
                      <AlertTriangle className="w-10 h-10" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-base font-black text-gray-800">Review Rejected</h4>
                      <p className="text-[10px] text-gray-400 font-black tracking-widest uppercase">First Time Verification Block</p>
                    </div>
                    <p className="text-xs font-semibold text-gray-500 leading-relaxed">
                      Dear Player! Our anti-spam protocols restrict testimonial submissions to verified buyers only. Please execute a topup transaction first to register feedback.
                    </p>
                    <button
                      onClick={() => {
                        handleCloseModals();
                        navigateTo('home');
                      }}
                      className="w-full bg-[#ee2c24] hover:bg-red-600 text-white font-extrabold py-3 rounded-xl text-xs uppercase tracking-wider shadow-md cursor-pointer"
                    >
                      Authenticate Now
                    </button>
                  </div>
                )}

                {/* 7. helpCenterModal (Customer support contacts details) */}
                {activeModal === 'helpCenterModal' && (
                  <div className="space-y-4 text-left">
                    <p className="text-xs font-semibold text-gray-500 leading-relaxed">
                      For instant questions, transaction support, or payment tracking, join our customer support channels:
                    </p>

                    <div className="space-y-3 pt-1">
                      <div className="flex items-center gap-3">
                        <div className="shrink-0">
                          <svg viewBox="0 0 24 24" className="w-8 h-8">
                            <path fill="#EA4335" d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2z" />
                            <path fill="#FBBC05" d="M22 6v12c0 1.1-.9 2-2 2h-4V8l6-4z" />
                            <path fill="#34A853" d="M2 6v12c0 1.1.9 2 2 2h4V8l-6-4z" />
                            <path fill="#4285F4" d="M20 4H4c-1.1 0-2 .9-2 2v2l10 6 10-6V6c0-1.1-.9-2-2-2z" />
                            <path fill="#1A73E8" d="M12 14L2 8v10c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8l-10 6z" />
                          </svg>
                        </div>
                        <div>
                          <p className="text-[10px] font-bold text-gray-400 uppercase leading-none">Email Address</p>
                          <a 
                            href="mailto:contactgarenaffmax@gmail.com" 
                            className="text-xs font-black text-[#ee2c24] hover:underline break-all"
                          >
                            contactgarenaffmax@gmail.com
                          </a>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="shrink-0">
                          <svg viewBox="0 0 24 24" className="w-8 h-8">
                            <path fill="#25D366" d="M12.012 2c-5.506 0-9.989 4.478-9.99 9.984a9.96 9.96 0 0 0 1.335 4.993L2 22l5.13-1.343a9.92 9.92 0 0 0 4.881 1.28c5.505 0 9.988-4.478 9.989-9.983c0-2.668-1.039-5.176-2.927-7.064C17.185 3.003 14.68 2 12.012 2z" />
                            <path fill="#FFF" d="M12.012 3.513c-4.66 0-8.453 3.792-8.454 8.453a8.41 8.41 0 0 0 1.127 4.22l-.12-.343-.65 2.373 2.435-.64.316.188a8.383 8.383 0 0 0 4.148 1.104c4.661 0 8.454-3.79 8.455-8.45a8.4 8.4 0 0 0-2.474-5.975 8.4 8.4 0 0 0-5.974-2.474zm4.845 11.233c-.266.748-1.54 1.37-2.11 1.422-.443.044-1.772.443-3.755-1.196-1.64-1.353-2.67-3.08-3.08-3.657-.41-.576-.73-1.286-.73-1.995 0-1.352.7-2.016.942-2.27.189-.2.51-.277.732-.277.09 0 .177.011.255.011.21.011.343.022.487.32.178.41.62 1.507.665 1.607.045.1.077.22.01.354-.066.133-.1.222-.2.332-.1.11-.21.255-.3.343-.1.1-.21.21-.09.42.122.21.543.898 1.163 1.45.798.71 1.472.93 1.683 1.03.21.1.332-.09.454-.233.133-.155.576-.675.731-.908.156-.233.31-.19.52-.1.21.09 1.33.632 1.552.743.22.11.365.166.42.266.056.1.056.576-.177 1.23z" />
                          </svg>
                        </div>
                        <div>
                          <p className="text-[10px] font-bold text-gray-400 uppercase leading-none">WhatsApp Channel</p>
                          <a 
                            href="https://whatsapp.com/channel/0029Vb8HTPiBqbr03gj1P03H" 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="text-xs font-black text-emerald-600 hover:underline"
                          >
                            Join Community Channel →
                          </a>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="shrink-0">
                          <svg viewBox="0 0 24 24" className="w-8 h-8" fill="#229ED9">
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 0 0-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.37.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z"/>
                          </svg>
                        </div>
                        <div>
                          <p className="text-[10px] font-bold text-gray-400 uppercase leading-none">Telegram Channel</p>
                          <a 
                            href="https://t.me/garenaofficialindmax" 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="text-xs font-black text-sky-600 hover:underline"
                          >
                            Join Telegram Channel →
                          </a>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={handleCloseModals}
                      className="w-full bg-gray-50 hover:bg-gray-100 text-gray-700 font-bold py-3 rounded-xl text-xs uppercase tracking-wide cursor-pointer border border-gray-200 mt-2"
                    >
                      Close Help Desk
                    </button>
                  </div>
                )}

                {/* 8. loginModal (Header Login Popup to Enter Player UID) */}
                {activeModal === 'loginModal' && (
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 text-gray-800 font-extrabold text-sm mb-1">
                      <span className="flex items-center justify-center bg-[#ee2c24] text-white w-5 h-5 rounded-md font-bold text-xs">
                        1
                      </span>
                      Sign In Player Profile
                    </div>

                    <form onSubmit={handleHeaderLogin} className="space-y-4 text-left">
                      {/* Region Select */}
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Server Region</label>
                        <select
                          value={loginRegion}
                          onChange={(e) => setLoginRegion(e.target.value)}
                          disabled={loginLoading}
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-gray-700 outline-none focus:border-[#ee2c24] transition-colors cursor-pointer"
                        >
                          {REGIONS_MAP.map((reg) => (
                            <option key={reg.value} value={reg.value}>
                              {reg.label}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* UID Input */}
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Player UID</label>
                          <button
                            type="button"
                            onClick={() => {
                              handleCloseModals();
                              handleOpenUIDGuide();
                            }}
                            className="text-[10px] text-[#ee2c24] font-bold flex items-center gap-1 cursor-pointer hover:underline"
                          >
                            <HelpCircle className="w-3 h-3" />
                            Find UID Guide
                          </button>
                        </div>
                        
                        <div className="flex gap-2">
                          <input
                            type="number"
                            placeholder="Enter Player UID"
                            value={loginUid}
                            onChange={(e) => setLoginUid(e.target.value)}
                            disabled={loginLoading}
                            className="flex-1 min-w-0 bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-gray-800 outline-none focus:border-[#ee2c24] transition-colors"
                          />
                          <button
                            type="submit"
                            disabled={loginLoading || !loginUid.trim()}
                            className="bg-[#ee2c24] hover:bg-red-600 disabled:bg-red-300 text-white font-extrabold px-5 rounded-xl transition-all shadow-sm flex items-center justify-center gap-1.5 cursor-pointer text-xs"
                          >
                            {loginLoading ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              'Verify'
                            )}
                          </button>
                        </div>
                      </div>
                    </form>

                    {/* Status Line */}
                    {loginStatusMessage && (
                      <div className="text-center pt-1 border-t border-gray-50">
                        <p className="text-[10px] font-bold text-emerald-600 animate-pulse flex items-center justify-center gap-1">
                          <Sparkles className="w-3.5 h-3.5" />
                          {loginStatusMessage}
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
    </>
  );
}
