import { motion } from 'motion/react';
import { ShieldAlert, Users, Zap, Terminal, AlertCircle, CheckSquare } from 'lucide-react';

export default function AntiFraud() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-6 text-left"
    >
      {/* Editorial Header */}
      <div className="space-y-2">
        <span className="text-[10px] font-black tracking-widest text-[#ee2c24] uppercase">Legal Desk</span>
        <h2 className="text-xl sm:text-2xl font-black text-gray-900 tracking-tight leading-tight">Anti-Fraud &amp; Abuse Prevention</h2>
        <p className="text-[10px] font-bold text-gray-400">Last Updated: July 5, 2026</p>
      </div>

      <div className="bg-red-950 border border-red-800 rounded-xl p-4 text-xs font-semibold text-red-200 leading-relaxed flex gap-3">
        <ShieldAlert className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold uppercase tracking-wider block mb-1 text-red-100">🔴 Zero Tolerance Policy</span>
          We maintain an absolute zero-tolerance policy toward all forms of fraud, abuse, manipulation, and misuse of our Platform. All violations are actively investigated, logged, and prosecuted to the full extent of applicable laws.
        </div>
      </div>

      <div className="bg-white rounded-xl p-5 border border-gray-100 shadow-xs space-y-6 text-xs sm:text-sm text-gray-600 font-semibold leading-relaxed">
        
        {/* Section 1 */}
        <div className="space-y-3">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-[#ee2c24]" />
            SECTION 1 — ACTS CONSTITUTING FRAUD OR ABUSE
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pl-6 border-l-2 border-gray-100">
            <div className="space-y-1">
              <span className="text-gray-900 font-bold block text-xs uppercase tracking-wide">1.1 Payment Fraud</span>
              <p className="text-[11px] text-gray-500">Using stolen cards, unauthorized UPI handles, or banking credentials obtained through fraudulent schemes or phishing.</p>
            </div>
            <div className="space-y-1">
              <span className="text-gray-900 font-bold block text-xs uppercase tracking-wide">1.2 Chargeback Abuse</span>
              <p className="text-[11px] text-gray-500">Filing a chargeback with your bank after receiving diamonds, claiming "unauthorized charge" or "non-delivery" fraudulently.</p>
            </div>
            <div className="space-y-1">
              <span className="text-gray-900 font-bold block text-xs uppercase tracking-wide">1.3 Promotional Abuse</span>
              <p className="text-[11px] text-gray-500">Using multiple UIDs, disposable email addresses, or VPNs to claim limited promotions repeatedly.</p>
            </div>
            <div className="space-y-1">
              <span className="text-gray-900 font-bold block text-xs uppercase tracking-wide">1.4 Identity Fraud</span>
              <p className="text-[11px] text-gray-500">Impersonating support staff, using false email handles, or spoofing credentials during legal claims.</p>
            </div>
            <div className="space-y-1 col-span-1 sm:col-span-2">
              <span className="text-gray-900 font-bold block text-xs uppercase tracking-wide">1.5 Technical &amp; Screen Abuse</span>
              <p className="text-[11px] text-gray-500">Using bots/automated scripts, attempting SQL injections or XSS, exploiting software bugs instead of reporting them, or submitting fabricated screenshot documents.</p>
            </div>
          </div>
        </div>

        {/* Section 2 */}
        <div className="space-y-3 pt-4 border-t border-gray-50">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <Terminal className="w-4 h-4 text-purple-500" />
            SECTION 2 — FRAUD DETECTION SYSTEMS
          </h3>
          <p className="pl-6 border-l-2 border-gray-100">
            We employ multi-layered detection systems running continuously:
          </p>
          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 pl-6">
            <li className="bg-gray-50 p-2 rounded-lg border border-gray-100 text-xs text-gray-500">
              💻 <span className="font-bold text-gray-800">Device Fingerprinting:</span> Identifies repeat checkouts targeting different UIDs from a single terminal.
            </li>
            <li className="bg-gray-50 p-2 rounded-lg border border-gray-100 text-xs text-gray-500">
              🌐 <span className="font-bold text-gray-800">IP Reputation Analysis:</span> Screens orders from known high-risk proxies, VPNs, or Tor endpoints.
            </li>
            <li className="bg-gray-50 p-2 rounded-lg border border-gray-100 text-xs text-gray-500">
              ⚡ <span className="font-bold text-gray-800">Velocity Monitoring:</span> Flags rapid transaction intervals from a single payee address.
            </li>
            <li className="bg-gray-50 p-2 rounded-lg border border-gray-100 text-xs text-gray-500">
              🔍 <span className="font-bold text-gray-800">UTR Real-time Checks:</span> Direct api checks cross-referencing UTRs to block fabricated confirmations.
            </li>
          </ul>
        </div>

        {/* Section 3 - Tier Breakdown */}
        <div className="space-y-3 pt-4 border-t border-gray-50">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <Users className="w-4 h-4 text-orange-500" />
            SECTION 3 — CONSEQUENCES BY TIER
          </h3>
          <div className="space-y-3 pl-6 border-l-2 border-gray-100 text-xs">
            <div className="p-3 bg-amber-50/50 rounded-lg border border-amber-100">
              <span className="font-bold text-amber-800 block uppercase">🟡 TIER 1 — LOW RISK / FIRST OFFENSE</span>
              <span className="text-gray-500 text-[11px]">Forgot to attach UTR, or minor procedure misunderstanding. Trigger: Friendly warning issued, transaction held for manual verification.</span>
            </div>
            <div className="p-3 bg-orange-50/50 rounded-lg border border-orange-100">
              <span className="font-bold text-orange-800 block uppercase">🟠 TIER 2 — MODERATE RISK / CLEAR POLICY BREACH</span>
              <span className="text-gray-500 text-[11px]">Repeated promotional abuse, fake email entries, or harassing support staff. Trigger: Permanent blacklist of UID, email, payment card, and device fingerprint.</span>
            </div>
            <div className="p-3 bg-red-50/50 rounded-lg border border-red-100">
              <span className="font-bold text-red-800 block uppercase">🔴 TIER 3 — HIGH RISK / CRIMINAL CONDUCT</span>
              <span className="text-gray-500 text-[11px]">Stolen card checkout, chargeback fraud, fabricated proof documents, hacking attempts, or threat calls. Trigger: Immediate permanent blacklist and filing a formal complaint with the Cyber Crime Cell and payment gate networks for civil recovery.</span>
            </div>
          </div>
        </div>

        {/* Section 4 & 5 */}
        <div className="space-y-3 pt-4 border-t border-gray-50">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <Zap className="w-4 h-4 text-emerald-500" />
            SECTION 4, 5 &amp; 6 — BLACKLIST, BOUNTY &amp; UNRECOGNIZED CHARGES
          </h3>
          <div className="space-y-2.5 pl-6 border-l-2 border-gray-100">
            <p>
              <span className="text-gray-900 font-bold block">Permanent Blacklist Structure</span>
              Once blacklisted, all related identifiers (Email, UID, IP subnets, Device Tokens, payment details) are locked. Attempts to circumvent will escalate to criminal referral.
            </p>
            <p>
              <span className="text-gray-900 font-bold block">Bug Bounty &amp; Disclosure</span>
              If you discover any technical loopholes or bugs, do not exploit them. Report them via the Contact form. Responsible good-faith disclosures will be recognized and are immune to legal actions.
            </p>
            <p>
              <span className="text-gray-900 font-bold block">Unrecognized Card Charges</span>
              If you detect unauthorized charges originating from our platform on your bank statement, contact us immediately. We will freeze any pending delivery linked to that payment and coordinate with your bank risk team to reverse funds.
            </p>
          </div>
        </div>

        {/* Support email contact */}
        <div className="pt-4 border-t border-gray-50 text-[11px] text-gray-400">
          For further questions or inquiries, please contact our Legal department at <a href="mailto:contactgarenaffmax@gmail.com" className="text-[#ee2c24] underline">contactgarenaffmax@gmail.com</a>.
        </div>
      </div>
    </motion.div>
  );
}
