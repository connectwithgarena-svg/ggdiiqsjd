import { motion } from 'motion/react';
import { 
  Shield, 
  Zap, 
  Award, 
  HelpCircle, 
  Mail, 
  MessageCircle, 
  Clock, 
  Users, 
  Sparkles, 
  CheckCircle,
  AlertTriangle,
  Lock,
  Globe,
  Star,
  Phone,
  ArrowRight,
  TrendingUp,
  FileText
} from 'lucide-react';

export default function About() {
  const diffs = [
    {
      icon: <Zap className="w-5 h-5 text-amber-500" />,
      title: '⚡ Instant Delivery — Always',
      desc: 'The moment your payment is confirmed, diamonds are credited to your Free Fire account automatically. No waiting. No manual processing. No follow-up needed. Our fully automated delivery system works 24 hours a day, 7 days a week, 365 days a year — including holidays.'
    },
    {
      icon: <Sparkles className="w-5 h-5 text-blue-500" />,
      title: '💎 100% Genuine Diamonds',
      desc: 'Every diamond delivered through our platform is 100% genuine and safe. We use only verified top-up channels. Your account faces zero risk of ban, suspension, or flag. We never ask for your password — only your Player UID.'
    },
    {
      icon: <Lock className="w-5 h-5 text-emerald-500" />,
      title: '🔒 Completely Secure',
      desc: 'Your safety is our top priority. All transactions are processed through SSL-encrypted, PCI-DSS certified payment gateways. We never store your card details, OTPs, or banking credentials. Every payment is fully encrypted from start to finish.'
    },
    {
      icon: <TrendingUp className="w-5 h-5 text-red-500" />,
      title: '💰 Best Prices in India',
      desc: 'We offer the most competitive diamond rates available. With our exclusive 100% Double Diamond Bonus, you get twice the diamonds for the same price — something you will not find anywhere else. Our pricing is always transparent — no hidden fees, no surprise charges.'
    },
    {
      icon: <Shield className="w-5 h-5 text-rose-500" />,
      title: '🛡️ Zero Ban Risk',
      desc: 'Many players worry about account safety when using third-party top-up services. With us, you never have to worry. We only use your in-game Player UID for delivery — your account login credentials are never touched. Thousands of players top up with us daily without a single ban.'
    },
    {
      icon: <Phone className="w-5 h-5 text-purple-500" />,
      title: '📞 Real Human Support',
      desc: 'We have a dedicated customer support team available every day. Whether you have a payment question, a delivery concern, or need help with your UID — our team responds fast and resolves your issue, not just sends auto-replies.'
    }
  ];

  const numbers = [
    { label: 'Orders Completed', icon: '✅', value: '5,00,000+' },
    { label: 'Average Delivery Time', icon: '⚡', value: 'Under 30 Seconds' },
    { label: 'Players Served', icon: '🌍', value: '1,00,000+' },
    { label: 'Customer Satisfaction', icon: '⭐', value: '98.7%' },
    { label: 'Fraud Incidents', icon: '🔒', value: 'Zero' },
    { label: 'Support Response Time', icon: '📞', value: 'Under 30 Minutes' },
    { label: 'Uptime', icon: '🕐', value: '99.9%' }
  ];

  const steps = [
    {
      num: 'Step 1',
      title: 'Login With Your UID',
      desc: 'Enter your Free Fire Player UID. Our system instantly fetches your in-game name and level from the live server — you can verify it\'s your account before paying a single rupee.'
    },
    {
      num: 'Step 2',
      title: 'Choose Your Package',
      desc: 'Select the diamond package that fits your budget. All packages come with our exclusive 100% Bonus — you always get double the diamonds. Prices start from as low as ₹79.'
    },
    {
      num: 'Step 3',
      title: 'Pay & Get Diamonds Instantly',
      desc: 'Complete your payment through UPI, debit card, credit card, or net banking. The moment payment is confirmed, diamonds are automatically added to your account. You will see them in your Free Fire wallet instantly.'
    }
  ];

  const commitments = [
    { emoji: '🤝', title: 'Honesty', desc: 'We never make false claims. What you see is what you get. The price displayed is the price you pay. The diamonds shown are the diamonds you receive.' },
    { emoji: '🔄', title: 'Reliability', desc: 'Our platform is built to handle thousands of orders simultaneously without delays. Whether it is 2 PM or 2 AM, your order is processed instantly.' },
    { emoji: '🛡️', title: 'Security', desc: 'We invest heavily in platform security, fraud prevention, and payment encryption. Your data is never sold, shared, or misused.' },
    { emoji: '💬', title: 'Transparency', desc: 'Our policies are written clearly and honestly. Our pricing has no hidden fees. Our support team gives you straight answers.' },
    { emoji: '🎮', title: 'Community', desc: 'We are part of the Free Fire community. We celebrate the game, support players, and grow together. Your success in the game is our success.' }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-10 text-left max-w-4xl mx-auto pb-12"
    >
      {/* Title Header */}
      <div className="border-b border-gray-100 pb-5">
        <div className="flex items-center gap-2 mb-1.5">
          <span className="text-xl sm:text-2xl">🏆</span>
          <span className="text-[11px] font-black tracking-widest text-[#ee2c24] uppercase">GGDIAMOND.SHOP</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 tracking-tight leading-tight">
          About Us — Free Fire Diamond Top-Up
        </h1>
      </div>

      {/* Who We Are & Story */}
      <div className="space-y-6">
        <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs space-y-4">
          <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2 border-b border-gray-50 pb-2">
            <span className="w-1.5 h-4.5 bg-[#ee2c24] rounded-full inline-block"></span>
            Who We Are
          </h2>
          <p className="text-xs sm:text-[13px] font-semibold text-gray-600 leading-relaxed">
            Welcome to <strong className="text-gray-900">ggdiamond.shop</strong> — India's fastest, safest, and most trusted Free Fire &amp; Free Fire MAX diamond top-up platform. We are a dedicated team of gaming enthusiasts who understand exactly what players need: instant delivery, cheap FF MAX diamonds, 100% double bonus, zero complications, and unbeatable value.
          </p>
          <p className="text-xs sm:text-[13px] font-semibold text-gray-600 leading-relaxed">
            We are not just a top-up service. We are gamers ourselves. We have spent countless hours on the battlefield, we understand the frustration of running out of diamonds mid-season, and we built this platform specifically to solve that problem — fast, affordable, and reliable.
          </p>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs space-y-4">
          <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2 border-b border-gray-50 pb-2">
            <span className="w-1.5 h-4.5 bg-[#ee2c24] rounded-full inline-block"></span>
            Our Story
          </h2>
          <p className="text-xs sm:text-[13px] font-semibold text-gray-600 leading-relaxed">
            ggdiamond.shop was born out of a simple idea: every Free Fire and Free Fire MAX player deserves easy access to affordable diamonds without hassle.
          </p>
          <p className="text-xs sm:text-[13px] font-semibold text-gray-600 leading-relaxed">
            We saw players struggling with complicated top-up processes, high prices, delayed deliveries, and untrustworthy platforms. So we decided to build something better — a clean, simple, and honest top-up experience that puts the player first.
          </p>
          <p className="text-xs sm:text-[13px] font-semibold text-gray-600 leading-relaxed">
            Since our launch, we have served hundreds of thousands of players across India and South Asia. From casual players to competitive eSports warriors, our platform has become the go-to destination for Free Fire diamond top-ups.
          </p>
        </div>
      </div>

      {/* What Makes Us Different */}
      <div className="space-y-5">
        <h3 className="text-xl font-extrabold text-gray-900 tracking-tight">
          What Makes Us Different
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {diffs.map((item, idx) => (
            <div key={idx} className="bg-white rounded-xl p-5 border border-gray-100 shadow-xs space-y-2.5">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-gray-50 rounded-lg inline-block">
                  {item.icon}
                </div>
                <h4 className="text-[13px] font-extrabold text-gray-900">{item.title}</h4>
              </div>
              <p className="text-xs font-semibold text-gray-500 leading-relaxed">
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Numbers Section with Light-Themed Table resembling photo */}
      <div className="space-y-4">
        <h3 className="text-xl font-extrabold text-gray-900 tracking-tight">
          Our Numbers Speak For Us
        </h3>
        
        <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-xs max-w-lg">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200 text-left">
                <th className="py-3 px-4 text-xs font-black text-gray-700 tracking-wider w-1/2">
                  Metric
                </th>
                <th className="py-3 px-4 text-xs font-black text-gray-700 tracking-wider text-right w-1/2">
                  Achievement
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {numbers.map((num, idx) => (
                <tr key={idx} className="hover:bg-gray-50/50 transition-colors">
                  <td className="py-3 px-4 text-xs font-bold text-gray-800 flex items-center gap-2">
                    <span className="inline-block text-base">{num.icon}</span>
                    {num.label}
                  </td>
                  <td className="py-3 px-4 text-xs font-black text-gray-900 text-right">
                    {num.value}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* How It Works */}
      <div className="space-y-5">
        <h3 className="text-xl font-extrabold text-gray-900 tracking-tight">
          How It Works — Simple 3 Steps
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {steps.map((item, idx) => (
            <div key={idx} className="bg-white rounded-xl p-5 border border-gray-100 shadow-xs space-y-2 relative overflow-hidden">
              <span className="absolute top-2 right-3 text-[10px] font-black text-gray-200 uppercase tracking-widest">
                {item.num}
              </span>
              <h4 className="text-xs font-black text-gray-800 uppercase tracking-wider">
                {item.title}
              </h4>
              <p className="text-xs font-semibold text-gray-500 leading-relaxed mt-1">
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Our Commitment To You */}
      <div className="space-y-5">
        <h3 className="text-xl font-extrabold text-gray-900 tracking-tight">
          Our Commitment To You
        </h3>
        <p className="text-xs sm:text-[13px] font-semibold text-gray-500 leading-relaxed">
          We make these promises to every player who trusts us:
        </p>
        <div className="bg-white rounded-2xl border border-gray-100 divide-y divide-gray-50 overflow-hidden shadow-xs">
          {commitments.map((com, idx) => (
            <div key={idx} className="p-5 flex gap-4 items-start">
              <span className="text-2xl mt-0.5">{com.emoji}</span>
              <div className="space-y-1">
                <h4 className="text-[13px] font-extrabold text-gray-900">{com.title}</h4>
                <p className="text-xs font-semibold text-gray-500 leading-relaxed">{com.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Supported Payment Methods */}
      <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs space-y-4">
        <h3 className="text-lg font-bold text-gray-800 flex items-center gap-2 border-b border-gray-50 pb-2">
          <span className="w-1.5 h-4.5 bg-[#ee2c24] rounded-full inline-block"></span>
          Payment Methods We Support
        </h3>
        <p className="text-xs sm:text-[13px] font-semibold text-gray-600 leading-relaxed">
          We accept all major payment methods available in India:
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 mt-2">
          <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 text-xs font-bold text-gray-700 flex items-center gap-2">
            <span>📱</span> <strong>UPI</strong> — GPay, PhonePe, Paytm, BHIM, Amazon Pay
          </div>
          <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 text-xs font-bold text-gray-700 flex items-center gap-2">
            <span>💳</span> <strong>Debit Cards</strong> — Visa, Mastercard, RuPay
          </div>
          <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 text-xs font-bold text-gray-700 flex items-center gap-2">
            <span>💳</span> <strong>Credit Cards</strong> — Visa, Mastercard, Amex
          </div>
          <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 text-xs font-bold text-gray-700 flex items-center gap-2">
            <span>🏦</span> <strong>Net Banking</strong> — All major Indian banks
          </div>
        </div>
        <p className="text-[11px] text-gray-400 font-bold leading-relaxed pt-1 flex items-center gap-1.5">
          <span>🔒</span> All transactions are secured by industry-leading encryption and processed by trusted, certified payment partners.
        </p>
      </div>

      {/* Legal & Compliance */}
      <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs space-y-4">
        <h3 className="text-lg font-bold text-gray-800 flex items-center gap-2 border-b border-gray-50 pb-2">
          <span className="w-1.5 h-4.5 bg-[#ee2c24] rounded-full inline-block"></span>
          Legal & Compliance
        </h3>
        <p className="text-xs sm:text-[13px] font-semibold text-gray-600 leading-relaxed">
          GGDIAMOND operates as an independent digital goods reseller. We are fully compliant with:
        </p>
        <ul className="list-disc pl-5 text-xs font-semibold text-gray-500 space-y-1">
          <li>Information Technology Act, 2000</li>
          <li>Consumer Protection Act, 2019</li>
          <li>Payment and Settlement Systems Act, 2007</li>
          <li>Digital Personal Data Protection Act, 2023 (DPDPA)</li>
          <li>Goods and Services Tax Act, 2017</li>
        </ul>
        <p className="text-xs font-semibold text-gray-500 leading-relaxed">
          We maintain complete transparency in our operations and uphold the highest standards of customer data protection.
        </p>
      </div>

      {/* Disclaimer */}
      <div className="bg-orange-50/40 border border-orange-100 rounded-xl p-5 space-y-2">
        <h4 className="text-xs font-bold text-orange-800 flex items-center gap-1.5 uppercase tracking-wider">
          <AlertTriangle className="w-4 h-4 text-orange-600" />
          Disclaimer
        </h4>
        <p className="text-[11px] font-bold text-orange-700 leading-relaxed">
          GGDIAMOND is an independent top-up service. We are not affiliated with, endorsed by, or officially partnered with Garena Online Private Limited. Free Fire and related trademarks are the property of Garena Online Private Limited. Use of these names is for identification purposes only.
        </p>
      </div>


      {/* Message From Team */}
      <div className="bg-slate-50 border border-slate-200/60 rounded-2xl p-6 relative overflow-hidden flex flex-col gap-2.5">
        <span className="text-6xl text-slate-200 font-serif absolute -top-3 left-3 select-none">“</span>
        <h4 className="text-xs font-extrabold text-gray-800 pl-6 mt-1 uppercase tracking-wider">
          A Message From Our Team
        </h4>
        <p className="text-xs font-bold text-slate-600 italic leading-relaxed pl-6 relative z-10">
          "We built GGDIAMOND because we love Free Fire and we believe every player deserves a safe, affordable, and instant way to power up their game. Every order we fulfill is a player we helped. That means everything to us. Thank you for trusting us — now go win that Booyah!"
        </p>
        <span className="text-[10px] font-black text-[#ee2c24] uppercase tracking-wider pl-6 mt-1 block">
          — The GGDIAMOND Team 🎮
        </span>
      </div>

      {/* Footer copyright for page inside */}
      <p className="text-[11px] text-gray-400 font-bold text-center pt-4">
        © 2024 GGDIAMOND — Instant Free Fire Diamond Top-Up | All Rights Reserved
      </p>
    </motion.div>
  );
}
