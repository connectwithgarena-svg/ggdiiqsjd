import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { HelpCircle, ChevronDown, Search } from 'lucide-react';

interface FAQItem {
  q: string;
  a: string;
}

const FAQ_LIST: FAQItem[] = [
  {
    q: 'What is this website?',
    a: 'GGDIAMOND is an independent top-up service that provides various payment channels to purchase in-game currency for Free Fire and Free Fire MAX. Your in-game currency is delivered instantly and can be used to purchase items inside the game.'
  },
  {
    q: 'How to perform transactions?',
    a: 'You need to login first using your Player UID. Once you have logged in, you can make a purchase using any available payment channel on our website.'
  },
  {
    q: 'How to make payment?',
    a: 'You can pay for top-ups with a wide variety of secure payment methods including UPI, credit and debit cards, eWallets, Netbanking, and more. Select your top-up amount to see which payment methods are available.'
  },
  {
    q: 'How to report any problems mid-transaction?',
    a: 'If you encounter any problems, you can check on the status of your transaction or reach out to us. If the transaction is successful but you have not received your diamonds, please contact our Customer Service directly via the Contact Us page on our website.'
  },
  {
    q: 'Can I file for a refund on my transaction?',
    a: 'Any transaction performed on our platform is final and cannot be refunded in any form. This includes transactions where the user enters an incorrect player UID. Please make sure you verify the verified nickname and account details carefully before topping up.'
  },
  {
    q: 'I encountered "account not found" when logging in. How do I fix the issue?',
    a: 'This error message means that our system cannot find any Player ID or social media platform that you use to login for a specific game. Normally, this occurs when you input the wrong Player ID or use a wrong social media account. Make sure you select the correct server region before logging in.'
  },
  {
    q: 'How long does it take for the diamonds to reflect in my account?',
    a: 'Your diamonds are credited to your Free Fire ID instantly as soon as the payment is successfully completed! Our system is fully automated, so you do not have to wait at all.'
  },
  {
    q: 'Why are diamonds cheaper here, and how are you offering a promo?',
    a: "GGDIAMOND Diamond Top Up provides direct bulk digital distribution value to players! Our main goal is to motivate our players and provide them with the best gaming experience possible. That's why we offer discounted prices. Currently, we are running a special promo where you get a 100% Bonus (Double Diamonds) on every top-up!"
  },
  {
    q: 'Can my Free Fire ID get banned if I top up from this website?',
    a: 'Not at all! This is a 100% Anti-ban and secure process. We only use your in-game Player UID for the top-up; we never ask for your account password.'
  },
  {
    q: 'How do I know that I am topping up the correct account?',
    a: "When you enter your Player UID and click 'Login', our system automatically retrieves your In-Game Name and Level from the live server and displays it on the screen. You can verify your real in-game name before making any payment."
  },
  {
    q: 'What should I keep in mind to avoid fraud while making a payment?',
    a: 'There are many fake websites operating, so always ensure that the UPI or Bank receiver\'s name shows up as a registered merchant like "Free Fire Store" or payment gateway checkout. Never send your payment to an individual\'s personal name.'
  },
  {
    q: 'Will I lose my money if it\'s deducted but I don\'t get diamonds?',
    a: 'No, your money is completely safe! If your payment is deducted but the top-up fails due to a network issue, the full amount will automatically be refunded to your original bank account within 24 to 48 hours.'
  }
];

export default function FAQ() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const filteredFaq = FAQ_LIST.filter(item =>
    item.q.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.a.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-6 text-left"
    >
      {/* Editorial Header */}
      <div className="space-y-2">
        <span className="text-[10px] font-black tracking-widest text-[#ee2c24] uppercase">Support Library</span>
        <h1 className="text-xl sm:text-2xl font-black text-gray-900 tracking-tight leading-tight">
          Frequently Asked Questions — Free Fire Diamond Top-Up
        </h1>
        <p className="text-xs sm:text-sm font-semibold text-gray-500 leading-relaxed">
          Quick answers to inquiries regarding Free Fire diamond delivery timelines, 100% double diamond bonus promos, cheap FF MAX diamond rates, and secure UPI payment options.
        </p>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-gray-400 absolute left-4 top-3" />
        <input
          type="text"
          placeholder="Search for questions, keywords, or guides..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-white border border-gray-100 rounded-xl pl-10 pr-4 py-2.5 text-xs sm:text-sm font-semibold text-gray-800 outline-hidden focus:border-[#ee2c24] shadow-xs"
        />
      </div>

      {/* Accordion List */}
      <div className="space-y-3">
        {filteredFaq.length > 0 ? (
          filteredFaq.map((item, idx) => {
            const isOpen = activeIndex === idx;
            return (
              <div
                key={idx}
                className="bg-white border border-gray-100 rounded-xl overflow-hidden shadow-xs transition-colors"
              >
                <button
                  onClick={() => toggleAccordion(idx)}
                  className="w-full p-4 flex items-center justify-between text-left font-bold text-xs sm:text-sm text-gray-800 hover:text-[#ee2c24] transition-colors cursor-pointer"
                >
                  <span className="flex items-center gap-2.5">
                    <HelpCircle className="w-4.5 h-4.5 text-gray-400 shrink-0" />
                    {item.q}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-gray-400 transition-transform shrink-0 ${
                      isOpen ? 'transform rotate-180 text-[#ee2c24]' : ''
                    }`}
                  />
                </button>

                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2, ease: 'easeInOut' }}
                    >
                      <div className="px-4 pb-4 pt-1 text-[11px] sm:text-xs text-gray-500 font-semibold leading-relaxed border-t border-dashed border-gray-50">
                        {item.a}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })
        ) : (
          <div className="text-center p-6 bg-gray-50 rounded-xl border border-gray-100">
            <p className="text-xs font-bold text-gray-400">No matched support articles found. Please try another term.</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}
