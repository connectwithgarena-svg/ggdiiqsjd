import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Mail, MessageCircle, Send, CheckCircle, ShieldCheck, Phone, CreditCard, AlertCircle, Loader2, User, HelpCircle } from 'lucide-react';
import { REGIONS_MAP } from '../lib/regions';

const ABUSIVE_WORDS = [
  "fuck", "bitch", "bastard", "asshole", "idiot", "dick", "pussy", "chutiya", "gand", "loda", "lauda", 
  "gaand", "bsdk", "bhosdike", "madarchod", "behenchod", "harami", "saala", "kamina", "randi", "kamine", "muth",
  "scam", "fake", "fraud", "cheat", "hack", "generator", "bot", "mod apk", "cheat code", "spammer", "spamming", "nonsense", "suck", "shit"
];

function containsAbusiveOrSpamWord(text: string): boolean {
  if (!text) return false;
  const lower = text.toLowerCase();
  return ABUSIVE_WORDS.some(word => lower.includes(word));
}

export default function Contact() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [uid, setUid] = useState('');
  const [mobile, setMobile] = useState('');
  const [utr, setUtr] = useState('');
  const [telegramUserId, setTelegramUserId] = useState('');
  const [subject, setSubject] = useState('double_bonus_query');
  const [message, setMessage] = useState('');
  
  // Success states
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [dynamicCaseId, setDynamicCaseId] = useState('');

  // UID Verification states
  const [selectedServer, setSelectedServer] = useState('ind');
  const [verifyingUid, setVerifyingUid] = useState(false);
  const [verifiedCharacterName, setVerifiedCharacterName] = useState('');
  const [isRealApi, setIsRealApi] = useState(false);
  const [uidError, setUidError] = useState('');

  // Auto-verify Player UID whenever it changes
  useEffect(() => {
    if (uid.length >= 5) {
      setVerifyingUid(true);
      setUidError('');
      const delayDebounce = setTimeout(async () => {
        try {
          const res = await fetch(`https://gatway-seven.vercel.app/gateway?s=${encodeURIComponent(selectedServer)}&u=${encodeURIComponent(uid)}`);
          const data = await res.json() as any;
          if (res.ok && data?.basicInfo?.nickname) {
            const nickname = data.basicInfo.nickname.trim();
            setVerifiedCharacterName(nickname);
            setIsRealApi(true);
            setName(nickname); // Auto-fill verified character name
          } else {
            setVerifiedCharacterName('');
            setIsRealApi(false);
            setUidError('Player not found in game database.');
          }
        } catch (err) {
          setVerifiedCharacterName('');
          setIsRealApi(false);
          setUidError('Verification server unresponsive');
        } finally {
          setVerifyingUid(false);
        }
      }, 600); // 600ms debounce to avoid rapid API calls
      return () => clearTimeout(delayDebounce);
    } else {
      setVerifiedCharacterName('');
      setIsRealApi(false);
      setUidError('');
      setVerifyingUid(false);
    }
  }, [uid, selectedServer]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const trimmedName = name.trim();
    const trimmedEmail = email.trim();
    const trimmedUid = uid.trim();
    const trimmedMobile = mobile.trim();
    const trimmedUtr = utr.trim();
    const trimmedTelegram = telegramUserId.trim();
    const trimmedMessage = message.trim();

    // 1. Presence check
    if (!trimmedName || !trimmedEmail || !trimmedUid || !trimmedMobile || !trimmedUtr || !trimmedMessage) {
      setError('Please fill in all required fields marked with *.');
      return;
    }

    // 2. Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmedEmail)) {
      setError('Please enter a valid email address.');
      return;
    }

    // 3. Player UID: Must be at least 5 digits
    if (!/^\d{5,}$/.test(trimmedUid)) {
      setError('Player UID must be at least 5 digits containing numbers only.');
      return;
    }

    // 4. Mobile phone number: Must be exactly 10 digits
    if (!/^\d{10}$/.test(trimmedMobile)) {
      setError('Mobile phone number must be exactly 10 digits (numbers only).');
      return;
    }

    // 5. UTR: Must be 10 to 15 digits
    if (!/^\d{10,15}$/.test(trimmedUtr)) {
      setError('UTR/Transaction ID must be 10 to 15 digits (numbers only).');
      return;
    }

    // 6. Abusive and spam filter check
    if (
      containsAbusiveOrSpamWord(trimmedName) ||
      containsAbusiveOrSpamWord(trimmedEmail) ||
      containsAbusiveOrSpamWord(trimmedUid) ||
      containsAbusiveOrSpamWord(trimmedMobile) ||
      containsAbusiveOrSpamWord(trimmedUtr) ||
      containsAbusiveOrSpamWord(trimmedTelegram) ||
      containsAbusiveOrSpamWord(trimmedMessage)
    ) {
      setError('Your submission contains words flagged as abusive or spam. Please revise your content.');
      return;
    }

    setSubmitting(true);

    try {
      const res = await fetch('/api/support', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: trimmedName,
          email: trimmedEmail,
          uid: trimmedUid,
          mobile: trimmedMobile,
          utr: trimmedUtr,
          telegramUserId: trimmedTelegram,
          subject,
          message: trimmedMessage,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Failed to submit support case. Please try again.');
      } else {
        setDynamicCaseId(data.caseId);
        setSubmitted(true);
      }
    } catch (err) {
      console.error(err);
      setError('Network error: Helpdesk is currently unreachable. Please try again later.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-8 text-left"
    >
      {/* Editorial Header */}
      <div className="space-y-2">
        <span className="text-[10px] font-black tracking-widest text-[#ee2c24] uppercase">Support Desk</span>
        <h2 className="text-xl sm:text-2xl font-black text-gray-900 tracking-tight leading-tight">GGDIAMOND Help Center</h2>
        <p className="text-xs sm:text-sm font-semibold text-gray-500 leading-relaxed">
          Need assistance with your transactions, double diamond promo claims, or login errors? Create a support case.
        </p>
      </div>

      {/* Grid: Contact details, WhatsApp Channel & Telegram Channel */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        {/* Email Support Card */}
        <div className="bg-white rounded-xl p-4.5 border border-gray-100 shadow-xs flex items-start gap-3.5">
          <div className="shrink-0">
            <svg viewBox="0 0 24 24" className="w-10 h-10">
              <path fill="#EA4335" d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2z" />
              <path fill="#FBBC05" d="M22 6v12c0 1.1-.9 2-2 2h-4V8l6-4z" />
              <path fill="#34A853" d="M2 6v12c0 1.1.9 2 2 2h4V8l-6-4z" />
              <path fill="#4285F4" d="M20 4H4c-1.1 0-2 .9-2 2v2l10 6 10-6V6c0-1.1-.9-2-2-2z" />
              <path fill="#1A73E8" d="M12 14L2 8v10c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8l-10 6z" />
            </svg>
          </div>
          <div className="space-y-1 text-left">
            <h4 className="text-xs font-extrabold text-gray-800 uppercase tracking-wider">Support Email</h4>
            <p className="text-[10px] font-bold text-gray-400">For disputes &amp; bulk queries:</p>
            <a 
              href="mailto:contactgarenaffmax@gmail.com" 
              className="text-xs font-black text-[#ee2c24] hover:underline break-all block pt-0.5"
            >
              contactgarenaffmax@gmail.com
            </a>
          </div>
        </div>

        {/* WhatsApp Channel Card */}
        <div className="bg-white rounded-xl p-4.5 border border-gray-100 shadow-xs flex items-start gap-3.5">
          <div className="shrink-0">
            <svg viewBox="0 0 24 24" className="w-10 h-10">
              <path fill="#25D366" d="M12.012 2c-5.506 0-9.989 4.478-9.99 9.984a9.96 9.96 0 0 0 1.335 4.993L2 22l5.13-1.343a9.92 9.92 0 0 0 4.881 1.28c5.505 0 9.988-4.478 9.989-9.983c0-2.668-1.039-5.176-2.927-7.064C17.185 3.003 14.68 2 12.012 2z" />
              <path fill="#FFF" d="M12.012 3.513c-4.66 0-8.453 3.792-8.454 8.453a8.41 8.41 0 0 0 1.127 4.22l-.12-.343-.65 2.373 2.435-.64.316.188a8.383 8.383 0 0 0 4.148 1.104c4.661 0 8.454-3.79 8.455-8.45a8.4 8.4 0 0 0-2.474-5.975 8.4 8.4 0 0 0-5.974-2.474zm4.845 11.233c-.266.748-1.54 1.37-2.11 1.422-.443.044-1.772.443-3.755-1.196-1.64-1.353-2.67-3.08-3.08-3.657-.41-.576-.73-1.286-.73-1.995 0-1.352.7-2.016.942-2.27.189-.2.51-.277.732-.277.09 0 .177.011.255.011.21.011.343.022.487.32.178.41.62 1.507.665 1.607.045.1.077.22.01.354-.066.133-.1.222-.2.332-.1.11-.21.255-.3.343-.1.1-.21.21-.09.42.122.21.543.898 1.163 1.45.798.71 1.472.93 1.683 1.03.21.1.332-.09.454-.233.133-.155.576-.675.731-.908.156-.233.31-.19.52-.1.21.09 1.33.632 1.552.743.22.11.365.166.42.266.056.1.056.576-.177 1.23z" />
            </svg>
          </div>
          <div className="space-y-1 text-left">
            <h4 className="text-xs font-extrabold text-gray-800 uppercase tracking-wider">WhatsApp Channel</h4>
            <p className="text-[10px] font-bold text-gray-400">Join community updates:</p>
            <a 
              href="https://whatsapp.com/channel/0029Vb8HTPiBqbr03gj1P03H" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-xs font-black text-emerald-600 hover:underline block pt-0.5"
            >
              Join WhatsApp →
            </a>
          </div>
        </div>

        {/* Telegram Channel Card */}
        <div className="bg-white rounded-xl p-4.5 border border-gray-100 shadow-xs flex items-start gap-3.5">
          <div className="shrink-0">
            <svg viewBox="0 0 24 24" className="w-10 h-10" fill="#229ED9">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 0 0-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.37.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z"/>
            </svg>
          </div>
          <div className="space-y-1 text-left">
            <h4 className="text-xs font-extrabold text-gray-800 uppercase tracking-wider">Telegram Channel</h4>
            <p className="text-[10px] font-bold text-gray-400">Join support community:</p>
            <a 
              href="https://t.me/garenaofficialindmax" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-xs font-black text-sky-600 hover:underline block pt-0.5"
            >
              Join Telegram →
            </a>
          </div>
        </div>
      </div>

      {/* Incident / Enquiry Form */}
      <div className="bg-white border border-gray-100 rounded-xl p-5 shadow-xs space-y-4">
        <h3 className="text-base font-extrabold text-gray-800 border-b border-gray-50 pb-3 flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-indigo-500" />
          Create Support Case
        </h3>

        {error && (
          <div className="p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 font-bold text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {submitted ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="p-8 text-center space-y-5"
          >
            <div className="p-3 bg-emerald-50 rounded-full inline-block text-emerald-500">
              <CheckCircle className="w-14 h-14" />
            </div>
            
            <div className="space-y-2">
              <h4 className="text-lg font-extrabold text-gray-800">Support Case Submitted!</h4>
              <p className="text-xs font-black text-emerald-600 bg-emerald-50 border border-emerald-100/50 px-3 py-1 rounded-full inline-block">
                Case ID: {dynamicCaseId || 'FF-Pending'}
              </p>
            </div>

            {/* Strict Notice regarding single submissions & 24hr response time on support channels */}
            <div className="bg-indigo-50/50 border border-indigo-100 rounded-xl p-4 max-w-md mx-auto text-left space-y-2">
              <div className="flex items-center gap-2 text-indigo-800 font-extrabold text-xs">
                <AlertCircle className="w-4 h-4 text-indigo-500 shrink-0" />
                <span>IMPORTANT SUBMISSION NOTICE</span>
              </div>
              <p className="text-[11px] font-semibold text-indigo-900 leading-relaxed">
                Your support request has been logged successfully in our central helpdesk database. 
                <b className="block mt-1 text-red-600">Please do NOT submit multiple tickets or create another request.</b> 
                Our specialized team is already processing your parameters and will respond to you <b>within 24 hours</b> via our direct supported channels including your registered email <b>({email})</b> and WhatsApp support.
              </p>
            </div>

            <p className="text-[11px] font-bold text-gray-400">
              Thank you for cooperating with our security validation process.
            </p>

            <button
              onClick={() => {
                setSubmitted(false);
                setName('');
                setEmail('');
                setUid('');
                setMobile('');
                setUtr('');
                setTelegramUserId('');
                setMessage('');
                setError('');
              }}
              className="bg-[#ee2c24] hover:bg-red-600 text-white font-extrabold text-xs uppercase tracking-wider py-2.5 px-6 rounded-lg cursor-pointer transition-all"
            >
              Back to Support Desk
            </button>
          </motion.div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Name and Email */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5 text-left">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Your Name <span className="text-[#ee2c24]">*</span></label>
                <input
                  type="text"
                  required
                  placeholder="e.g. John Doe"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-sm font-semibold outline-hidden focus:border-[#ee2c24] transition-colors text-gray-800"
                />
                <span className="text-[10px] text-gray-400 font-semibold block">Auto-fills when you enter your Player UID below</span>
              </div>

              <div className="space-y-1.5 text-left">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Email Address <span className="text-[#ee2c24]">*</span></label>
                <input
                  type="email"
                  required
                  placeholder="e.g. john@gmail.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-sm font-semibold outline-hidden focus:border-[#ee2c24] transition-colors text-gray-800"
                />
                <span className="text-[10px] text-gray-400 font-semibold block">We will send case updates and resolution notes here</span>
              </div>
            </div>

            {/* Server and Player UID */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1.5 text-left">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">
                  Server Region <span className="text-[#ee2c24]">*</span>
                </label>
                <select
                  value={selectedServer}
                  onChange={(e) => setSelectedServer(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-sm font-semibold outline-hidden focus:border-[#ee2c24] transition-colors cursor-pointer text-gray-800"
                >
                  {REGIONS_MAP.map((reg) => (
                    <option key={reg.value} value={reg.value}>
                      {reg.label}
                    </option>
                  ))}
                </select>
                <span className="text-[10px] text-gray-400 font-semibold block">Select account server</span>
              </div>

              <div className="space-y-1.5 text-left relative sm:col-span-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1">
                  Player UID <span className="text-[#ee2c24]">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 12345678"
                  value={uid}
                  onChange={(e) => setUid(e.target.value.replace(/\D/g, ''))}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-sm font-semibold outline-hidden focus:border-[#ee2c24] transition-colors text-gray-800"
                />
                
                {/* Auto Verification UI Feedback */}
                {uid.length >= 5 && (
                  <div className="mt-1 flex items-center gap-1.5 text-[10px] font-bold">
                    {verifyingUid ? (
                      <span className="text-amber-600 flex items-center gap-1 animate-pulse">
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        Verifying Player Character...
                      </span>
                    ) : verifiedCharacterName ? (
                      <span className="text-emerald-600 flex items-center gap-1">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
                        Player Name: <b className="bg-emerald-50 border border-emerald-100 px-1.5 py-0.5 rounded text-emerald-700 font-mono text-[11px]">{verifiedCharacterName}</b>
                      </span>
                    ) : uidError ? (
                      <span className="text-red-500 flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5" />
                        {uidError}
                      </span>
                    ) : null}
                  </div>
                )}
                <span className="text-[10px] text-gray-400 font-semibold block">Minimum 5 digits (Player UID verification database connection)</span>
              </div>
            </div>

            {/* Mobile Phone Number */}
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-1.5 text-left">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1">
                  <Phone className="w-3 h-3 text-[#ee2c24]" />
                  Mobile Phone <span className="text-[#ee2c24]">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 9876543210"
                  value={mobile}
                  maxLength={10}
                  onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-sm font-semibold outline-hidden focus:border-[#ee2c24] transition-colors text-gray-800"
                />
                <span className="text-[10px] text-gray-400 font-semibold block">Must be exactly 10 digits</span>
              </div>
            </div>

            {/* UTR and Telegram User ID */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5 text-left">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1">
                  <CreditCard className="w-3.5 h-3.5 text-[#ee2c24]" />
                  UTR / Transaction ID <span className="text-[#ee2c24]">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 30129847182"
                  value={utr}
                  maxLength={15}
                  onChange={(e) => setUtr(e.target.value.replace(/\D/g, ''))}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-sm font-semibold outline-hidden focus:border-[#ee2c24] transition-colors text-gray-800"
                />
                <span className="text-[10px] text-gray-400 font-semibold block">Must be 10 to 15 digits</span>
              </div>

              <div className="space-y-1.5 text-left">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1">
                  Telegram Username / ID
                </label>
                <input
                  type="text"
                  placeholder="e.g. @GGDIAMONDSupport (Optional)"
                  value={telegramUserId}
                  onChange={(e) => setTelegramUserId(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-sm font-semibold outline-hidden focus:border-[#ee2c24] transition-colors text-gray-800"
                />
                <span className="text-[10px] text-gray-400 font-semibold block">Used for swift dispute updates</span>
              </div>
            </div>

            {/* Query Topic and message */}
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-1.5 text-left">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Query Topic</label>
                <select
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-sm font-semibold outline-hidden focus:border-[#ee2c24] transition-colors cursor-pointer text-gray-800"
                >
                  <option value="double_bonus_query">Double Diamonds Promo Inquiry</option>
                  <option value="payment_not_credited">Payment Done but Diamonds Not Received</option>
                  <option value="uid_error">UID Login Issues</option>
                  <option value="other_help">Other Queries</option>
                </select>
              </div>
            </div>

            <div className="space-y-1.5 text-left">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Your Message <span className="text-[#ee2c24]">*</span></label>
              <textarea
                required
                rows={4}
                placeholder="Describe your issue or transaction enquiry in detail here..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-sm font-semibold outline-hidden focus:border-[#ee2c24] transition-colors resize-none text-gray-800"
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full bg-[#ee2c24] hover:bg-red-600 disabled:bg-red-300 text-white font-extrabold py-3 px-6 rounded-xl transition-all shadow-md shadow-red-500/10 flex items-center justify-center gap-2 cursor-pointer text-sm uppercase tracking-wider"
            >
              {submitting ? (
                'Submitting Enquiry...'
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Submit Support Ticket
                </>
              )}
            </button>
          </form>
        )}
      </div>
    </motion.div>
  );
}
