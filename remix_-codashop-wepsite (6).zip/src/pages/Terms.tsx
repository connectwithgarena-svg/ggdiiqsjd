import { motion } from 'motion/react';
import { Scale, ShieldAlert, FileText, CheckCircle, Info } from 'lucide-react';

export default function Terms() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-6 text-left"
    >
      {/* Editorial Header */}
      <div className="space-y-2">
        <span className="text-[10px] font-black tracking-widest text-[#ee2c24] uppercase">Legal Desk</span>
        <h2 className="text-xl sm:text-2xl font-black text-gray-900 tracking-tight leading-tight">Terms &amp; Conditions</h2>
        <p className="text-[10px] font-bold text-gray-400">Last Updated: July 5, 2026 | Effective Date: July 5, 2026</p>
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-xs font-semibold text-amber-800 leading-relaxed flex gap-3">
        <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Important Legal Notice</span>
          These Terms constitute a legally binding agreement between you ("User") and us ("the Platform"). By accessing, browsing, or transacting on this website, you confirm you have read, understood, and agree to be fully bound by these Terms. If you do not agree, stop using this website immediately.
        </div>
      </div>

      <div className="bg-white rounded-xl p-5 border border-gray-100 shadow-xs space-y-6 text-xs sm:text-sm text-gray-600 font-semibold leading-relaxed">
        
        {/* Section 1 */}
        <div className="space-y-2.5">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <FileText className="w-4 h-4 text-[#ee2c24]" />
            SECTION 1 — DEFINITIONS
          </h3>
          <div className="grid gap-2 pl-6 border-l-2 border-gray-100">
            <p><span className="text-gray-900 font-bold">"Platform"</span> — This website and all its associated subdomains, interfaces, and content.</p>
            <p><span className="text-gray-900 font-bold">"Service"</span> — The digital in-game diamond recharge facility provided for Free Fire (published by Garena Online Private Limited).</p>
            <p><span className="text-gray-900 font-bold">"Player UID"</span> — The unique numeric identifier assigned by Garena to each Free Fire account.</p>
            <p><span className="text-gray-900 font-bold">"Transaction"</span> — Any completed payment made on this Platform for diamond delivery.</p>
            <p><span className="text-gray-900 font-bold">"Diamonds"</span> — The in-game virtual currency used within the Free Fire game ecosystem.</p>
            <p><span className="text-gray-900 font-bold">"Delivery"</span> — The automated credit of purchased diamonds to the Free Fire account linked to the Player UID provided.</p>
            <p><span className="text-gray-900 font-bold">"Promotional Package"</span> — Any package tagged with bonus, anniversary, discount, double, or limited-time indicators.</p>
          </div>
        </div>

        {/* Section 2 */}
        <div className="space-y-2.5">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <Scale className="w-4 h-4 text-rose-500" />
            SECTION 2 — ELIGIBILITY &amp; ACCOUNT RESPONSIBILITY
          </h3>
          <div className="space-y-3 pl-6 border-l-2 border-gray-100">
            <p>
              <span className="text-gray-900 font-bold">2.1 Age Requirement:</span> You must be at least 13 years old to use this Platform. If you are under 18, explicit written consent from a parent or legal guardian is required before any purchase. By proceeding, you confirm you meet this requirement. Misrepresentation of age may result in order cancellation without refund.
            </p>
            <p>
              <span className="text-gray-900 font-bold">2.2 Accurate Information:</span> You agree to provide only true, accurate, current, and complete information at all times — including your Player UID, server region, name, email address, and mobile number. Submitting false or misleading information is a material breach of these Terms.
            </p>
            <p>
              <span className="text-gray-900 font-bold">2.3 UID Ownership:</span> You confirm and warrant that the Player UID entered at checkout is your own registered Free Fire account. You must not enter another person's Player UID without their explicit, verified, written consent. We will not issue refunds for diamonds delivered to an incorrect or third-party UID due to user error.
            </p>
            <p>
              <span className="text-gray-900 font-bold">2.4 Region Accuracy:</span> You are solely responsible for selecting the correct server region that matches your Free Fire account. Region mismatch resulting in failed or misdirected delivery will not qualify for a refund.
            </p>
            <p>
              <span className="text-gray-900 font-bold">2.5 Account Security:</span> We will NEVER ask for your Free Fire account password under any circumstances. If anyone claiming to represent us requests your password, do not comply and report it to us immediately.
            </p>
          </div>
        </div>

        {/* Section 3 */}
        <div className="space-y-2.5">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-500" />
            SECTION 3 — NATURE OF SERVICE &amp; THIRD-PARTY DISCLAIMER
          </h3>
          <div className="space-y-3 pl-6 border-l-2 border-gray-100">
            <p>
              <span className="text-gray-900 font-bold">3.1 Independent Service Provider:</span> We are an independent digital goods reseller. We are NOT an official representative, subsidiary, partner, affiliate, or agent of Garena Online Private Limited. Free Fire and all associated trademarks are the property of Garena Online Private Limited. References to Garena or Free Fire are for identification and descriptive purposes only.
            </p>
            <p>
              <span className="text-gray-900 font-bold">3.2 Game Publisher Terms:</span> Your use of diamonds and your Free Fire account is subject to Garena's own Terms of Service, Privacy Policy, and End User License Agreement. It is your responsibility to ensure that using a third-party top-up service is permitted under Garena's current terms. We accept no liability for any action Garena takes against your account.
            </p>
            <p>
              <span className="text-gray-900 font-bold">3.3 Service Availability:</span> We provide this service on an "as available" basis. We do not guarantee uninterrupted, error-free, or delay-free service at all times. Scheduled or emergency maintenance periods may temporarily affect our ability to process orders.
            </p>
          </div>
        </div>

        {/* Section 4 */}
        <div className="space-y-2.5">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-500" />
            SECTION 4 — ORDERS, PAYMENTS &amp; PRICING
          </h3>
          <div className="space-y-3 pl-6 border-l-2 border-gray-100">
            <p>
              <span className="text-gray-900 font-bold">4.1 Binding Order:</span> Clicking "Pay Now" or completing payment on this Platform constitutes a legally binding purchase order. You agree that your order cannot be cancelled, modified, or reversed once payment has been confirmed by the payment gateway.
            </p>
            <p>
              <span className="text-gray-900 font-bold">4.2 Pricing:</span> All prices are displayed in Indian Rupees (INR). Prices are subject to change at any time without prior notice. The price applicable to your order is the price confirmed at the time your payment is successfully processed — not the price shown at any earlier browsing session.
            </p>
            <p>
              <span className="text-gray-900 font-bold">4.3 Payment Authorization:</span> By completing payment, you confirm that you are the authorized user of the payment method used, the payment method has sufficient funds or credit, and you have not obtained the payment method through fraud, theft, or unauthorized means.
            </p>
            <p>
              <span className="text-gray-900 font-bold">4.4 Failed Payment Holds:</span> In the event of a failed payment, your bank may place a temporary hold on funds. This hold is controlled entirely by your financial institution and typically releases within 3 to 7 business days. We have no authority to expedite this release. Do not attempt to place duplicate orders before confirming with your bank.
            </p>
            <p>
              <span className="text-gray-900 font-bold">4.5 Double Payment:</span> In the rare event of an accidental double payment for the same order, notify us within 24 hours via the Support page with both UTR references and a screenshot. Requests received after 24 hours will not be entertained. Verified duplicates will be refunded within 7 to 10 business days.
            </p>
          </div>
        </div>

        {/* Section 5 */}
        <div className="space-y-2.5">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <FileText className="w-4 h-4 text-indigo-500" />
            SECTION 5 — DELIVERY TERMS
          </h3>
          <div className="space-y-3 pl-6 border-l-2 border-gray-100">
            <p>
              <span className="text-gray-900 font-bold">5.1 Instant Delivery:</span> Diamonds are delivered automatically and instantly to the Free Fire account linked to your Player UID upon successful payment confirmation from the payment gateway.
            </p>
            <p>
              <span className="text-gray-900 font-bold">5.2 Delivery Delay:</span> In exceptional circumstances — including Garena server downtime, payment gateway delays, or network outages — delivery may take up to 24 hours. Delays do not constitute grounds for a refund unless the 24-hour window is exceeded with no delivery.
            </p>
            <p>
              <span className="text-gray-900 font-bold">5.3 Non-Delivery Investigation:</span> If diamonds have not been credited within 24 hours of confirmed payment, contact our Support team with: your exact Player UID, Transaction / UTR Reference Number, a clear screenshot of payment confirmation, and a screenshot of your in-game diamond balance before and after. Failure to provide all items will result in the ticket being closed without resolution.
            </p>
            <p>
              <span className="text-gray-900 font-bold">5.4 Delivery Destination is Final:</span> Once diamonds are delivered to the Player UID entered at checkout, the delivery cannot be reversed, redirected, or cancelled. Always double-check your UID on the verification screen before proceeding to payment.
            </p>
            <p>
              <span className="text-gray-900 font-bold">5.5 Sold-Out Packages:</span> If a package becomes unavailable after payment but before delivery, we will contact you and offer either a replacement package or a full refund.
            </p>
          </div>
        </div>

        {/* Section 6 */}
        <div className="space-y-2.5">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <Info className="w-4 h-4 text-purple-500" />
            SECTION 6 — PROMOTIONAL PACKAGES &amp; BONUS DIAMONDS
          </h3>
          <div className="space-y-3 pl-6 border-l-2 border-gray-100">
            <p>
              <span className="text-gray-900 font-bold">6.1 Limited Availability:</span> Promotional packages are available only for a limited time and while stock lasts. We reserve the right to withdraw any offer at any time without prior notice.
            </p>
            <p>
              <span className="text-gray-900 font-bold">6.2 One Per Customer:</span> Unless explicitly stated otherwise, promotional packages are limited to one per Player UID, per device, and per payment method. Circumventing this limit constitutes abuse and will result in order cancellation and permanent blacklisting.
            </p>
            <p>
              <span className="text-gray-900 font-bold">6.3 No Monetary Value of Bonus:</span> Bonus diamonds provided under promotional offers have no independent monetary value and will not be calculated as part of any refund. Refunds for promotional packages, where eligible, will only be computed based on the base diamond amount at its equivalent standard market rate.
            </p>
            <p>
              <span className="text-gray-900 font-bold">6.4 Promotional Accuracy:</span> We reserve the right to correct typographical errors in pricing or bonus amounts and cancel orders placed based on incorrect promotional data.
            </p>
          </div>
        </div>

        {/* Section 7 - Prohibited Conduct with red visual highlight */}
        <div className="space-y-3 bg-rose-50 border border-rose-100 rounded-xl p-4">
          <h3 className="text-sm font-black text-rose-800 uppercase tracking-wide flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-[#ee2c24]" />
            SECTION 7 — PROHIBITED CONDUCT — ZERO TOLERANCE
          </h3>
          <p className="text-xs text-rose-700 font-bold">
            The following conduct is explicitly prohibited and will result in immediate order cancellation, permanent account blacklisting, and may lead to civil or criminal legal proceedings:
          </p>
          <ul className="space-y-1.5 pl-5 list-disc text-rose-800 text-xs font-semibold">
            <li>Entering a Player UID that does not belong to you.</li>
            <li>Using stolen, cloned, or fraudulently obtained payment methods.</li>
            <li>Initiating unjustified chargebacks for successfully delivered orders.</li>
            <li>Creating multiple accounts or UIDs to abuse promotional offers.</li>
            <li>Attempting to hack, penetrate, or disrupt our platform or servers.</li>
            <li>Using automated scripts, bots, or crawlers on this website.</li>
            <li>Submitting false, fabricated, or manipulated screenshots or documents in support requests.</li>
            <li>Harassing, threatening, or abusing our support staff in any form across any communication channel.</li>
            <li>Publicly defaming or spreading false information about this Platform with intent to damage our reputation.</li>
            <li>Impersonating our support staff or representatives.</li>
            <li>Exploiting any bug or technical error for personal gain. Such exploits must be reported immediately.</li>
          </ul>
          <div className="pt-2 border-t border-rose-100 text-[11px] text-rose-700 space-y-1">
            <p><span className="font-bold">Tier 1 (Minor / First offense):</span> Order cancelled. Warning issued.</p>
            <p><span className="font-bold">Tier 2 (Repeat or Moderate):</span> Permanent blacklisting. No future service. No appeal.</p>
            <p><span className="font-bold">Tier 3 (Severe - Fraud, Hacking, Threats):</span> Legal action. Civil suit. Law enforcement referral.</p>
          </div>
        </div>

        {/* Section 8 */}
        <div className="space-y-2.5">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-orange-500" />
            SECTION 8 — CHARGEBACK &amp; DISPUTE POLICY
          </h3>
          <div className="space-y-3 pl-6 border-l-2 border-gray-100">
            <p>
              <span className="text-gray-900 font-bold">8.1 Chargeback Definition:</span> A chargeback occurs when a customer disputes a transaction with their bank, resulting in a forced reversal of funds.
            </p>
            <p>
              <span className="text-gray-900 font-bold">8.2 Fraudulent Chargebacks:</span> Initiating a chargeback for a successfully delivered order is fraud. We treat it as such, without exception. Upon receipt of a chargeback notice, we immediately blacklist the associated UID, email, and payment method, and submit full transaction evidence (delivery logs, IP data, etc.) to the bank. We reserve the right to pursue civil or criminal proceedings for recovery of the disputed amount plus chargeback fees (typically ₹500 to ₹2,500 per incident).
            </p>
            <p>
              <span className="text-gray-900 font-bold">8.3 direct contact resolution:</span> If you believe your payment was unauthorized, contact us FIRST before filing a bank dispute. We can often resolve the matter faster through direct communication.
            </p>
          </div>
        </div>

        {/* Section 9 */}
        <div className="space-y-2.5">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <Info className="w-4 h-4 text-teal-500" />
            SECTION 9 — LIMITATION OF LIABILITY
          </h3>
          <div className="space-y-2 pl-6 border-l-2 border-gray-100 text-xs">
            <p className="font-bold text-gray-900">TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, WE SHALL NOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES ARISING FROM YOUR USE OF OUR SERVICE.</p>
            <p>We are not responsible for: Garena server downtime, bans or suspensions by Garena, failures by third-party payment gateways, or financial losses from entering an incorrect UID. Our maximum total liability for any single transaction shall not exceed the amount you paid for that transaction.</p>
          </div>
        </div>

        {/* Section 10 */}
        <div className="space-y-2.5">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <Scale className="w-4 h-4 text-cyan-500" />
            SECTION 10 — INDEMNIFICATION
          </h3>
          <p className="pl-6 border-l-2 border-gray-100">
            You agree to defend, indemnify, and hold harmless this Platform, its directors, employees, agents, and affiliates from and against any claims, liabilities, damages, losses, costs, and expenses (including reasonable legal fees) arising from your use of the Service in violation of these Terms, false information provided, or any fraudulent transaction/chargeback you initiated.
          </p>
        </div>

        {/* Section 11 */}
        <div className="space-y-2.5">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <FileText className="w-4 h-4 text-blue-500" />
            SECTION 11 — GOVERNING LAW &amp; DISPUTE RESOLUTION
          </h3>
          <div className="space-y-3 pl-6 border-l-2 border-gray-100">
            <p>
              <span className="text-gray-900 font-bold">11.1 Governing Law:</span> These Terms are governed by the laws of India — including the Information Technology Act 2000, Consumer Protection Act 2019, and Payment and Settlement Systems Act 2007.
            </p>
            <p>
              <span className="text-gray-900 font-bold">11.2 Good-Faith Negotiation:</span> Any dispute shall first be attempted to be resolved through good-faith negotiation for 30 days.
            </p>
            <p>
              <span className="text-gray-900 font-bold">11.3 Arbitration:</span> If not resolved through negotiation, disputes shall be referred to binding arbitration under the Arbitration and Conciliation Act 1996. The seat of arbitration shall be India.
            </p>
            <p>
              <span className="text-gray-900 font-bold">11.4 Revisions:</span> We reserve the right to revise these Terms at any time. Continued use of the website after changes constitutes your acceptance of the revised Terms.
            </p>
          </div>
        </div>

        {/* Support email contact */}
        <div className="pt-4 border-t border-gray-50 text-[11px] text-gray-400">
          For further questions or inquiries, please contact our Legal department at <a href="mailto:contactgarenaffmax@gmail.com" className="text-[#ee2c24] underline">contactgarenaffmax@gmail.com</a>.
        </div>
      </div>
    </motion.div>
  );
}
