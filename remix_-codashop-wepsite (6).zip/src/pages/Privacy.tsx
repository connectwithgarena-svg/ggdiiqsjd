import { motion } from 'motion/react';
import { Shield, Eye, Lock, Globe, Server, CheckCircle2 } from 'lucide-react';

export default function Privacy() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-6 text-left"
    >
      {/* Editorial Header */}
      <div className="space-y-2">
        <span className="text-[10px] font-black tracking-widest text-[#ee2c24] uppercase">Legal Desk</span>
        <h2 className="text-xl sm:text-2xl font-black text-gray-900 tracking-tight leading-tight">Privacy Policy</h2>
        <p className="text-[10px] font-bold text-gray-400">Last Updated: July 5, 2026 | Jurisdiction: India (DPDPA 2023)</p>
      </div>

      <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 text-xs font-semibold text-emerald-800 leading-relaxed flex gap-3">
        <Shield className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold uppercase tracking-wider block mb-1">Our Privacy Commitment</span>
          We are committed to protecting your privacy. This policy explains exactly what data we collect, how we use it, who we share it with, how long we retain it, and what rights you have under the Information Technology Act 2000 and the Digital Personal Data Protection Act 2023 (India).
        </div>
      </div>

      <div className="bg-white rounded-xl p-5 border border-gray-100 shadow-xs space-y-6 text-xs sm:text-sm text-gray-600 font-semibold leading-relaxed">
        
        {/* Section 1 */}
        <div className="space-y-2.5">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <Eye className="w-4 h-4 text-[#ee2c24]" />
            SECTION 1 — DATA WE COLLECT
          </h3>
          <div className="space-y-3 pl-6 border-l-2 border-gray-100">
            <p>
              <span className="text-gray-900 font-bold">1.1 Data You Provide Directly:</span>
            </p>
            <ul className="list-disc pl-5 space-y-1 text-gray-500">
              <li><span className="font-bold text-gray-700">Player UID:</span> Required for diamond delivery identification.</li>
              <li><span className="font-bold text-gray-700">Server region:</span> Required to locate the correct game account.</li>
              <li><span className="font-bold text-gray-700">Full name &amp; Email address:</span> Collected on support forms for identity and communication.</li>
              <li><span className="font-bold text-gray-700">Mobile number &amp; UTR Reference:</span> Collected for payment dispute investigation.</li>
              <li><span className="font-bold text-gray-700">Telegram User ID:</span> Optionally provided for support channel contact.</li>
              <li><span className="font-bold text-gray-700">Message content:</span> Support ticket body text submitted via contact form.</li>
            </ul>

            <p className="pt-2">
              <span className="text-gray-900 font-bold">1.2 Data Collected Automatically:</span>
            </p>
            <ul className="list-disc pl-5 space-y-1 text-gray-500">
              <li>IP address, transaction timestamp, and gateway response code (for fraud prevention).</li>
              <li>Browser type, version, and device type (for security auditing and system compatibility).</li>
              <li>Session duration and pages visited (aggregated analytics only).</li>
            </ul>

            <div className="mt-3 bg-rose-50 border border-rose-100 p-3 rounded-lg text-rose-800 text-xs font-semibold">
              <span className="block font-bold uppercase mb-1">❌ Data We NEVER Collect — Ever</span>
              <p>Free Fire passwords, credit/debit card numbers, CVVs, net banking passwords, OTPs, Aadhaar/PAN, biometrics, or GPS location data.</p>
            </div>
          </div>
        </div>

        {/* Section 2 */}
        <div className="space-y-2.5">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <Server className="w-4 h-4 text-rose-500" />
            SECTION 2 — HOW WE USE YOUR DATA
          </h3>
          <div className="pl-6 border-l-2 border-gray-100 space-y-2">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-gray-100 text-gray-400 font-bold">
                    <th className="pb-2 pr-4">Purpose</th>
                    <th className="pb-2">Legal Basis</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50 text-gray-500">
                  <tr>
                    <td className="py-2 pr-4 font-bold text-gray-700">Diamond delivery to your UID</td>
                    <td className="py-2">Contract performance</td>
                  </tr>
                  <tr>
                    <td className="py-2 pr-4 font-bold text-gray-700">Transaction verification</td>
                    <td className="py-2">Contract performance</td>
                  </tr>
                  <tr>
                    <td className="py-2 pr-4 font-bold text-gray-700">Fraud detection &amp; prevention</td>
                    <td className="py-2">Legitimate interest</td>
                  </tr>
                  <tr>
                    <td className="py-2 pr-4 font-bold text-gray-700">Support ticket resolution</td>
                    <td className="py-2">Contract performance</td>
                  </tr>
                  <tr>
                    <td className="py-2 pr-4 font-bold text-gray-700">Platform security monitoring</td>
                    <td className="py-2">Legitimate interest</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="bg-gray-50 p-2.5 rounded-lg text-[11px] text-gray-500">
              <span className="font-bold text-gray-700">We do NOT use your data for:</span> Selling to third-party marketers, advertising profiling, or sharing with data brokers.
            </div>
          </div>
        </div>

        {/* Section 3 */}
        <div className="space-y-2.5">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <Globe className="w-4 h-4 text-indigo-500" />
            SECTION 3 — DATA SHARING
          </h3>
          <div className="space-y-3 pl-6 border-l-2 border-gray-100">
            <p>
              <span className="text-gray-900 font-bold">3.1 Payment Gateways:</span> We share minimal transaction data (amount, order reference, UID hash) with our payment gateway partners (e.g., PayU, Easebuzz) strictly for processing. They are PCI-DSS compliant, and we do not receive card details.
            </p>
            <p>
              <span className="text-gray-900 font-bold">3.2 Internal Team Access:</span> Transaction data is accessible only to authorized team members for delivery checks, fraud investigations, or support resolution. All access is logged.
            </p>
            <p>
              <span className="text-gray-900 font-bold">3.3 Legal Requirements:</span> We may disclose your data if required by court order, legal process, or criminal fraud investigation where your data is relevant evidence.
            </p>
            <p className="font-bold text-gray-900">
              ⚠️ We will NEVER sell your personal data, share it with advertisers, or transfer it abroad without appropriate safeguards.
            </p>
          </div>
        </div>

        {/* Section 4 */}
        <div className="space-y-2.5">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <Lock className="w-4 h-4 text-emerald-500" />
            SECTION 4 — DATA RETENTION
          </h3>
          <div className="pl-6 border-l-2 border-gray-100">
            <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs text-gray-500">
              <span className="font-bold text-gray-700">Transaction records:</span> <span>90 days from transaction date</span>
              <span className="font-bold text-gray-700">Support ticket data:</span> <span>12 months from ticket closure</span>
              <span className="font-bold text-gray-700">Fraud logs:</span> <span>24 months (legal requirement)</span>
              <span className="font-bold text-gray-700">Server access logs:</span> <span>30 days rolling</span>
            </div>
            <p className="mt-2 text-gray-400 text-[11px]">
              After these periods, data is permanently and securely deleted or fully anonymized.
            </p>
          </div>
        </div>

        {/* Section 5 */}
        <div className="space-y-2.5">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <Lock className="w-4 h-4 text-[#ee2c24]" />
            SECTION 5 — DATA SECURITY MEASURES
          </h3>
          <div className="space-y-2 pl-6 border-l-2 border-gray-100">
            <p>We implement strict measures to ensure player data integrity:</p>
            <ul className="list-disc pl-5 space-y-1 text-gray-500">
              <li>SSL/TLS encryption for all data in transit (HTTPS enforced sitewide).</li>
              <li>Server-side input validation and sanitization on all forms.</li>
              <li>Role-based access control and regular security audits.</li>
              <li>No storage of payment card data on our servers.</li>
              <li>In case of a data breach, we will notify affected users within 72 hours.</li>
            </ul>
          </div>
        </div>

        {/* Section 6 */}
        <div className="space-y-2.5">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <Globe className="w-4 h-4 text-amber-500" />
            SECTION 6 — COOKIES &amp; TRACKING
          </h3>
          <div className="space-y-2 pl-6 border-l-2 border-gray-100">
            <p><span className="text-gray-900 font-bold">6.1 Cookies We Use:</span> Session Cookies (maintain login/region state, duration: Session), Preference Cookies (remember region selection, duration: 30 days), and Security Cookies (CSRF protection, duration: Session).</p>
            <p><span className="text-gray-900 font-bold">6.2 Cookies We Do NOT Use:</span> No advertising/retargeting cookies (Google Ads, Facebook Pixel) or third-party analytics with PII.</p>
            <p className="text-gray-400 text-[11px]">You can disable cookies in your browser settings, though disabling session cookies may block checkout completion.</p>
          </div>
        </div>

        {/* Section 7 */}
        <div className="space-y-2.5">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-purple-500" />
            SECTION 7 — YOUR RIGHTS UNDER DPDPA 2023
          </h3>
          <div className="space-y-2 pl-6 border-l-2 border-gray-100">
            <p>You have the following statutory rights regarding your personal data:</p>
            <div className="grid gap-2 grid-cols-1 sm:grid-cols-2 text-xs font-semibold">
              <div className="bg-gray-50 p-2 rounded-lg">🔍 <span className="text-gray-800 font-bold">Right to Access:</span> Request a copy of personal data we hold.</div>
              <div className="bg-gray-50 p-2 rounded-lg">✏️ <span className="text-gray-800 font-bold">Right to Correction:</span> Request correction of inaccurate data.</div>
              <div className="bg-gray-50 p-2 rounded-lg">🗑️ <span className="text-gray-800 font-bold">Right to Erasure:</span> Request deletion (subject to legal limits).</div>
              <div className="bg-gray-50 p-2 rounded-lg">📤 <span className="text-gray-800 font-bold">Right to Portability:</span> Request machine-readable format export.</div>
              <div className="bg-gray-50 p-2 rounded-lg">🚫 <span className="text-gray-800 font-bold">Right to Withdraw:</span> Withdraw consent for data processing.</div>
              <div className="bg-gray-50 p-2 rounded-lg">📢 <span className="text-gray-800 font-bold">Grievance Redressal:</span> File complaints about our data practices.</div>
            </div>
            <p className="text-gray-500 pt-2">
              To exercise these rights, submit a request via our Contact page with the subject <span className="text-gray-800 font-bold">"DATA RIGHTS REQUEST"</span>. We will respond within 30 days.
            </p>
          </div>
        </div>

        {/* Section 8 & 9 */}
        <div className="space-y-2.5">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <Shield className="w-4 h-4 text-teal-500" />
            SECTION 8 &amp; 9 — CHILDREN'S PRIVACY &amp; AMENDMENTS
          </h3>
          <div className="space-y-2 pl-6 border-l-2 border-gray-100">
            <p>Our platform is not directed to children under 13. We do not knowingly collect their data; any such data found is immediately purged. We may update this Privacy Policy periodically. Continued use implies your acceptance of the updated policy.</p>
          </div>
        </div>

        {/* Support email contact */}
        <div className="pt-4 border-t border-gray-50 text-[11px] text-gray-400">
          For further questions or inquiries, please contact our Legal department at <a href="mailto:contactgarenaffmax@gmail.com" className="text-[#ee2c24] underline">contactgarenaffmax@gmail.com</a>.
        </div>
      </div>
    </motion.div>
  );
}
