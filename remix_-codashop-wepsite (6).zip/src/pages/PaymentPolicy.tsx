import { motion } from 'motion/react';
import { CreditCard, CheckCircle, ShieldCheck, XCircle, AlertCircle, FileText } from 'lucide-react';

export default function PaymentPolicy() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-6 text-left"
    >
      {/* Editorial Header */}
      <div className="space-y-2">
        <span className="text-[10px] font-black tracking-widest text-[#ee2c24] uppercase">Legal Desk</span>
        <h2 className="text-xl sm:text-2xl font-black text-gray-900 tracking-tight leading-tight">Payment Policy</h2>
        <p className="text-[10px] font-bold text-gray-400">Last Updated: July 5, 2026</p>
      </div>

      <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 text-xs font-semibold text-emerald-800 leading-relaxed flex gap-3">
        <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold uppercase tracking-wider block mb-1">🔒 Security First</span>
          All transactions on this Platform are processed through SSL/TLS encrypted connections and PCI-DSS certified payment gateways. We never store your card details.
        </div>
      </div>

      <div className="bg-white rounded-xl p-5 border border-gray-100 shadow-xs space-y-6 text-xs sm:text-sm text-gray-600 font-semibold leading-relaxed">
        
        {/* Section 1 */}
        <div className="space-y-3">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-indigo-500" />
            SECTION 1 — ACCEPTED &amp; NON-ACCEPTED PAYMENT METHODS
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pl-6 border-l-2 border-gray-100 text-xs">
            <div className="bg-emerald-50/30 p-3 rounded-lg border border-emerald-100 space-y-1.5">
              <span className="font-bold text-emerald-800 block">✅ ACCEPTED METHODS</span>
              <ul className="list-disc pl-4 space-y-0.5 text-emerald-900 font-medium">
                <li>UPI (GPay, PhonePe, Paytm, BHIM, Amazon Pay)</li>
                <li>Net Banking (All major Indian banks)</li>
                <li>Credit/Debit Cards (Visa, Mastercard, RuPay, Amex)</li>
                <li>Wallets supported by the active gateway</li>
              </ul>
            </div>
            <div className="bg-rose-50/30 p-3 rounded-lg border border-rose-100 space-y-1.5">
              <span className="font-bold text-rose-800 block">❌ NON-ACCEPTED METHODS</span>
              <ul className="list-disc pl-4 space-y-0.5 text-rose-900 font-medium">
                <li>Cash, cheques, or demand drafts</li>
                <li>Cryptocurrency (Bitcoin, USDT, etc.)</li>
                <li>International cards without gateway support</li>
                <li>Direct transfers to individual UPI/Bank accounts</li>
                <li>EMI or installment options</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Section 2 */}
        <div className="space-y-3 pt-4 border-t border-gray-50">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            SECTION 2 — PAYMENT SECURITY STANDARDS
          </h3>
          <div className="space-y-2.5 pl-6 border-l-2 border-gray-100">
            <p>
              <span className="text-gray-900 font-bold">2.1 Encryption:</span> All checkout sequences are encrypted. Verify "https://" and the lock indicator in the browser address bar before paying.
            </p>
            <p>
              <span className="text-gray-900 font-bold">2.2 Card Data Safety:</span> We never log, store, or transmit full card numbers, CVVs, expiry credentials, or Net banking passwords. Everything is processed directly through PCI-DSS certified gateway hosts.
            </p>
            <p className="bg-amber-50 border border-amber-100 p-3 rounded-lg text-[11px] text-amber-800 font-bold">
              ⚠️ Critical UPI Verification: When completing a UPI payment, verify that the payee/merchant title in your UPI app matches our registered business name. If an unfamiliar individual name is displayed, cancel immediately.
            </p>
            <p className="text-rose-700 font-bold">
              We will NEVER ask you to share OTPs, pay via UPI "collect requests", transfer to personal mobile numbers, or provide net banking passwords.
            </p>
          </div>
        </div>

        {/* Section 3 */}
        <div className="space-y-2.5 pt-4 border-t border-gray-50">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-[#ee2c24]" />
            SECTION 3 — TRANSACTION PROCESSING &amp; DELIVERY
          </h3>
          <div className="space-y-2 pl-6 border-l-2 border-gray-100">
            <p>Your transaction is complete when the gateway transmits success signals (typically 0–60 seconds). Do not refresh the checkout portal during this sequence.</p>
            <p>Successful payment automatically triggers the delivery API. Diamonds are credited to your UID within minutes. We cannot authorize delivery without confirmed gateway clearance signals.</p>
            <p className="font-bold text-gray-800">Ensure you save the UTR reference number returned by your bank for any verification tickets.</p>
          </div>
        </div>

        {/* Section 4 */}
        <div className="space-y-3 pt-4 border-t border-gray-50">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-orange-500" />
            SECTION 4 — FAILED PAYMENTS &amp; TEMPORARY DEDUCTIONS
          </h3>
          <div className="space-y-2 pl-6 border-l-2 border-gray-100">
            <p>If a gateway transaction fails, no diamonds are credited. Any pending bank debit is a temporary bank hold, typically released automatically within 3 to 7 business days by your financial institution.</p>
            <p className="font-bold text-orange-800">Do NOT place repetitive orders to avoid cumulative bank holds on your account.</p>
            <p>
              <span className="font-bold text-gray-900 block">Funds Deducted but Order Failed?</span>
              Submit a support ticket within 48 hours containing: your bank statement snippet showing the debit, the exact transaction amount/timestamp, and the bank UTR reference. Verified payments will either be delivered or refunded within 7 days.
            </p>
          </div>
        </div>

        {/* Section 5, 6 & 7 */}
        <div className="space-y-3 pt-4 border-t border-gray-50">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <FileText className="w-4 h-4 text-teal-500" />
            SECTION 5, 6, 7 &amp; 8 — PRICING, TAXES &amp; RISK CHECKS
          </h3>
          <div className="space-y-2 pl-6 border-l-2 border-gray-100">
            <p>All prices are locked at checkout in Indian Rupees (INR). Bank surcharges or exchange rates for non-INR accounts are your sole responsibility. Displayed values include applicable GST under the Goods and Services Tax Act 2017.</p>
            <p>Our security system may queue high-risk transactions for manual review (holding delivery for up to 6 hours). If contacted to verify identity, failure to respond within 12 hours will cancel and refund the order.</p>
            <p>Accidental double payments must be reported with dual UTR numbers within 24 hours to qualify for bank refunds. Otherwise, duplicate orders will trigger automatic secondary diamond deliveries.</p>
          </div>
        </div>

        {/* Support email contact */}
        <div className="pt-4 border-t border-gray-50 text-[11px] text-gray-400">
          For further questions or inquiries, please contact our Legal department at <a href="mailto:contactgarenaffmax@gmail.com" className="text-[#ee2c24] underline">contactgarenaffmax@gmail.com</a>.
        </div>
      </div>
    </motion.div>
  );
}
