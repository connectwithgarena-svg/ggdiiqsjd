import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, HelpCircle, Loader2, Sparkles, Heart, LogOut, ArrowRight, Globe } from 'lucide-react';
import { PlayerData, PageRoute } from '../types';
import { REGIONS_MAP } from '../lib/regions';
import { loginPlayer } from '../lib/loginPlayer';

interface HomeProps {
  isLoggedIn: boolean;
  uid: string;
  playerData: PlayerData | null;
  playerRegion: string;
  onLoginSuccess: (data: PlayerData, uid: string, region: string) => void;
  onLogout: () => void;
  onOpenUIDGuide: () => void;
  onOpenErrorModal: (message: string) => void;
  setRoute: (route: PageRoute) => void;
}

export default function Home({
  isLoggedIn,
  uid,
  playerData,
  playerRegion,
  onLoginSuccess,
  onLogout,
  onOpenUIDGuide,
  onOpenErrorModal,
  setRoute
}: HomeProps) {
  const [inputUid, setInputUid] = useState('');
  const [region, setRegion] = useState('ind');
  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputUid.trim()) {
      onOpenErrorModal('Please enter your Player UID');
      return;
    }

    setLoading(true);
    setStatusMessage('Connecting to game servers...');

    const verifierTimeout = setTimeout(() => {
      setStatusMessage('Verifying Player UID against regional registry...');
    }, 800);

    try {
      const data = await loginPlayer(inputUid, region);
      clearTimeout(verifierTimeout);
      setStatusMessage('Login Successful!');
      
      // Call the parent handler
      onLoginSuccess(data, inputUid.trim(), region);
    } catch (err: any) {
      clearTimeout(verifierTimeout);
      console.error(err);
      setStatusMessage('');
      onOpenErrorModal(err.message || 'Network error encountered. Gateway timed out. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Banner Box */}
      <div className="relative w-full h-24 sm:h-28 rounded-2xl overflow-hidden shadow-md">
        <div 
          className="absolute inset-0 bg-cover bg-center" 
          style={{ backgroundImage: 'url("/assets/ff_banner.webp")' }}
          role="img"
          aria-label="Free Fire and Free Fire MAX promotional diamond banner"
        />
        <div className="absolute inset-0 bg-black/35 backdrop-brightness-95" />
        <div className="relative h-full flex items-center p-4 sm:p-6 gap-4 sm:gap-5">
          <img 
            src="/assets/icon.webp"
            alt="Free Fire MAX game icon for diamond top-up"
            loading="eager"
            fetchPriority="high"
            decoding="async"
            referrerPolicy="no-referrer"
            className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl border-2 border-white/60 shadow-lg object-cover transition-transform hover:scale-105 duration-300"
            onError={(e) => {
              (e.target as HTMLImageElement).src = "/assets/icon.png";
            }}
          />
          <div className="text-left space-y-1">
            <h1 className="text-base sm:text-lg font-black text-white tracking-tight drop-shadow-md">
              Free Fire Diamond Top-Up
            </h1>
            <div className="flex flex-wrap items-center gap-1.5">
              <div className="inline-flex items-center gap-1 bg-black/55 backdrop-blur-xs border border-white/10 px-2 py-0.5 rounded-md text-[9px] font-bold text-white uppercase tracking-wider shadow-sm">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                100% SECURE PAYMENTS
              </div>
            </div>
          </div>
        </div>
      </div>

      {isLoggedIn && playerData ? (
        /* Player Profile Card */
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl p-5 border border-gray-100 shadow-xs space-y-5 text-left"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5 text-gray-800 font-extrabold text-sm">
              <span className="flex items-center justify-center bg-[#ee2c24] text-white w-5 h-5 rounded font-bold text-xs">
                ✓
              </span>
              Active Player Session
            </div>
            <button
              onClick={onLogout}
              className="text-xs text-gray-400 hover:text-[#ee2c24] font-bold flex items-center gap-1 cursor-pointer transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              Logout
            </button>
          </div>

          {/* Profile Card Header with Avatar and Basic Info */}
          <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 flex items-center gap-4">
            <img
              src={`https://gatway-seven.vercel.app/gateway?img=${playerData.basicInfo.headPic || '902000162'}`}
              alt={`Free Fire verified player avatar for ${playerData.basicInfo.nickname}`}
              className="w-14 h-14 rounded-full border-2 border-[#ee2c24] object-cover bg-gray-200 shadow-xs"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/assets/icon.png';
              }}
            />
            <div className="space-y-1 min-w-0 flex-1">
              <h2 className="text-base font-black text-gray-800 uppercase tracking-tight truncate">
                {playerData.basicInfo.nickname}
              </h2>
              <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[10px] text-gray-400 font-bold">
                <span>UID: <span className="text-gray-700 font-extrabold">{uid}</span></span>
                <span>|</span>
                <span className="flex items-center gap-0.5 uppercase">
                  <Globe className="w-3 h-3 text-gray-400 animate-pulse" />
                  {playerRegion}
                </span>
              </div>
            </div>
          </div>

          {/* Level, Likes and Guild specs */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="bg-gray-50 border border-gray-100 rounded-lg p-2.5 space-y-0.5 text-center">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Level</span>
              <span className="font-extrabold text-gray-800 text-sm">{playerData.basicInfo.level}</span>
            </div>
            <div className="bg-gray-50 border border-gray-100 rounded-lg p-2.5 space-y-0.5 text-center">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Likes</span>
              <span className="font-extrabold text-emerald-600 text-sm flex items-center justify-center gap-1">
                <Heart className="w-3.5 h-3.5 fill-emerald-500 text-emerald-500" />
                {(playerData.basicInfo.liked || 0).toLocaleString()}
              </span>
            </div>
          </div>

          {/* Guild affiliation info row */}
          {playerData.clanBasicInfo?.clanName && (
            <div className="bg-gray-50 border border-gray-100 rounded-xl p-3 flex justify-between items-center text-xs">
              <span className="font-bold text-gray-400 uppercase tracking-wider text-[10px]">Guild Affiliation</span>
              <span className="font-extrabold text-[#ee2c24] uppercase tracking-wide">
                {playerData.clanBasicInfo.clanName}
              </span>
            </div>
          )}

          {/* Main CTA buttons */}
          <div className="space-y-2.5 pt-1">
            <button
              onClick={() => setRoute('diamond')}
              className="w-full bg-[#ee2c24] hover:bg-red-600 text-white font-extrabold py-3.5 px-4 rounded-xl text-xs uppercase tracking-wider shadow-md shadow-red-500/15 cursor-pointer flex items-center justify-center gap-1.5 transition-all active:scale-[0.98]"
            >
              <span>Browse Diamond Packages</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            
            <button
              onClick={onLogout}
              className="w-full bg-gray-50 hover:bg-gray-100 text-gray-500 font-bold py-2.5 rounded-xl text-xs uppercase tracking-wide cursor-pointer border border-gray-200 transition-all active:scale-[0.98]"
            >
              Switch Account / Change UID
            </button>
          </div>
        </motion.div>
      ) : (
        /* Login Card */
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl p-5 border border-gray-100 shadow-xs space-y-4"
        >
          <div className="flex items-center gap-2.5 text-gray-800 font-extrabold text-sm">
            <span className="flex items-center justify-center bg-[#ee2c24] text-white w-5 h-5 rounded font-bold text-xs">
              1
            </span>
            <h2 className="text-sm font-extrabold text-gray-800">
              Enter Player UID for Instant Diamond Delivery
            </h2>
          </div>

          <form onSubmit={handleLogin} className="space-y-4 text-left">
            {/* Region Select */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Server Region</label>
              <select
                value={region}
                onChange={(e) => setRegion(e.target.value)}
                disabled={loading}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm font-semibold text-gray-700 outline-hidden focus:border-[#ee2c24] transition-colors cursor-pointer"
              >
                {REGIONS_MAP.map((reg) => (
                  <option key={reg.value} value={reg.value}>
                    {reg.label}
                  </option>
                ))}
              </select>
            </div>

            {/* UID Input */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Player UID</label>
                <button
                  type="button"
                  onClick={onOpenUIDGuide}
                  className="text-xs text-[#ee2c24] font-bold flex items-center gap-1 cursor-pointer hover:underline"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  Find UID Guide
                </button>
              </div>
              
              <div className="flex gap-2.5">
                <div className="relative flex-1">
                  <input
                    type="number"
                    placeholder="Enter your Free Fire Player UID"
                    value={inputUid}
                    onChange={(e) => setInputUid(e.target.value)}
                    disabled={loading}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm font-semibold text-gray-800 outline-hidden focus:border-[#ee2c24] transition-colors"
                  />
                </div>
                <button
                  type="submit"
                  disabled={loading || !inputUid.trim()}
                  className="bg-[#ee2c24] hover:bg-red-600 disabled:bg-red-300 text-white font-extrabold px-6 rounded-xl transition-all shadow-md shadow-red-500/15 flex items-center gap-2 cursor-pointer text-sm"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Verify
                    </>
                  ) : (
                    'Login'
                  )}
                </button>
              </div>
            </div>
          </form>

          {/* Status Line */}
          {statusMessage && (
            <div className="text-center">
              <p className="text-xs font-bold text-emerald-600 animate-pulse flex items-center justify-center gap-1.5">
                <Sparkles className="w-4 h-4" />
                {statusMessage}
              </p>
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
}
