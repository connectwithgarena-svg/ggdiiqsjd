import { motion } from 'motion/react';
import { AlertTriangle, CheckCircle, XCircle, RefreshCw, FileText, HelpCircle } from 'lucide-react';

export default function Refund() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-6 text-left"
    >
      {/* Editorial Header */}
      <div className="space-y-2">
        <span className="text-[10px] font-black tracking-widest text-[#ee2c24] uppercase">Legal Desk</span>
        <h2 className="text-xl sm:text-2xl font-black text-gray-900 tracking-tight leading-tight">Refund &amp; Cancellation Policy</h2>
        <p className="text-[10px] font-bold text-gray-400">Last Updated: July 5, 2026</p>
      </div>

      <div className="bg-rose-50 border border-rose-200 rounded-xl p-4 text-xs font-semibold text-rose-800 leading-relaxed flex gap-3">
        <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Core Principle: All Sales Are Final</span>
          Due to the instantaneous and irreversible nature of digital in-game currency delivery, refunds are an exception, not a right. We evaluate every refund request against strict criteria.
        </div>
      </div>

      <div className="bg-white rounded-xl p-5 border border-gray-100 shadow-xs space-y-6 text-xs sm:text-sm text-gray-600 font-semibold leading-relaxed">
        
        {/* Section 1 - Non-Refundable */}
        <div className="space-y-3">
          <h3 className="text-sm font-black text-rose-700 uppercase tracking-wide flex items-center gap-2">
            <XCircle className="w-4 h-4 text-rose-500" />
            SECTION 1 — ABSOLUTE NON-REFUNDABLE SITUATIONS
          </h3>
          <p className="text-gray-500 font-bold pl-6">
            We will NOT process a refund under any of the following circumstances. No exceptions. No appeals. Final.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pl-6">
            <div className="bg-gray-50 p-3 rounded-lg border border-gray-100 space-y-1">
              <span className="text-rose-600 font-bold flex items-center gap-1">❌ Incorrect UID</span>
              <p className="text-[11px] text-gray-500">You were shown your character name and level on the verification screen before payment — you confirmed and proceeded.</p>
            </div>
            <div className="bg-gray-50 p-3 rounded-lg border border-gray-100 space-y-1">
              <span className="text-rose-600 font-bold flex items-center gap-1">❌ Server Region Mismatch</span>
              <p className="text-[11px] text-gray-500">Selecting the correct server region matching your Free Fire account is your sole responsibility.</p>
            </div>
            <div className="bg-gray-50 p-3 rounded-lg border border-gray-100 space-y-1">
              <span className="text-rose-600 font-bold flex items-center gap-1">❌ Change of Mind</span>
              <p className="text-[11px] text-gray-500">Digital goods are non-returnable once delivery is triggered automatically.</p>
            </div>
            <div className="bg-gray-50 p-3 rounded-lg border border-gray-100 space-y-1">
              <span className="text-rose-600 font-bold flex items-center gap-1">❌ Game Account Bans</span>
              <p className="text-[11px] text-gray-500">We have no visibility into Garena account ban status before or after delivery. Bans due to gameplay violations do not entitle refunds.</p>
            </div>
            <div className="bg-gray-50 p-3 rounded-lg border border-gray-100 space-y-1">
              <span className="text-rose-600 font-bold flex items-center gap-1">❌ Unused Diamonds</span>
              <p className="text-[11px] text-gray-500">If you simply did not spend the delivered diamonds, you are not eligible for a refund.</p>
            </div>
            <div className="bg-gray-50 p-3 rounded-lg border border-gray-100 space-y-1">
              <span className="text-rose-600 font-bold flex items-center gap-1">❌ Unauthorized Payment Claims</span>
              <p className="text-[11px] text-gray-500">Transactions made using third-party payment details without consent will not be refunded post-delivery.</p>
            </div>
            <div className="bg-gray-50 p-3 rounded-lg border border-gray-100 col-span-1 sm:col-span-2 space-y-1">
              <span className="text-rose-600 font-bold flex items-center gap-1">❌ Late Claims &amp; Missing Info</span>
              <p className="text-[11px] text-gray-500">Refund requests submitted more than 48 hours after the transaction, or requests lacking a verified UTR/Transaction Reference number, are automatically rejected.</p>
            </div>
          </div>
        </div>

        {/* Section 2 - Eligible Conditions */}
        <div className="space-y-3 pt-4 border-t border-gray-50">
          <h3 className="text-sm font-black text-emerald-700 uppercase tracking-wide flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-500" />
            SECTION 2 — CONDITIONS WHERE REFUND MAY BE ELIGIBLE
          </h3>
          <p className="text-gray-500 font-bold pl-6">
            A refund <span className="text-emerald-600">WILL BE CONSIDERED</span> only if ALL of the following conditions are simultaneously true. Partial fulfillment does not qualify:
          </p>
          <ul className="grid grid-cols-1 gap-2 pl-6 text-gray-600 font-bold">
            <li className="flex items-start gap-2 text-xs bg-emerald-50/50 p-2.5 rounded-lg border border-emerald-100">
              <span className="text-emerald-600 shrink-0 mt-0.5">✅</span>
              <div>
                <span className="text-gray-800 block">Condition 1: Payment successfully deducted</span>
                <span className="text-[11px] text-gray-500 font-normal">Deduction is verified on your bank statement or payment application records.</span>
              </div>
            </li>
            <li className="flex items-start gap-2 text-xs bg-emerald-50/50 p-2.5 rounded-lg border border-emerald-100">
              <span className="text-emerald-600 shrink-0 mt-0.5">✅</span>
              <div>
                <span className="text-gray-800 block">Condition 2: Gateway Status "Successful"</span>
                <span className="text-[11px] text-gray-500 font-normal">The payment processor registers the status as successfully cleared.</span>
              </div>
            </li>
            <li className="flex items-start gap-2 text-xs bg-emerald-50/50 p-2.5 rounded-lg border border-emerald-100">
              <span className="text-emerald-600 shrink-0 mt-0.5">✅</span>
              <div>
                <span className="text-gray-800 block">Condition 3: Non-Delivery after 24 Hours</span>
                <span className="text-[11px] text-gray-500 font-normal">Diamonds were not credited within 24 hours of the payment timestamp.</span>
              </div>
            </li>
            <li className="flex items-start gap-2 text-xs bg-emerald-50/50 p-2.5 rounded-lg border border-emerald-100">
              <span className="text-emerald-600 shrink-0 mt-0.5">✅</span>
              <div>
                <span className="text-gray-800 block">Condition 4: Timely Ticket &amp; Server Verification</span>
                <span className="text-[11px] text-gray-500 font-normal">Support request filed within 48 hours, and our internal server logs confirm that diamonds were indeed not delivered.</span>
              </div>
            </li>
          </ul>
        </div>

        {/* Section 3 - Request Procedure */}
        <div className="space-y-3 pt-4 border-t border-gray-50">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <RefreshCw className="w-4 h-4 text-indigo-500" />
            SECTION 3 — REFUND REQUEST PROCEDURE
          </h3>
          <div className="space-y-3 pl-6 border-l-2 border-gray-100 text-xs">
            <p className="font-bold">Follow this procedure exactly. Deviations will delay or invalidate your request:</p>
            <div className="space-y-2">
              <p><span className="text-[#ee2c24] font-bold">Step 1 — Wait the Full 24 Hours:</span> Do not submit a ticket before 24 hours have elapsed. Early tickets will be rejected.</p>
              <p><span className="text-[#ee2c24] font-bold">Step 2 — Submit a Support Ticket:</span> Navigate to our Contact page and provide: Full Name, Player UID, Server Region, Package purchased, UTR / Transaction Reference Number, clear payment screenshot, and in-game diamond balance screenshots before/after.</p>
              <p><span className="text-[#ee2c24] font-bold">Step 3 — Do NOT File a Bank Dispute:</span> Do NOT initiate a chargeback or bank dispute while a support ticket is open. Doing so immediately voids your refund eligibility and is treated as fraud.</p>
              <p><span className="text-[#ee2c24] font-bold">Step 4 — Await Investigation (3–5 Business Days):</span> Our risk team will cross-reference gateway records and delivery server logs.</p>
              <p><span className="text-[#ee2c24] font-bold">Step 5 — Decision:</span> If delivery failure is confirmed, full refund is credited to the original payment method in 7–10 business days. Otherwise, the ticket is final closed.</p>
            </div>
          </div>
        </div>

        {/* Section 4 */}
        <div className="space-y-2.5 pt-4 border-t border-gray-50">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <FileText className="w-4 h-4 text-purple-500" />
            SECTION 4 — REFUND METHOD
          </h3>
          <p className="pl-6 border-l-2 border-gray-100">
            Approved refunds will <span className="font-bold text-gray-800">ONLY</span> be processed to the original payment method used for the purchase. We do NOT issue refunds in cash, cheque, to a different bank account, or in cryptocurrency. Cleared funds take 7–10 business days, governed by your bank's policies.
          </p>
        </div>

        {/* Section 5 */}
        <div className="space-y-2.5 pt-4 border-t border-gray-50">
          <h3 className="text-sm font-black text-gray-800 uppercase tracking-wide flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-teal-500" />
            SECTION 5 &amp; 6 — CANCELLATION &amp; FRAUD DETECTION
          </h3>
          <div className="space-y-2 pl-6 border-l-2 border-gray-100">
            <p>You may abandon any transaction before payment is cleared. Once payment is confirmed, cancellation is not possible as delivery is instant.</p>
            <p>We actively analyze refund request patterns. Multiple claims, claims with prior chargebacks, claims contradicted by our delivery logs, or claims backed by manipulated screenshots are blocked. Fraudulent claims will trigger permanent blacklist blocks.</p>
          </div>
        </div>

        {/* Support email contact */}
        <div className="pt-4 border-t border-gray-50 text-[11px] text-gray-400">
          For further questions or inquiries, please contact our Legal department at <a href="mailto:contactgarenaffmax@gmail.com" className="text-[#ee2c24] underline">contactgarenaffmax@gmail.com</a>.
        </div>
      </div>
    </motion.div>
  );
}
