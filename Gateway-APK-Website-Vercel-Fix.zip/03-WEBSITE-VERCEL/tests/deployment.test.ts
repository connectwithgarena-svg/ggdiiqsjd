import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile, mkdir, mkdtemp, writeFile, rm } from 'node:fs/promises';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import ts from 'typescript';
import app from '../api/index';
test('Vercel entry exports existing Express API without starting a listener; SPA rewrite preserves API routes', async () => {
  const server = app.listen(0,'127.0.0.1');
  await new Promise<void>(r=>server.once('listening',r));
  try {
    const origin=`http://127.0.0.1:${(server.address() as any).port}`;
    const reviews=await fetch(origin+'/api/reviews'); assert.equal(reviews.status,200);
    const status=await fetch(origin+'/api/payment/status/invalid'); assert.equal(status.status,401);
    const cancel=await fetch(origin+'/api/payment/cancel/invalid',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}); assert.equal(cancel.status,401);
    const support=await fetch(origin+'/api/support',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}); assert.equal(support.status,400);
    const config=JSON.parse(await readFile('vercel.json','utf8'));
    assert.equal(config.framework,'vite');assert.equal(config.outputDirectory,'dist');
    assert.equal(config.rewrites[0].destination,'/api/index');
    assert.equal(config.crons[0].path,'/api/payment/retry-alerts');
  } finally { await new Promise<void>(r=>server.close(()=>r())); }
});

// tsx and bundlers resolve extensionless imports that deployed native Node ESM rejects.
test('emitted Vercel API dependency graph starts in native Node ESM without a TypeScript loader', async () => {
  const root = process.cwd();
  const cache = path.join(root, 'node_modules/.cache');
  await mkdir(cache, { recursive: true });
  const output = await mkdtemp(path.join(cache, 'vercel-esm-'));
  try {
    await writeFile(path.join(output, 'package.json'), JSON.stringify({ type: 'module' }));
    const visited = new Set<string>();
    async function emit(relative: string) {
      if (visited.has(relative)) return;
      visited.add(relative);
      const source = await readFile(path.join(root, relative), 'utf8');
      const code = ts.transpileModule(source, { fileName: relative, compilerOptions: {
        module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022, esModuleInterop: true,
      }}).outputText;
      const destination = path.join(output, relative.replace(/\.ts$/, '.js'));
      await mkdir(path.dirname(destination), { recursive: true });
      await writeFile(destination, code);
      for (const imported of ts.preProcessFile(code).importedFiles) {
        if (!imported.fileName.startsWith('.')) continue;
        const resolved = path.normalize(path.join(path.dirname(relative), imported.fileName));
        await emit(resolved.endsWith('.js') ? resolved.slice(0, -3) + '.ts' : resolved + '.ts');
      }
    }
    await emit('api/index.ts');
    const script = `
      import assert from 'node:assert/strict';
      import app from './api/index.js';
      const server = app.listen(0, '127.0.0.1');
      await new Promise(r => server.once('listening', r));
      try {
        const origin = 'http://127.0.0.1:' + server.address().port;
        for (const [route, method, expected] of [
          ['/api/reviews', 'GET', 200],
          ['/api/payment/status/invalid', 'GET', 401],
          ['/api/payment/create', 'POST', 401],
          ['/api/payment/cancel/invalid', 'POST', 401],
          ['/api/payment/webhook', 'POST', 401],
        ]) {
          const response = await fetch(origin + route, { method,
            ...(method === 'POST' ? {headers: {'Content-Type': 'application/json'}, body: '{}'} : {}) });
          assert.equal(response.status, expected, route);
        }
        console.log('Native ESM API startup and routes passed');
      } finally { await new Promise(r => server.close(r)); }
    `;
    await writeFile(path.join(output, 'smoke.mjs'), script);
    const { stdout } = await promisify(execFile)(process.execPath, ['smoke.mjs'], {
      cwd: output, timeout: 15000, env: { ...process.env, NODE_OPTIONS: '' },
    });
    assert.match(stdout, /Native ESM API startup and routes passed/);
  } finally { await rm(output, { recursive: true, force: true }); }
});
