import { test } from 'node:test';
import assert from 'node:assert/strict';
import { trackPaymentEvent, verifiedSuccess } from '../src/lib/payments';
test('Meta checkout and verified Purchase fire once per order, with no customer PII', () => {
  const events: any[] = [], stored = new Map<string,string>();
  (globalThis as any).window = { fbq: (...args: any[]) => events.push(args) };
  (globalThis as any).localStorage = { getItem: (key: string) => stored.get(key), setItem: (key: string,value: string) => stored.set(key,value) };
  trackPaymentEvent('InitiateCheckout','order-1',550,2180);
  trackPaymentEvent('InitiateCheckout','order-1',550,2180);
  let successes=0;
  const order: any = { id:'order-1',status:'pending',payableAmount:'551.14',diamonds:2180,email:'not-for-analytics@example.test' };
  verifiedSuccess(order, () => successes++);
  assert.equal(successes,0); assert.equal(events.length,1);
  verifiedSuccess({...order,status:'paid'}, () => successes++);
  verifiedSuccess({...order,status:'paid'}, () => successes++);
  assert.equal(events.length,2); assert.equal(events[1][1],'Purchase'); assert.equal(events[1][2].value,551.14);
  assert.equal(events[1][3].eventID,'Purchase_order-1'); assert.ok(!JSON.stringify(events).includes(order.email));
});
test('blocked storage or a broken analytics script cannot prevent verified success', () => {
  (globalThis as any).window = { fbq: () => { throw new Error('Analytics blocked'); } };
  (globalThis as any).localStorage = { getItem: () => { throw new Error('Storage blocked'); } };
  let paid = false;
  verifiedSuccess({ id:'paid',status:'paid',payableAmount:'551.14',diamonds:2180 } as any, () => { paid=true; });
  assert.equal(paid,true);
});
