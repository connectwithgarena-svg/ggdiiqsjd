import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { randomUUID, randomBytes, createHmac } from 'node:crypto';
import express from 'express';
import { PGlite } from '@electric-sql/pglite';
import { paymentRouter, flushAlerts } from '../backend/payments';
import { Gateway, PaymentError, type GatewayPayment } from '../backend/gateway';
import type { Database } from '../backend/database';
import { ensureOrderNumber } from '../backend/orderNumbers';

const pg = new PGlite();
function adapter(client: any): Database {
  return { query: (sql, params) => client.query(sql, params), transaction: fn => client.transaction((tx: any) => fn(adapter(tx))) };
}
const db = adapter(pg);
let server: any, origin: string, calls = 0, telegramCalls = 0, telegramFail = false;
const payments = new Map<string, GatewayPayment>();
const env = { TELEGRAM_BOT_TOKEN: 'synthetic-test-token', TELEGRAM_CHAT_ID: 'old-chat', SUCCESS_TELEGRAM_BOT_TOKEN: 'synthetic-success-token', SUCCESS_TELEGRAM_CHAT_ID: 'success-chat', PAYMENT_WEBHOOK_SECRET: 'synthetic-webhook-secret', CRON_SECRET: 'synthetic-cron' };
const transport: typeof fetch = async (_url, options) => {
  telegramCalls++;
  assert.equal(String(_url), 'https://api.telegram.org/botsynthetic-success-token/sendMessage');
  const message = JSON.parse(String(options?.body));
  assert.equal(message.chat_id, 'success-chat');
  assert.match(message.text, /Order: GORDNO123456789[0-9]{6}\n/);
  for (const field of ['Name: Synthetic Customer','Mobile: 9000000000','Email: synthetic@example.test','Player UID: 123456789','Player: Test Player','Level: 55','Diamonds: 2180','Amount: ₹551.14']) assert.ok(message.text.includes(field), field);
  assert.ok(!String(options?.body).includes('CVV'));
  return new Response(JSON.stringify({ ok: !telegramFail }), { status: telegramFail ? 503 : 200 });
};
const gateway = {
  async create(order: any) {
    calls++;
    if (payments.has(order.id)) return payments.get(order.id)!;
    const now = Date.now(), amount = ((order.requested + 114) / 100).toFixed(2);
    const p = { id: 'pay_' + order.id, external_id: order.id, profile: 'bharatpe', status: 'pending', requested_amount: (order.requested / 100).toFixed(2), payable_amount: amount,
      upi_uri: `upi://pay?pa=synthetic@upi&pn=Test&cu=INR&am=${amount}`, created_at: new Date(now).toISOString(), expires_at: new Date(now + 420000).toISOString(), paid_at: null };
    payments.set(order.id, p); return p;
  },
  async get(id: string) {
    const p = [...payments.values()].find(p => p.id === id);
    if (!p) throw new PaymentError(404, 'Not found');
    return p;
  },
};
function fixture() {
  return { token: randomBytes(32).toString('hex'), body: { attemptId: randomUUID(), packageId: '1090', uid: '123456789', nickname: 'Test Player', level: 55, name: 'Synthetic Customer', mobile: '9000000000', email: 'synthetic@example.test' } };
}
async function create(f = fixture(), extra = {}) {
  const response = await fetch(origin + '/api/payment/create', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Order-Token': f.token }, body: JSON.stringify({ ...f.body, ...extra }) });
  return { response, order: await response.json(), f };
}
async function status(f: ReturnType<typeof fixture>) {
  const response = await fetch(origin + '/api/payment/status/' + f.body.attemptId, { headers: { 'X-Order-Token': f.token } });
  return { response, order: await response.json() };
}
async function webhook(p: GatewayPayment, override: Record<string, any> = {}, badSignature = false) {
  const event = { id: `${p.status}_${p.id}`, type: `payment.${p.status}`, payment: { id: p.id, external_id: p.external_id, status: p.status, requested_amount_paise: 55000, payable_amount_paise: 55114, paid_at_ms: p.paid_at ? Date.parse(p.paid_at) : undefined, ...override } };
  const raw = JSON.stringify(event), ts = Math.floor(Date.now() / 1000).toString();
  const signature = createHmac('sha256', env.PAYMENT_WEBHOOK_SECRET).update(`${ts}.${raw}`).digest('hex');
  return fetch(origin + '/api/payment/webhook', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-FFSHOP-Timestamp': ts, 'X-FFSHOP-Signature': badSignature ? '0'.repeat(64) : signature, 'X-FFSHOP-Event': event.id }, body: raw });
}
before(async () => {
  await pg.exec(await readFile('backend/schema.sql', 'utf8'));
  const app = express(); app.use('/api/payment', paymentRouter({ db, gateway, transport, env }));
  server = app.listen(0, '127.0.0.1'); await new Promise<void>(r => server.once('listening', r));
  origin = `http://127.0.0.1:${server.address().port}`;
});
after(async () => { await new Promise<void>(r => server.close(r)); await pg.close(); });

test('trusted server catalogue ignores client price; QR has exact payable amount and seven-minute deadline', async () => {
  const { response, order, f } = await create(fixture(), { price: 1, amount: 1, payableAmount: 1 });
  assert.equal(response.status, 200); assert.equal(response.headers.get('cache-control'), 'no-store');
  assert.match(order.orderNumber, /^GORDNO123456789[0-9]{6}$/);
  assert.equal(order.requestedAmount, '550.00'); assert.equal(order.taxAmount, '1.14');
  assert.equal(order.payableAmount, '551.14'); assert.equal(order.status, 'pending'); assert.match(order.qr, /^data:image\/png;base64,/);
  assert.equal(Date.parse(payments.get(f.body.attemptId)!.expires_at) - Date.parse(payments.get(f.body.attemptId)!.created_at), 420000);
  assert.ok(!JSON.stringify(order).includes('synthetic@example.test'));
});
test('concurrent create retries use one gateway order without sending any success alert', async () => {
  const f = fixture(), before = calls, beforeTelegram = telegramCalls;
  const results = await Promise.all([create(f), create(f), create(f)]);
  assert.ok(results.every(r => r.response.status === 200));
  assert.equal(calls - before, 1); assert.equal(telegramCalls - beforeTelegram, 0);
  assert.equal(new Set(results.map(r => r.order.orderNumber)).size, 1);
});
test('same attempt cannot change customer, package or capability', async () => {
  const { f } = await create();
  assert.equal((await create(f, { name: 'Different Customer' })).response.status, 409);
  assert.equal((await create({ ...f, token: randomBytes(32).toString('hex') })).response.status, 409);
  assert.equal((await status({ ...f, token: randomBytes(32).toString('hex') })).response.status, 404);
});
test('invalid customer and sold-out packages do not call gateway', async () => {
  const before = calls;
  assert.equal((await create(fixture(), { mobile: '123' })).response.status, 400);
  assert.equal((await create(fixture(), { packageId: '3180' })).response.status, 400);
  assert.equal(calls, before);
});
test('simultaneous polls and repeated webhook create one durable paid transition and alert', async () => {
  const { f } = await create(), p = payments.get(f.body.attemptId)!;
  p.status = 'paid'; p.paid_at = new Date(Date.parse(p.created_at) + 100).toISOString();
  const before = telegramCalls;
  const results = await Promise.all([status(f), status(f), webhook(p), webhook(p)]);
  assert.equal((await status(f)).order.status, 'paid');
  assert.equal((await db.query("SELECT * FROM shop_alerts WHERE order_id=$1 AND kind='paid'", [f.body.attemptId])).rows.length, 1);
  assert.equal(telegramCalls - before, 1);
  assert.equal((await webhook(p)).status, 200);
});
test('forged or mismatched callbacks cannot confirm an order', async () => {
  const { f } = await create(), p = { ...payments.get(f.body.attemptId)!, status: 'paid', paid_at: new Date().toISOString() };
  assert.equal((await webhook(p, {}, true)).status, 401);
  assert.equal((await webhook(p, { payable_amount_paise: 55000 })).status, 400);
  assert.equal((await webhook(p, { paid_at_ms: Date.parse(p.expires_at) })).status, 400);
  assert.equal((await status(f)).order.status, 'pending');
});
test('signed webhook confirms saved payment after gateway retention deletes it; local paid order survives', async () => {
  const { f } = await create(), p = payments.get(f.body.attemptId)!;
  p.status = 'paid'; p.paid_at = new Date(Date.parse(p.created_at) + 10).toISOString(); payments.delete(f.body.attemptId);
  assert.equal((await webhook(p)).status, 200);
  assert.equal((await status(f)).order.status, 'paid');
  const before = calls;
  assert.equal((await create(f)).order.status, 'paid'); assert.equal(calls, before);
});
test('expired QR disappears and deleted gateway order never becomes paid or recreated', async () => {
  const { f } = await create(), p = payments.get(f.body.attemptId)!;
  const expires = new Date(Date.now() - 1).toISOString(), created = new Date(Date.parse(expires) - 420000).toISOString();
  p.created_at = created; p.expires_at = expires;
  await db.query('UPDATE shop_orders SET gateway_created=$2,expires_at=$3 WHERE id=$1', [f.body.attemptId, created, expires]);
  const expired = await status(f); assert.equal(expired.order.status, 'expired'); assert.equal(expired.order.qr, null);
  payments.delete(f.body.attemptId);
  assert.equal((await status(f)).order.status, 'expired');
  const before = calls; assert.equal((await create(f)).order.status, 'expired'); assert.equal(calls, before);
});
test('old unpaid callback cannot downgrade paid order', async () => {
  const { f } = await create(), p = payments.get(f.body.attemptId)!;
  p.status = 'paid'; p.paid_at = new Date(Date.parse(p.created_at) + 10).toISOString(); await webhook(p);
  assert.equal((await webhook({ ...p, status: 'expired' })).status, 200);
  assert.equal((await status(f)).order.status, 'paid');
});
test('Telegram failure retains paid state and retryable outbox; retry endpoint authenticates', async () => {
  const { f } = await create(), p = payments.get(f.body.attemptId)!;
  p.status = 'paid'; p.paid_at = new Date(Date.parse(p.created_at) + 10).toISOString(); telegramFail = true;
  assert.equal((await webhook(p)).status, 503);
  assert.equal((await status(f)).order.status, 'paid');
  assert.equal((await db.query("SELECT sent_at FROM shop_alerts WHERE order_id=$1 AND kind='paid'", [f.body.attemptId])).rows[0].sent_at, null);
  telegramFail = false; await db.query('UPDATE shop_alerts SET next_at=now() WHERE order_id=$1', [f.body.attemptId]);
  assert.equal((await fetch(origin + '/api/payment/retry-alerts')).status, 401);
  assert.equal((await fetch(origin + '/api/payment/retry-alerts', { headers: { Authorization: 'Bearer ' + env.CRON_SECRET } })).status, 200);
  assert.ok((await db.query("SELECT sent_at FROM shop_alerts WHERE order_id=$1 AND kind='paid'", [f.body.attemptId])).rows[0].sent_at);
});
test('real gateway adapter sends credentials only server-side and a stable idempotency key', async () => {
  const seen: any[] = [];
  const g = new Gateway({ PAYMENT_GATEWAY_URL: 'https://gateway.example.test', PAYMENT_GATEWAY_API_KEY: 'synthetic' }, async (url, init) => { seen.push({ url, init }); return new Response('{}'); });
  const order = { id: randomUUID(), customer_name: 'Test', requested: 55000 };
  await g.create(order); await g.create(order);
  assert.equal(seen[0].init.headers['Idempotency-Key'], seen[1].init.headers['Idempotency-Key']);
  assert.equal(JSON.parse(seen[0].init.body).amount, 550);
  assert.equal(seen[0].init.cache, 'no-store');
});

test('lost gateway response retries the identical order, and stale intent cannot recreate after deletion', async () => {
  const f = fixture(), original = gateway.create;
  gateway.create = async order => { const p = await original(order); throw new PaymentError(502, 'Lost response'); };
  try { assert.equal((await create(f)).response.status, 502); } finally { gateway.create = original; }
  const first = payments.get(f.body.attemptId)!;
  assert.equal((await create(f)).response.status, 200);
  assert.equal(payments.get(f.body.attemptId)!.id, first.id);
  const stale = fixture();
  gateway.create = async order => { await original(order); throw new PaymentError(502, 'Lost response'); };
  try { assert.equal((await create(stale)).response.status, 502); } finally { gateway.create = original; }
  await db.query("UPDATE shop_orders SET created_at=now()-interval '30 minutes' WHERE id=$1", [stale.body.attemptId]);
  payments.delete(stale.body.attemptId);
  const before = calls;
  assert.equal((await create(stale)).order.status, 'expired'); assert.equal(calls, before);
});
test('authenticated status rejects changed amount, profile and payment time', async () => {
  const { f } = await create(), p = payments.get(f.body.attemptId)!;
  p.payable_amount = '551.15'; assert.equal((await status(f)).response.status, 502);
  p.payable_amount = '551.14'; p.profile = 'paytm'; assert.equal((await status(f)).response.status, 502);
  p.profile = 'bharatpe'; p.status = 'paid'; p.paid_at = p.expires_at; assert.equal((await status(f)).response.status, 502);
  p.status = 'pending'; p.paid_at = null;
});
test('expired signatures cannot be replayed', async () => {
  const ts = String(Math.floor(Date.now()/1000)-301), raw = '{}';
  const signature = createHmac('sha256', env.PAYMENT_WEBHOOK_SECRET).update(`${ts}.${raw}`).digest('hex');
  const response = await fetch(origin + '/api/payment/webhook', { method: 'POST', headers: { 'Content-Type':'application/json', 'X-FFSHOP-Timestamp':ts, 'X-FFSHOP-Signature':signature }, body:raw });
  assert.equal(response.status, 401);
});

test('missing success-bot configuration never falls back to the existing bot', async () => {
  const previous = env.SUCCESS_TELEGRAM_BOT_TOKEN;
  env.SUCCESS_TELEGRAM_BOT_TOKEN = '';
  const before = telegramCalls;
  try { assert.equal((await create()).response.status, 503); }
  finally { env.SUCCESS_TELEGRAM_BOT_TOKEN = previous; }
  assert.equal(telegramCalls, before);
});
test('old queued created alerts are not resent by the success-alert worker', async () => {
  const { f } = await create();
  await db.query("INSERT INTO shop_alerts(order_id,kind) VALUES($1,'created')", [f.body.attemptId]);
  const before = telegramCalls;
  assert.equal(await flushAlerts(db, f.body.attemptId, transport, env), true);
  assert.equal(telegramCalls, before);
  const p = payments.get(f.body.attemptId)!;
  p.status='paid'; p.paid_at=new Date(Date.parse(p.created_at)+10).toISOString();
  assert.equal((await webhook(p)).status,200);
  assert.equal(telegramCalls-before,1);
  assert.equal((await webhook(p)).status,200);
  assert.equal(telegramCalls-before,1);
});

async function cancel(f: ReturnType<typeof fixture>) {
  const response = await fetch(origin + '/api/payment/cancel/' + f.body.attemptId, {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Order-Token': f.token }, body: '{}',
  });
  return { response, order: await response.json() };
}
test('authenticated cancellation hides QR, persists through refresh, and does not recreate the old order', async () => {
  const { f } = await create(), before = calls, beforeAlerts = telegramCalls;
  const first = await cancel(f);
  assert.equal(first.response.status,200); assert.equal(first.order.status,'cancelled'); assert.equal(first.order.qr,null);
  assert.equal((await cancel(f)).order.status,'cancelled');
  assert.equal((await status(f)).order.status,'cancelled');
  assert.equal((await create(f)).order.status,'cancelled'); assert.equal(calls,before);
  assert.equal(telegramCalls,beforeAlerts);
  // Website-only cancellation never releases/reuses the existing gateway reservation.
  assert.equal(payments.get(f.body.attemptId)!.status,'pending');
});
test('another order capability cannot cancel a payment', async () => {
  const { f } = await create();
  assert.equal((await cancel({...f,token:randomBytes(32).toString('hex')})).response.status,404);
  assert.equal((await status(f)).order.status,'pending');
});
test('a payment confirmed before cancellation wins and sends one success alert', async () => {
  const { f } = await create(), p=payments.get(f.body.attemptId)!;
  p.status='paid'; p.paid_at=new Date(Date.parse(p.created_at)+10).toISOString();
  const before=telegramCalls;
  const [cancelled, checked] = await Promise.all([cancel(f), status(f)]);
  assert.equal(cancelled.order.status,'paid'); assert.equal(checked.order.status,'paid');
  assert.equal((await cancel(f)).order.status,'paid'); assert.equal(telegramCalls-before,1);
});
test('gateway error during cancellation does not falsely confirm cancellation', async () => {
  const { f } = await create(), original=gateway.get;
  gateway.get=async()=>{throw new PaymentError(502,'Gateway temporarily unavailable');};
  try { assert.equal((await cancel(f)).response.status,502); }
  finally { gateway.get=original; }
  assert.equal((await status(f)).order.status,'pending');
});
test('a delayed authentic receipt still records real money after website cancellation', async () => {
  const { f } = await create(), p=payments.get(f.body.attemptId)!;
  assert.equal((await cancel(f)).order.status,'cancelled');
  const before=telegramCalls;
  p.status='paid'; p.paid_at=new Date(Date.parse(p.created_at)+10).toISOString();
  assert.equal((await webhook(p)).status,200);
  assert.equal((await webhook(p)).status,200);
  assert.equal((await status(f)).order.status,'paid'); assert.equal(telegramCalls-before,1);
});
test('an uncertain creating intent can be cancelled and must not generate a new QR on retry', async () => {
  const f=fixture(), original=gateway.create;
  gateway.create=async order=>{await original(order);throw new PaymentError(502,'Lost response');};
  try { assert.equal((await create(f)).response.status,502); } finally {gateway.create=original;}
  const before=calls;
  assert.equal((await cancel(f)).order.status,'cancelled');
  assert.equal((await create(f)).order.status,'cancelled'); assert.equal(calls,before);
});
test('already expired payments are returned as expired when cancelling', async () => {
  const { f }=await create();payments.get(f.body.attemptId)!.status='expired';
  const result=await cancel(f); assert.equal(result.order.status,'expired');assert.equal(result.order.qr,null);
});

test('each new order has a different persistent display number while retries and status keep it', async () => {
  const first=await create(), second=await create();
  assert.notEqual(first.order.orderNumber,second.order.orderNumber);
  assert.equal((await create(first.f)).order.orderNumber,first.order.orderNumber);
  assert.equal((await status(first.f)).order.orderNumber,first.order.orderNumber);
  assert.equal((await cancel(first.f)).order.orderNumber,first.order.orderNumber);
});
test('database collision retries a new six-digit suffix without changing the internal order ID', async () => {
  const f1=fixture(),f2=fixture();f1.body.uid='765432109';f2.body.uid='765432109';
  await create(f1);await create(f2);
  await db.query('UPDATE shop_orders SET order_number=NULL WHERE id IN ($1,$2)',[f1.body.attemptId,f2.body.attemptId]);
  const first=await ensureOrderNumber(db,f1.body.attemptId,f1.body.uid,()=>111111);
  let attempts=0;
  const second=await ensureOrderNumber(db,f2.body.attemptId,f2.body.uid,()=>++attempts===1?111111:222222);
  assert.equal(first,'GORDNO765432109111111');assert.equal(second,'GORDNO765432109222222');assert.equal(attempts,2);
  assert.equal((await status(f2)).order.id,f2.body.attemptId);
});
test('Tax breakdown uses integer-paise difference for ₹0.30 and ₹1.00 without altering QR total', async () => {
  for(const adjustment of [30,100]) {
    const original=gateway.create;
    gateway.create=async order=>{const p=await original(order);p.payable_amount=((order.requested+adjustment)/100).toFixed(2);p.upi_uri=`upi://pay?pa=synthetic@upi&cu=INR&am=${p.payable_amount}`;return p;};
    try {
      const {order}=await create();
      assert.equal(order.taxAmount,(adjustment/100).toFixed(2));assert.equal(order.payableAmount,((55000+adjustment)/100).toFixed(2));
    } finally {gateway.create=original;}
  }
});
test('order-number migration is safe to repeat on the original schema and preserves existing orders', async () => {
  const legacy=new PGlite();
  try {
    const schema=await readFile('backend/schema.sql','utf8');
    await legacy.exec(schema.split('-- PostgreSQL:')[0]);
    const f=fixture();
    await legacy.query(`INSERT INTO shop_orders(id,token_hash,request_hash,package_id,uid,nickname,player_level,customer_name,mobile,email,requested,diamonds)
      VALUES($1,'token','hash','1090','123456789','Player',55,'Customer','9000000000','customer@example.test',55000,2180)`,[f.body.attemptId]);
    const migration=await readFile('backend/migrations/001-order-number.sql','utf8');
    await legacy.exec(migration);await legacy.exec(migration);
    const id=await ensureOrderNumber(adapter(legacy),f.body.attemptId,'123456789',()=>345678);
    assert.equal(id,'GORDNO123456789345678');
    assert.equal((await legacy.query<{ requested: number; status: string }>('SELECT requested,status FROM shop_orders WHERE id=$1',[f.body.attemptId])).rows[0].requested,55000);
  } finally {await legacy.close();}
});
