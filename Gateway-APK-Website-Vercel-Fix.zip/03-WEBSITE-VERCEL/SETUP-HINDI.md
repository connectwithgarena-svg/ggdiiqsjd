# Final QR-page version — setup

## Vercel API error का नया fix

`Cannot find module /var/task/server` का import fix इस version में है। Updated source files website GitHub repo के root में डालकर उसी Vercel project पर redeploy करें। Env values वही रखें। इस API fix के लिए नया SQL नहीं है; नीचे वाला पहले का GORDNO migration केवल तभी Run करें अगर अभी तक नहीं किया है।

Deploy के बाद `/api/reviews` खोलने पर JSON मिलना चाहिए। API function startup failure नहीं आनी चाहिए।

## Order-number update पहले apply नहीं किया है तो

1. Website के PostgreSQL/Neon database का **SQL Editor** खोलें। यह gateway वाला Cloudflare D1 नहीं है।
2. `backend/migrations/001-order-number.sql` का पूरा SQL Run करें। Download में यही `database-update.sql` भी दिया है। पुराने orders सुरक्षित रहेंगे; दोबारा Run करना भी सुरक्षित है।
3. Updated ZIP की अंदर वाली source files GitHub repository root में डालकर उसी Vercel project पर redeploy करें। Env values और Vercel settings वही रहेंगी।

अब QR के नीचे order number `GORDNO` + customer का game UID + 6 random digits दिखेगा। उदाहरण: `GORDNO123456789654321`। हर नए order का नया unique number होगा; refresh/retry पर वही रहेगा। Success Telegram alert में भी यही number रहेगा।

Original amount और **Tax (payment adjustment)** अलग दिखेंगे। Tax केवल gateway का पहले से जुड़ा extra amount है; total दोबारा नहीं बढ़ता। इसमें GST rate या सरकारी tax calculation नहीं जोड़ा गया है।

## इस version में

- Checkout के Pay पर पहले वाला Telegram alert अपने original दोनों requests/payloads के साथ चलता है।
- इसके बाद `/qr` अलग page खुलता है। कोई payment popup नहीं है।
- नाम, mobile, email लेने के बाद exact payable amount का QR और सात मिनट का timer दिखता है।
- Verified payment पर existing success screen और Meta Purchase चलता है।
- केवल confirmed payment की पूरी detail दूसरे Telegram bot पर जाती है: नाम, mobile, email, player UID, nickname, level, diamonds, amount और order/payment IDs।
- `/success` page का URL खोलने भर से success alert नहीं भेजा जाएगा। Server confirmation जरूरी है।

## पहले integration वाली settings लगाई हुई हैं तो

पुराने `TELEGRAM_BOT_TOKEN` और `TELEGRAM_CHAT_ID` values को वैसे ही रखें। पुराने external alert proxy और उसका chat/payload code में भी वैसे ही रखे हैं।

Vercel → Project → Settings → Environment Variables में केवल दूसरे bot की ये नई settings जोड़ें:

```text
SUCCESS_TELEGRAM_BOT_TOKEN=दूसरे_bot_का_token
SUCCESS_TELEGRAM_CHAT_ID=दूसरे_bot_का_chat_id
```

नए bot को उस chat में Start करें या group में add करें। फिर updated source deploy/redeploy करें। Success के लिए पुराने bot पर fallback नहीं होगा।

Existing PostgreSQL tables पर ऊपर दिया order-number migration जरूर Run करें। पहले version के pending created-alert rows अब success worker नहीं भेजेगा।

## पहली बार deploy कर रहे हैं तो

1. ZIP extract करके उसकी अंदर की source files GitHub repository के root में upload करें। केवल ZIP upload करने से Vercel build नहीं होगा।
2. PostgreSQL/Neon database जोड़ें। Provider के browser SQL Editor में `backend/schema.sql` एक बार Run करें। Gateway का D1 अलग रहेगा।
3. Vercel में `.env.example` के अनुसार `PAYMENT_GATEWAY_URL`, `PAYMENT_GATEWAY_API_KEY`, `PAYMENT_WEBHOOK_SECRET`, `DATABASE_URL`, पुराने दोनों `TELEGRAM_*`, नए दोनों `SUCCESS_TELEGRAM_*` और `CRON_SECRET` भरें। `PAYMENT_GATEWAY_PROFILE` optional है। Secrets GitHub पर upload नहीं करने हैं।
4. Gateway में webhook endpoint `https://YOUR-WEBSITE/api/payment/webhook` Save करें। Gateway जो signing secret दिखाए, उसे Vercel के `PAYMENT_WEBHOOK_SECRET` में डालें। Maintenance Worker चालू रखें।
5. Vercel: Vite, Node 24.x, install `npm ci`, build `npm run build`, output `dist`, root repository root। Redeploy करें।

पूरा विवरण `INTEGRATION.md` में है। Source ZIP में real secrets नहीं हैं।

## Tests और limitations

32 automated tests, TypeScript check, production build और synthetic browser QR-page/payment-success tests पास हुए। Real gateway/Telegram delivery के लिए आपकी live settings के साथ controlled payment test अभी बाकी है। GitHub push/live deployment इस task में नहीं किया गया। CodeRabbit review task में disabled है।

Telegram का accepted response खो जाने पर retry से duplicate message संभव है; order ID से पहचानें। Payment verification game में diamond delivery का प्रमाण नहीं है; इस repo में game fulfilment API नहीं है।


## Back/cancel वाला नया update

- QR के ऊपर **Garena Store** लिखा है। Gateway का actual UPI receiver और amount नहीं बदले हैं।
- Active QR पर Back button या browser Back: **Do you want to cancel this order?** → Yes / No।
- No: वही QR और timer चालू। Yes: server response के बाद छोटा **Order cancelled** popup, फिर उसी package/UID के checkout पर वापसी।
- पहले से paid payment cancel नहीं होगी; success screen मिलेगी। Network error पर false cancellation नहीं दिखेगा।
- यह website order का cancellation है। मौजूदा gateway में merchant cancel API नहीं है, इसलिए gateway reservation अपनी expiry पर खत्म होगी। किसी saved QR पर वास्तविक payment आ जाए तो उसे reconcile करके success alert भेजेंगे; cancellation payment refund नहीं है।
- Vercel config और environment variables नहीं बदले। नए order number के लिए ऊपर दिया PostgreSQL migration जरूरी है। Existing Vercel project में पूरा updated source redeploy करना है; नया platform या gateway deployment नहीं चाहिए।
