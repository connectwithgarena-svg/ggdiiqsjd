# Vercel QR payment setup (browser only)

This is the existing React/Vite website with a dedicated `/qr` payment page connected to FFShop gateway 2.0/schema 7. Other pages and forms are preserved. `Verify.tsx` and its route have been removed. The shared package catalogue retains the same products, prices and sold-out flags.

## Vercel API startup fix

This version fixes `ERR_MODULE_NOT_FOUND: Cannot find module /var/task/server`. API/server runtime imports now use explicit `.js` filenames for the JavaScript emitted by Vercel. The regression test emits the entire API dependency graph and starts it in native Node ESM without tsx or bundling.

Upload all updated website files to the existing repository root and redeploy the Vercel project. Keep your environment values. No new database migration is introduced by this startup fix; run the existing order-number migration below only if it has not already been applied. After deployment, `/api/reviews` should return JSON and an unsigned POST to `/api/payment/webhook` should return 401 instead of a function startup error.

## Order number and Tax

Before deploying this version over an existing installation, open the **website PostgreSQL provider’s SQL editor** and run `backend/migrations/001-order-number.sql`. This is not the Cloudflare D1 database. The migration adds a nullable display reference and unique index, preserves existing orders, and is safe to repeat. New installations can run the complete `backend/schema.sql` instead.

The QR page shows `GORDNO` + the customer's game UID + six random digits **below the QR**, e.g. `GORDNO123456789654321`. Each new order gets a unique stored reference; refresh, polling and retries keep it. Existing orders receive a reference when next accessed. Internal UUIDs and gateway mappings remain unchanged. Success Telegram alerts include this reference.

The order amount and **Tax (payment adjustment)** are displayed separately. Tax is the existing gateway adjustment: payable amount minus original amount. Nothing extra is added and no GST rate or statutory tax calculation is implemented. Vercel settings and environment-variable names are unchanged.

## 1. Upload the source to GitHub

The original repository contained only a ZIP. Extract the delivered source ZIP and upload its **contents** to the repository root using GitHub's web interface. `package.json`, `vercel.json`, `api/`, `backend/` and `src/` must be at the root, not inside another folder. A ZIP alone is not deployable by Vercel. Do not upload `.env`, `node_modules`, `dist` or real secrets. The old source ZIP is replaced with a sanitized version too.

## 2. Add PostgreSQL for durable orders

Use Vercel Marketplace/Storage to connect a PostgreSQL provider such as Neon, or use an existing PostgreSQL database. The database is separate from the gateway's Cloudflare D1 database.

1. Copy the provider's pooled PostgreSQL connection string into Vercel's `DATABASE_URL` environment variable. Preserve the provider's TLS parameters.
2. Open that provider's browser SQL editor.
3. Paste the entire `backend/schema.sql` and run it once. It creates `shop_orders` and `shop_alerts` without deleting existing tables.

For local development only, `npm run db:migrate` executes that same SQL using `DATABASE_URL`.

## 3. Vercel environment variables

Open your Vercel project → Settings → Environment Variables. Add the values for **Production** (and a separate test setup for Preview if needed). Names are case-sensitive. Never use a `VITE_` or `NEXT_PUBLIC_` prefix for these values.

| Name | Value |
|---|---|
| `PAYMENT_GATEWAY_URL` | Existing gateway HTTPS origin, e.g. `https://your-gateway.pages.dev`, with no `/pay` path |
| `PAYMENT_GATEWAY_API_KEY` | API key created in your gateway dashboard; same key is used for creation and status |
| `PAYMENT_GATEWAY_PROFILE` | Optional: `bharatpe`, `paytm`, `phonepe`, `hdfc` or `gpay`; omit to use active profile |
| `PAYMENT_WEBHOOK_SECRET` | Signing secret generated when saving the gateway webhook; copy it here |
| `DATABASE_URL` | PostgreSQL connection string |
| `TELEGRAM_BOT_TOKEN` | Existing Pay-click/support bot: retain your current value |
| `TELEGRAM_CHAT_ID` | Existing Pay-click/support chat: retain your current value |
| `SUCCESS_TELEGRAM_BOT_TOKEN` | A separate bot token for verified payment-success alerts |
| `SUCCESS_TELEGRAM_CHAT_ID` | Chat/group for that second bot; start/add this bot first |
| `CRON_SECRET` | A different random secret, at least 32 characters, for scheduled alert retries |
| `APP_URL` | Your website's HTTPS origin |

`.env.example` contains placeholders; it does not configure Vercel by itself. Do not send secrets in chat or commit them to GitHub. For local development copy it to ignored `.env`.

## 4. Connect the gateway webhook

In the gateway's Integration / Payment webhooks settings:

- Endpoint: `https://YOUR-WEBSITE-DOMAIN/api/payment/webhook`
- Save the endpoint in the gateway. Copy the generated signing secret into Vercel's `PAYMENT_WEBHOOK_SECRET`, then redeploy the website. Saving the gateway webhook again rotates its secret; update Vercel accordingly.

Keep your existing Cloudflare maintenance Worker/scheduler enabled. It delivers signed paid/expired/cancelled callbacks even if the browser closes. The website validates HMAC, order ID, payment ID, both amounts and the payment timestamp. Do not configure this endpoint as a customer redirect URL.

## 5. Deploy

Import the repository into Vercel or redeploy its existing project:

- Framework: **Vite**
- Root Directory: repository root
- Node.js: **24.x**
- Install: `npm ci`
- Build: `npm run build`
- Output: `dist`

`vercel.json` routes `/api/*` to the Express function in `api/index.ts`; page URLs still use the existing SPA. No laptop or continuously running local server is needed.

## Customer flow

1. Existing UID login → existing diamond package → existing checkout.
2. First Pay click preserves BOTH original notifications (`/api/log-purchase` and the existing `teligram-alert-bot.vercel.app/api/send` proxy, same payload/chat), fires `InitiateCheckout` once per order, then navigates to `/qr`. These original click notifications still occur on each Pay click; payment refresh/polling does not resend them.
3. Customer provides name, Indian mobile number and email. The page explains these details are sent to order support on Telegram.
4. Second Pay click creates a durable order. Server loads the package price from its own catalogue. It does not send an additional created-order notification; the original first-click alerts remain the existing flow.
5. The gateway chooses the < ₹2 adjustment. The website displays its exact payable amount and QR until its seven-minute deadline, with a countdown. Retries and refreshes reuse the same payment attempt.
6. Website polls its server every five seconds. Only an authenticated gateway response or validated signed callback can mark the order paid.
7. Confirmed payment displays the existing success screen, fires `Purchase` using actual paid amount and stable event ID, and queues a **payment success** Telegram alert to the SECOND bot only. It includes customer name, mobile, email, player UID, player nickname, level, diamond quantity, payable amount and order/payment IDs. The trusted server queues this after confirmation, even if the customer closes the page; simply opening `/success` cannot trigger it. The Google Ads conversion also waits for confirmed payment.

`?status=success` and localStorage values are no longer proof of payment. The success screen now accurately says payment received/delivery pending; this integration does **not** automatically fulfil diamonds in a game account. No game top-up provider exists in this repository.

## Reliability / limits

- PostgreSQL stores order state after the gateway deletes its short-lived payment record. Treat these customer records as private business data; no public order listing is provided.
- Each browser gets a random order capability in sessionStorage. Refresh `/qr` in the same tab resumes the same order. Back from an active order (button, browser Back or in-app navigation) asks Yes/No. No keeps the same QR. Yes performs authenticated website-order cancellation, briefly shows confirmation, then restores the same package/UID checkout, including after a refresh. A subsequent Pay starts a new attempt; the cancelled QR is not reopened. Direct `/qr` access without an order displays a safe empty state. Closing the tab can lose browser recovery access; server-side webhook processing and alerts continue.
- A unique order/payment mapping, database transaction and unique alert key prevent concurrent polling/webhooks from creating multiple paid transitions or normal duplicate alerts.
- The original click-alert bot/settings are independent of `SUCCESS_TELEGRAM_*`. There is no fallback sending success to the old bot. Configure both new success variables before enabling checkout. The order-number migration above is required for existing installations; old unsent `created` outbox rows are ignored by the success worker.
- Telegram failures never undo payment success. They remain queued, are retried by polling/webhook retries, and by a daily Vercel cron fallback (`0 0 * * *`, compatible with Hobby). It processes up to 20 due orders per run. For heavier traffic use more frequent scheduling on a suitable plan or call the authenticated retry endpoint from your existing scheduler.
- Telegram has no idempotent `sendMessage` key: if it accepts a message but the connection drops before acknowledgement, a retry can produce another alert. Alerts include the same order ID for reconciliation; do not automatically fulfil twice based on chat messages.
- Browser Meta events depend on browser consent, blockers and network availability. Stable event IDs/local markers prevent ordinary repeat events; do not promise exact-once analytics across cleared storage or multiple devices.
- Existing merchant Android relay must remain online with notification access. This site does not independently observe bank credits.
- The existing website has no verified user-account authentication: a game UID identifies the intended recipient, not ownership of a bank account. Order access uses the random capability, not the UID alone.

## Test before taking live payments

After configuring values, create a low-value test product/order in your test environment and pay the exact generated amount. Confirm: correct QR total, pending state, server-confirmed success, one normal success alert, matching Meta event, QR removal at expiry, and callback processing with the customer tab closed. Also verify your actual diamond fulfilment process separately. Synthetic automated tests cannot prove real merchant notification delivery.

Local commands: `npm ci`, `npm run lint`, `npm test`, `npm run build`. `npm run dev` starts local development; `npm run build:server` + `npm start` runs a standalone Node server. Vercel only needs `npm run build`.

## Vercel cancellation update

The earlier cancellation update did not change Vercel settings, dependencies or environment-variable names. The latest order-number update requires the PostgreSQL migration described above. Redeploy the complete source ZIP to your existing Vercel project. `/api/payment/cancel/:id` is served by the same Vercel Express function and requires the order capability.

The QR page now displays **Garena Store** above the exact amount/QR. This is a display heading; it does not rewrite the gateway's UPI recipient, amount or bank-verified merchant identity.

Cancellation checks authenticated gateway status before closing the website order. Already confirmed payments take the success path and remain paid. Network/mapping errors leave the confirmation open with an error; the UI never claims cancellation succeeded without a server response. Repeated cancellation is idempotent, and another customer's capability cannot cancel the order.

The current FFShop gateway exposes cancellation only to its admin dashboard, not the merchant API. Therefore this Vercel update cancels the **website order**, hides its QR and leaves the gateway reservation to expire on its normal schedule. A previously saved UPI QR cannot be revoked by a website. Any later authenticated receipt of actual money is still reconciled and alerts the success bot once; cancellation is not a refund and never discards a genuine credit. No gateway deployment changes are required.

Browser Back is guarded while the QR page is mounted, including a direct/reloaded `/qr` page. Closing the tab or leaving to another website cannot reliably display a custom React confirmation; server-side expiry/reconciliation remains authoritative. Success-page refresh/Forward re-verifies the saved order, and Back/navigation clears stale success UI.
