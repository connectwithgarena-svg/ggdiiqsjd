import type { PackageItem } from '../types';

export const PACKAGES: PackageItem[] = [
  {
    id: '1090',
    base: 1090,
    bonus: 1090,
    price: 550,
    promoTag: 'Promo'
  },
  {
    id: '4440_9TH',
    base: 2220,
    bonus: 2220,
    price: 750,
    originalPrice: 1100,
    badge: '9TH ANNIVERSARY OFFER',
    promoTag: '9th Offer'
  },
  {
    id: '4210_9TH',
    base: 4210,
    bonus: 4210,
    price: 1100,
    originalPrice: 1600,
    badge: '9TH ANNIVERSARY OFFER',
    promoTag: 'Anniversary'
  },
  {
    id: '3180',
    base: 3180,
    bonus: 3180,
    price: 1850,
    promoTag: 'Sold Out',
    isSoldOut: true
  },
  {
    id: '13160_9TH',
    base: 6580,
    bonus: 6580,
    price: 1400,
    originalPrice: 2550,
    badge: 'CHANCE TO WIN IPHONE 18 PRO',
    promoTag: 'Naruto Offer'
  },
  {
    id: '12500',
    base: 12500,
    bonus: 12500,
    price: 5500,
    promoTag: 'Promo'
  },
  {
    id: '18500',
    base: 18500,
    bonus: 18500,
    price: 7500,
    promoTag: 'Promo'
  },
  {
    id: '47000',
    base: 47000,
    bonus: 45500,
    price: 15000,
    promoTag: 'Sold Out',
    isSoldOut: true
  }
];

