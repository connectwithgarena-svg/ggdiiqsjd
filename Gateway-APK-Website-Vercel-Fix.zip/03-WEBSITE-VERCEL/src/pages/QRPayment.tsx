import { useEffect, useRef, useState, type FormEvent } from 'react';
import { type Attempt, type PaidOrder, paymentRequest, readAttempt, saveAttempt, verifiedSuccess } from '../lib/payments';

type PaymentPageProps = { onPaid: (order: PaidOrder) => void; onBack: () => void; registerExitGuard: (guard: (() => void) | null) => void };
function PaymentForm({ attempt: initial, onPaid, onBack, registerExitGuard }: PaymentPageProps & { attempt: Attempt }) {
  const [attempt, setAttempt] = useState(initial);
  const [name, setName] = useState(String(initial.payload?.name || ''));
  const [mobile, setMobile] = useState(String(initial.payload?.mobile || ''));
  const [email, setEmail] = useState(String(initial.payload?.email || ''));
  // Cached data only restores the view; it can never authorize a success screen.
  const [order, setOrder] = useState<PaidOrder | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [remaining, setRemaining] = useState(0);
  const [cancelPhase, setCancelPhase] = useState<'confirm' | 'cancelling' | 'cancelled' | null>(null);
  const [cancelError, setCancelError] = useState('');
  const requestExitRef = useRef<() => void>(() => {});
  const finishAction = useRef<(() => void) | null>(null), finishing = useRef(false);
  const cancelTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const requestVersion = useRef(0), cancelInFlight = useRef(false);
  const onBackRef = useRef(onBack); onBackRef.current = onBack;
  const finish = (action: () => void) => {
    if (finishing.current) return;
    finishing.current = true;
    registerExitGuard(null);
    // Remove our guard entry so Back from checkout/success cannot reopen a live QR.
    if (window.history.state?.ggPaymentGuard === initial.id) {
      finishAction.current = action;
      window.history.back();
    } else action();
  };
  useEffect(() => {
    if (window.history.state?.ggPaymentGuard !== initial.id) {
      window.history.replaceState({ ...window.history.state, ggPaymentBase: initial.id }, '', window.location.href);
      window.history.pushState({ ggPaymentGuard: initial.id }, '', window.location.href);
    }
    const handleBack = (event: PopStateEvent) => {
      event.stopImmediatePropagation();
      if (finishAction.current) {
        const action = finishAction.current; finishAction.current = null; action(); return;
      }
      window.history.pushState({ ggPaymentGuard: initial.id }, '', '/qr');
      requestExitRef.current();
    };
    registerExitGuard(() => requestExitRef.current());
    window.addEventListener('popstate', handleBack, true);
    return () => {
      window.removeEventListener('popstate', handleBack, true);
      registerExitGuard(null);
      clearTimeout(cancelTimer.current);
    };
  }, [initial.id, registerExitGuard]);
  const deadline = useRef(0), expiryTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined), inFlight = useRef(false), mounted = useRef(true);
  const onPaidRef = useRef(onPaid); onPaidRef.current = onPaid;
  const accept = (next: PaidOrder, current: Attempt) => {
    if (!mounted.current) return;
    const saved = { ...current, order: next }; saveAttempt(saved); setAttempt(saved);
    const nextDeadline = performance.now() + Math.max(0, Date.parse(next.expiresAt) - Date.parse(next.serverTime));
    deadline.current = deadline.current ? Math.min(deadline.current, nextDeadline) : nextDeadline;
    clearTimeout(expiryTimer.current);
    expiryTimer.current = setTimeout(() => { if (mounted.current) setRemaining(0); }, Math.max(0, deadline.current - performance.now()));
    setRemaining(Math.max(0, Math.ceil((deadline.current - performance.now()) / 1000)));
    setOrder(next); setError('');
    if (next.status === 'paid') { setCancelPhase(null); finish(() => verifiedSuccess(next, onPaidRef.current)); }
  };
  async function create(current: Attempt) {
    if (inFlight.current || !current.payload) return;
    inFlight.current = true; setBusy(true); setError('');
    try { accept(await paymentRequest('create', current, current.payload), current); }
    catch (e) {
      if (mounted.current) {
        if ((e as any)?.status === 400) {
          const editable = { ...current, payload: undefined }; saveAttempt(editable); setAttempt(editable);
        }
        setError(e instanceof Error ? e.message : 'Unable to create payment. Retry this order.');
      }
    }
    finally { inFlight.current = false; if (mounted.current) setBusy(false); }
  }
  useEffect(() => {
    mounted.current = true;
    // A repeated create uses the same durable intent, including after a lost response/reload.
    if (initial.payload) void create(initial);
    return () => { mounted.current = false; clearTimeout(expiryTimer.current); };
  }, []);
  useEffect(() => {
    if (!order || ['paid', 'cancelled'].includes(order.status)) return;
    let stopped = false, timer: ReturnType<typeof setTimeout>;
    const tick = setInterval(() => setRemaining(Math.max(0, Math.ceil((deadline.current - performance.now()) / 1000))), 250);
    async function poll() {
      if (stopped) return;
      if (!inFlight.current && !cancelInFlight.current && !finishing.current) {
        const version = requestVersion.current;
        inFlight.current = true;
        try {
          const next = await paymentRequest('status/' + attempt.id, attempt);
          if (!stopped && version === requestVersion.current) accept(next, attempt);
        } catch (e) { if (!stopped) setError(e instanceof Error ? e.message : 'Checking payment. Please wait.'); }
        finally { inFlight.current = false; }
      }
      if (!stopped) timer = setTimeout(poll, 5000);
    }
    timer = setTimeout(poll, 1000);
    return () => { stopped = true; clearInterval(tick); clearTimeout(timer); };
  }, [order?.id, order?.status, attempt.id]);
  function submit(e: FormEvent) {
    e.preventDefault();
    const current = attempt.payload ? attempt : { ...attempt, payload: { attemptId: attempt.id, packageId: attempt.packageId,
      uid: attempt.uid, nickname: attempt.nickname, level: attempt.level, name: name.trim(), mobile: mobile.trim(), email: email.trim() } };
    saveAttempt(current); setAttempt(current); void create(current);
  }
  requestExitRef.current = () => {
    if (finishing.current || cancelInFlight.current || cancelPhase === 'cancelled') return;
    if ((!attempt.payload && !order) || (order && ['expired','cancelled'].includes(order.status))) {
      finish(() => onBackRef.current()); return;
    }
    setCancelError(''); setCancelPhase('confirm');
  };
  async function confirmCancellation() {
    if (busy || cancelInFlight.current || finishing.current) return;
    cancelInFlight.current = true;
    requestVersion.current++;
    setCancelPhase('cancelling'); setCancelError('');
    try {
      const next = await paymentRequest('cancel/' + attempt.id, attempt, {});
      if (!mounted.current) return;
      accept(next, attempt);
      if (next.status === 'paid') return;
      if (!['cancelled','expired'].includes(next.status)) throw new Error('Cancellation was not confirmed. Please retry.');
      setCancelPhase('cancelled');
      cancelTimer.current = setTimeout(() => finish(() => onBackRef.current()), 1200);
    } catch (e) {
      if (mounted.current) {
        setCancelError(e instanceof Error ? e.message : 'Unable to cancel. Please retry.');
        setCancelPhase('confirm');
      }
    } finally { cancelInFlight.current = false; }
  }
  const expired = !!order && (remaining === 0 || ['expired','cancelled'].includes(order.status));
  return <section aria-label="Complete payment" className="w-full">
    <div className="bg-white rounded-2xl p-5 sm:p-6 w-full space-y-4 shadow-xl border border-gray-100">
      <div className="flex justify-between items-center"><h1 className="font-extrabold text-gray-800">Complete Payment</h1>
        <button type="button" aria-label="Back to checkout" disabled={busy || cancelPhase === 'cancelling'} onClick={() => requestExitRef.current()} className="font-bold text-gray-500 px-2">Back</button></div>
      {!order ? <form onSubmit={submit} className="space-y-3">
        <p className="text-sm text-gray-600">Enter your details for this order. Payment is verified automatically.</p>
        <label className="block text-sm font-bold">Full name<input required minLength={2} maxLength={80} autoComplete="name" value={name} disabled={busy || !!attempt.payload} onChange={e => setName(e.target.value)} className="block w-full border rounded-xl p-3 mt-1" /></label>
        <label className="block text-sm font-bold">Mobile number<input required type="tel" pattern="[6-9][0-9]{9}" maxLength={10} autoComplete="tel-national" value={mobile} disabled={busy || !!attempt.payload} onChange={e => setMobile(e.target.value)} className="block w-full border rounded-xl p-3 mt-1" /></label>
        <label className="block text-sm font-bold">Email address<input required type="email" maxLength={254} autoComplete="email" value={email} disabled={busy || !!attempt.payload} onChange={e => setEmail(e.target.value)} className="block w-full border rounded-xl p-3 mt-1" /></label>
        <p className="text-xs text-gray-500">These details will be shared with our order support team on Telegram for order handling.</p>
        <button disabled={busy} className="w-full bg-[#ee2c24] text-white p-3 rounded-xl font-bold disabled:opacity-50">{busy ? 'Creating your QR…' : attempt.payload ? 'Retry this payment order' : `Pay ₹${attempt.price} + tax`}</button>
      </form> : <div className="text-center space-y-3">
        {expired ? <div className="rounded-xl bg-red-50 p-5 text-red-700 font-bold">{order.status === 'cancelled' ? 'Payment cancelled' : 'QR expired'}<p className="font-normal text-sm mt-2">Do not pay this QR. We will still check any payment already completed during its valid period.</p></div> : <>
          <h2 className="font-extrabold text-xl text-gray-800">Garena Store</h2>
          <p className="text-xs font-bold text-gray-500 uppercase">Total payable</p>
          <p className="font-black text-3xl">₹{order.payableAmount}</p>
          <dl className="text-sm text-gray-600 space-y-1 rounded-xl bg-gray-50 p-3">
            <div className="flex justify-between gap-3"><dt>Order amount</dt><dd>₹{order.requestedAmount}</dd></div>
            <div className="flex justify-between gap-3"><dt>Tax <span className="text-xs">(payment adjustment)</span></dt><dd>₹{order.taxAmount}</dd></div>
          </dl>
          <p className="text-sm text-gray-600">Pay this exact amount, including paise.</p>
          {order.qr && <img src={order.qr} alt={`Payment QR for ₹${order.payableAmount}`} className="mx-auto w-[280px] max-w-full" />}
          <p className="font-bold">QR expires in {Math.floor(remaining / 60)}:{String(remaining % 60).padStart(2, '0')}</p>
          <p className="text-sm text-gray-600">Waiting for automatic payment confirmation…</p>
        </>}
        <p className="text-xs text-gray-500 break-all border-t border-gray-100 pt-3" data-testid="order-number">Order: {order.orderNumber}</p>
      </div>}
      {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
    </div>
    {cancelPhase && <div className="fixed inset-0 z-[100] bg-black/50 flex items-center justify-center p-4">
      <div role="dialog" aria-modal="true" aria-labelledby="cancel-order-title" className="bg-white rounded-2xl p-6 w-full max-w-sm space-y-4 text-center shadow-xl"
        onKeyDown={event => { if (event.key === 'Escape' && cancelPhase === 'confirm') setCancelPhase(null); }}>
        {cancelPhase === 'cancelled' ? <>
          <h2 id="cancel-order-title" className="font-extrabold text-lg">{order?.status === 'expired' ? 'Order expired' : 'Order cancelled'}</h2>
          <p className="text-sm text-gray-600">Returning to checkout…</p>
          <button autoFocus className="text-[#ee2c24] font-bold" onClick={() => finish(() => onBackRef.current())}>OK</button>
        </> : <>
          <h2 id="cancel-order-title" className="font-extrabold text-lg">Do you want to cancel this order?</h2>
          <p className="text-sm text-gray-600">Choose No to continue your payment. If you cancel, do not pay this QR.</p>
          {cancelError && <p role="alert" className="text-sm text-red-600">{cancelError}</p>}
          <div className="flex gap-3">
            <button autoFocus disabled={cancelPhase === 'cancelling'} onClick={() => setCancelPhase(null)} className="flex-1 border rounded-xl p-3 font-bold">No</button>
            <button disabled={busy || cancelPhase === 'cancelling'} onClick={confirmCancellation} className="flex-1 bg-[#ee2c24] text-white rounded-xl p-3 font-bold disabled:opacity-50">{cancelPhase === 'cancelling' ? 'Cancelling…' : 'Yes'}</button>
          </div>
        </>}
      </div>
    </div>}
  </section>;
}

export default function QRPayment({ onPaid, onBack, registerExitGuard }: PaymentPageProps) {
  const [attempt] = useState(() => readAttempt());
  if (!attempt) return <section className="bg-white rounded-2xl p-6 border border-gray-100 space-y-4 text-center">
    <h1 className="font-extrabold">No active payment</h1>
    <p>Select a diamond package to start a payment.</p>
    <button onClick={onBack} className="text-[#ee2c24] font-bold">Back to checkout</button>
  </section>;
  return <PaymentForm key={attempt.id} attempt={attempt} onPaid={onPaid} onBack={onBack} registerExitGuard={registerExitGuard} />;
}
