import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, ShoppingBag, ShieldCheck, Bell, AlertTriangle, X, CheckCircle2, Gift, Flame } from 'lucide-react';
import { PackageItem, PageRoute } from '../types';

interface DiamondPackagesProps {
  loggedInUser: string | null;
  setRoute: (route: PageRoute) => void;
  onSelectPackage: (pkg: PackageItem) => void;
  onOpenErrorModal: (message: string) => void;
}

import { PACKAGES } from '../data/packages';
export { PACKAGES } from '../data/packages';

export default function DiamondPackages({ loggedInUser, setRoute, onSelectPackage, onOpenErrorModal }: DiamondPackagesProps) {
  const handlePurchaseClick = (pkg: PackageItem) => {
    if (!loggedInUser) {
      onOpenErrorModal('Please log in using your Player UID first before selecting a top-up package.');
      return;
    }
    onSelectPackage(pkg);
    setRoute('checkout');
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2.5 text-gray-800 font-extrabold text-sm text-left">
        <span className="flex items-center justify-center bg-[#ee2c24] text-white w-5 h-5 rounded font-bold text-xs shrink-0">
          2
        </span>
        <h1 className="text-sm font-extrabold text-gray-800 tracking-tight whitespace-nowrap">
          Select Diamond Package
        </h1>
      </div>

      {/* Package Rows */}
      <div className="space-y-3.5">
        {PACKAGES.map((pkg) => {
          // Custom designs based on special event types
          const isSpecialOffer = Boolean(pkg.badge);
          const isIphoneOffer = pkg.badge === 'CHANCE TO WIN IPHONE 18 PRO';

          let borderClass = 'border-gray-100 hover:border-gray-200';
          let bgClass = 'bg-white';
          let accentTextClass = 'text-amber-500';
          let badgeBgClass = 'bg-amber-50/50 text-black';
          let tagClass = 'border-amber-500 text-amber-500 bg-amber-50/50';

          if (isIphoneOffer) {
            borderClass = 'border-rose-400 hover:border-rose-500 ring-2 ring-rose-500/20 shadow-lg shadow-rose-500/10';
            bgClass = 'bg-gradient-to-r from-rose-50/40 via-amber-50/30 to-rose-50/20';
            accentTextClass = 'text-rose-600';
            badgeBgClass = 'bg-gradient-to-r from-red-600 via-rose-500 to-amber-500 text-white font-black shadow-md shadow-rose-500/30';
            tagClass = 'border-rose-500 text-rose-600 bg-rose-50/80 font-black';
          } else if (isSpecialOffer) {
            borderClass = 'border-amber-200 hover:border-amber-400 shadow-amber-500/5';
            bgClass = 'bg-amber-50/15';
            accentTextClass = 'text-amber-600';
            badgeBgClass = 'bg-gradient-to-r from-amber-500 to-yellow-500 text-white font-black';
            tagClass = 'border-amber-500 text-amber-600 bg-amber-50/40';
          } else if (pkg.isSoldOut) {
            borderClass = 'border-gray-100 opacity-60';
            bgClass = 'bg-gray-50/30';
            accentTextClass = 'text-gray-400';
            badgeBgClass = 'bg-gray-300 text-gray-500';
            tagClass = 'border-gray-300 text-gray-400 bg-gray-50';
          }

          return (
            <motion.div
              key={pkg.id}
              whileHover={!pkg.isSoldOut ? { y: -1, transition: { duration: 0.12 } } : {}}
              className={`relative flex items-center justify-between p-3.5 sm:p-4 rounded-xl border ${borderClass} ${bgClass} transition-all shadow-xs gap-3.5 text-left`}
            >
              {/* Special Event Ribbon Badge */}
              {pkg.badge && (
                <div className={`absolute -top-2.5 left-3 sm:left-4 text-[9px] sm:text-[10px] font-black tracking-wider px-2.5 py-0.5 rounded-full shadow-xs whitespace-nowrap select-none flex items-center gap-1 ${badgeBgClass}`}>
                  {isIphoneOffer ? (
                    <>
                      <Gift className="w-3 h-3 text-yellow-200 animate-bounce" />
                      <span>{pkg.badge}</span>
                      <Flame className="w-3 h-3 text-yellow-300 fill-yellow-300" />
                    </>
                  ) : (
                    <span>{pkg.badge}</span>
                  )}
                </div>
              )}

              {/* Package Meta details */}
              <div className="flex items-center gap-2.5 sm:gap-3.5 flex-1 min-w-0">
                <img
                  src="https://static.wixstatic.com/media/fa21d6_28cb860923fa474abd20749b7cfc313e~mv2.webp/v1/fill/w_80,h_80,al_c,q_80/fa21d6_28cb860923fa474abd20749b7cfc313e~mv2.webp"
                  alt={`Garena Free Fire ${pkg.base} + ${pkg.bonus} Diamond bundle package`}
                  loading="lazy"
                  decoding="async"
                  className={`w-9 h-9 sm:w-10 sm:h-10 object-contain shrink-0 ${pkg.isSoldOut ? 'grayscale contrast-75' : ''}`}
                />
                <div className="space-y-0.5 min-w-0 flex-1">
                  <h2 className="text-sm sm:text-base font-extrabold text-gray-900 tracking-tight flex items-center gap-1 m-0 p-0 whitespace-nowrap">
                    <span>{pkg.base.toLocaleString()}</span>
                    <span className={`font-black ${accentTextClass}`}>
                      +{pkg.bonus.toLocaleString()}
                    </span>
                  </h2>
                  <div className="flex items-center gap-1.5 flex-wrap sm:flex-nowrap">
                    <span className={`inline-flex items-center justify-center border text-[8px] sm:text-[9px] font-extrabold px-1.5 py-0.5 rounded-md uppercase tracking-wider whitespace-nowrap shrink-0 ${tagClass}`}>
                      {pkg.promoTag}
                    </span>
                    {!pkg.isSoldOut && (
                      <span className="text-[8px] sm:text-[9px] text-gray-400 font-extrabold flex items-center gap-0.5 whitespace-nowrap shrink-0">
                        <Sparkles className="w-2.5 h-2.5 text-amber-500 fill-amber-500 shrink-0" />
                        100% Bonus Included
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Purchase button area */}
              <div className="flex flex-col items-end gap-1 shrink-0">
                {pkg.isSoldOut ? (
                  <button
                    disabled
                    className="bg-gray-100 text-gray-400 text-xs font-bold py-2 px-4 w-20 sm:w-22 rounded-lg cursor-not-allowed text-center uppercase"
                  >
                    Sold Out
                  </button>
                ) : (
                  <button
                    onClick={() => handlePurchaseClick(pkg)}
                    className="bg-[#ee2c24] hover:bg-red-600 active:scale-95 text-white text-xs sm:text-sm font-extrabold py-2 px-3 w-20 sm:w-22 rounded-lg transition-all shadow-sm cursor-pointer flex flex-col items-center justify-center"
                  >
                    <span className="flex items-center gap-0.5">
                      ₹ {pkg.price}
                    </span>
                    {pkg.originalPrice && (
                      <s className="text-[9px] text-white/70 font-medium leading-none">
                        ₹ {pkg.originalPrice}
                      </s>
                    )}
                  </button>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>


    </div>
  );
}
