export interface PlayerBasicInfo {
  nickname: string;
  level: number;
  liked: number;
  accountId?: string;
  createAt?: string;
  headPic?: string;
}

export interface PlayerSocialInfo {
  signature?: string;
}

export interface PlayerProfileInfo {
  clothes?: string[];
}

export interface PlayerClanBasicInfo {
  clanName?: string;
}

export interface PlayerData {
  basicInfo: PlayerBasicInfo;
  socialInfo?: PlayerSocialInfo;
  profileInfo?: PlayerProfileInfo;
  clanBasicInfo?: PlayerClanBasicInfo;
}

export interface PackageItem {
  id: string;
  base: number;
  bonus: number;
  price: number;
  originalPrice?: number;
  badge?: string;
  promoTag?: string;
  isSoldOut?: boolean;
}

export type PageRoute = 'home' | 'diamond' | 'checkout' | 'qr' | 'about' | 'contact' | 'faq' | 'privacy' | 'terms' | 'refund' | 'antifraud' | 'payment' | 'bonus';
