export type PaidOrder = { id: string; orderNumber: string; requestedAmount: string; taxAmount: string | null; status: string; uid: string; nickname: string; level: number; diamonds: number; payableAmount: string; packageId: string; expiresAt: string; serverTime: string; qr: string | null };
export type Attempt = { id: string; token: string; uid: string; packageId: string; nickname: string; level: number; price: number; diamonds: number; payload?: Record<string, unknown>; order?: PaidOrder };
const KEY = 'gg_payment_attempt_v1';
export function readAttempt(): Attempt | null {
  try { const a = JSON.parse(sessionStorage.getItem(KEY) || 'null'); return a?.id && a?.token && a?.packageId ? a : null; } catch { return null; }
}
export function saveAttempt(a: Attempt) { sessionStorage.setItem(KEY, JSON.stringify(a)); }
export function clearAttempt() { sessionStorage.removeItem(KEY); }
export async function paymentRequest(path: string, attempt: Attempt, body?: object): Promise<PaidOrder> {
  const response = await fetch('/api/payment/' + path, { method: body ? 'POST' : 'GET', cache: 'no-store',
    headers: { 'X-Order-Token': attempt.token, 'Content-Type': 'application/json' },
    signal: AbortSignal.timeout(20000), ...(body ? { body: JSON.stringify(body) } : {}) });
  const result = await response.json();
  if (!response.ok) throw Object.assign(new Error(result.error || 'Payment service unavailable. Please retry.'), { status: response.status });
  return result;
}
export function trackPaymentEvent(event: 'InitiateCheckout' | 'Purchase', id: string, value: number, diamonds: number) {
  try {
  const pixel = (window as any).fbq;
  if (typeof pixel !== 'function') return;
  const key = `gg_meta_${event}_${id}`;
  if (localStorage.getItem(key)) return;
  pixel('track', event, { currency: 'INR', value, content_name: `Free Fire ${diamonds} Diamonds`, content_type: 'product', content_ids: ['ff_diamonds'], num_items: 1 }, { eventID: `${event}_${id}` });
  localStorage.setItem(key, '1');
  } catch { /* Analytics must never block checkout or confirmed payment. */ }
}
export function verifiedSuccess(order: PaidOrder, onPaid: (order: PaidOrder) => void) {
  if (order.status !== 'paid') return;
  trackPaymentEvent('Purchase', order.id, Number(order.payableAmount), order.diamonds);
  try {
  const key = `gg_ads_paid_${order.id}`;
  if (typeof (window as any).gtag === 'function' && !localStorage.getItem(key)) {
    (window as any).gtag('event', 'conversion', { send_to: 'AW-17990074173/8HBuCMvqmoIcEL3-qoJD', transaction_id: order.id, value: Number(order.payableAmount), currency: 'INR' });
    localStorage.setItem(key, '1');
  }
  } catch { /* Conversion tracking is best effort. */ }
  onPaid(order);
}
