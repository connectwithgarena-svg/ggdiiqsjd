// Existing Pay-click notifications: keep endpoints, chat and payloads unchanged.
export function notifyCheckoutClick(info: { nickname: string; level: number }, uid: string, totalDiamonds: number, price: number, transport: typeof fetch = fetch) {
    // 3. Telemetry Dispatch via Secure Backend API proxy route
    transport('/api/log-purchase', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        nickname: info.nickname,
        level: info.level,
        uid: uid,
        totalDiamonds: totalDiamonds,
        price: price
      })
    }).catch(err => console.error('Secure purchase log dispatcher failed:', err));

    const messageText = `
🚀 *GGDIAMOND ALERT*
━━━━━━━━━━━━━━━━━━
👤 *Name:* ${info.nickname}
📊 *Level:* ${info.level}
🆔 *UID:* ${uid}
💎 *Diamonds:* ${totalDiamonds}
💰 *Price:* ₹${price}
━━━━━━━━━━━━━━━━━━
✅ *Action:* User Clicked PAY NOW
    `;

    const backendUrl = "https://teligram-alert-bot.vercel.app/api/send"; 
    transport(backendUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            chat_id: "8422419131", 
            message: messageText
        })
    }).catch(console.error);

}
