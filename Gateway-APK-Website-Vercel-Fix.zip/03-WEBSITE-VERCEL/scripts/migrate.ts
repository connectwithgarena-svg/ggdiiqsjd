import 'dotenv/config';
import { readFile } from 'node:fs/promises';
import { Pool } from 'pg';
if (!process.env.DATABASE_URL) throw new Error('Set DATABASE_URL');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
try { await pool.query(await readFile('backend/schema.sql', 'utf8')); console.log('Payment tables ready'); }
finally { await pool.end(); }
