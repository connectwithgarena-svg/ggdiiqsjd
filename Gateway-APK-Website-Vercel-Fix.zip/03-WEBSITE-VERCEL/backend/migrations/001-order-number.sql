-- PostgreSQL: run once on the website database before deploying this version.
-- Safe to rerun; existing order IDs and payment mappings are preserved.
ALTER TABLE shop_orders ADD COLUMN IF NOT EXISTS order_number text;
CREATE UNIQUE INDEX IF NOT EXISTS shop_orders_order_number_unique ON shop_orders(order_number);
