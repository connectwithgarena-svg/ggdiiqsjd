import express from 'express';
import { randomUUID } from 'node:crypto';
import QRCode from 'qrcode';
import { PACKAGES } from '../src/data/packages.js';
import { database, type Database } from './database.js';
import { ensureOrderNumber } from './orderNumbers.js';
import { Gateway, PaymentError, hash, paise, validatePayment, validWebhook } from './gateway.js';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const TOKEN = /^[0-9a-f]{64}$/;
function validateInput(body: any) {
  const pkg = PACKAGES.find(p => p.id === body?.packageId && !p.isSoldOut);
  const text = (v: unknown) => typeof v === 'string' ? v.trim() : '';
  const customer = { name: text(body?.name), mobile: text(body?.mobile), email: text(body?.email).toLowerCase() };
  if (!pkg || !UUID.test(body?.attemptId || '') || !/^\d{5,15}$/.test(body?.uid || '') ||
      customer.name.length < 2 || customer.name.length > 80 || /[\x00-\x1f<>]/.test(customer.name) ||
      !/^[6-9]\d{9}$/.test(customer.mobile) || customer.email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customer.email) ||
      text(body.nickname).length > 80 || !Number.isInteger(body.level) || body.level < 0 || body.level > 1000)
    throw new PaymentError(400, 'Enter a valid package, player UID, name, Indian mobile number and email.');
  return { id: body.attemptId, packageId: pkg.id, uid: body.uid, nickname: text(body.nickname) || 'Player', level: body.level,
    ...customer, requested: pkg.price * 100, diamonds: pkg.base + pkg.bonus };
}
async function row(db: Database, id: string) { return (await db.query('SELECT * FROM shop_orders WHERE id=$1', [id])).rows[0]; }
async function markPaid(db: Database, id: string, paidAt: string) {
  // Payment state and unique success notification are committed together.
  await db.query(`WITH changed AS (
    UPDATE shop_orders SET status='paid', paid_at=$2 WHERE id=$1 AND status<>'paid' RETURNING id
  ) INSERT INTO shop_alerts(order_id,kind) SELECT id,'paid' FROM changed ON CONFLICT DO NOTHING`, [id, paidAt]);
}
export async function flushAlerts(db: Database, id: string, transport: typeof fetch = fetch, env = process.env) {
  const order = await row(db, id);
  if (!order || order.status !== 'paid') return true;
  if (!env.SUCCESS_TELEGRAM_BOT_TOKEN || !env.SUCCESS_TELEGRAM_CHAT_ID) return false;
  order.order_number ||= await ensureOrderNumber(db, order.id, order.uid);
  for (const kind of ['paid']) {
    const lease = randomUUID();
    const claimed = await db.query(`UPDATE shop_alerts SET lease_id=$3, lease_until=now()+interval '30 seconds', attempts=attempts+1
      WHERE order_id=$1 AND kind=$2 AND sent_at IS NULL AND next_at<=now() AND (lease_until IS NULL OR lease_until<now()) RETURNING kind`, [id, kind, lease]);
    if (!claimed.rows.length) continue;
    const text = `✅ PAYMENT SUCCESS — delivery pending\n` +
      `Order: ${order.order_number}\nInternal order: ${order.id}\nPayment: ${order.gateway_id}\nPlayer UID: ${order.uid}\nPlayer: ${order.nickname}\nLevel: ${order.player_level}\n` +
      `Name: ${order.customer_name}\nMobile: ${order.mobile}\nEmail: ${order.email}\n` +
      `Diamonds: ${order.diamonds}\nAmount: ₹${(order.payable / 100).toFixed(2)}`;
    try {
      const response = await transport(`https://api.telegram.org/bot${env.SUCCESS_TELEGRAM_BOT_TOKEN}/sendMessage`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, redirect: 'error', signal: AbortSignal.timeout(5000),
        body: JSON.stringify({ chat_id: env.SUCCESS_TELEGRAM_CHAT_ID, text }),
      });
      const result = await response.json() as any;
      if (!response.ok || result.ok !== true) throw new Error('Delivery failed');
      await db.query('UPDATE shop_alerts SET sent_at=now(),lease_until=NULL WHERE order_id=$1 AND kind=$2 AND lease_id=$3', [id, kind, lease]);
    } catch {
      await db.query("UPDATE shop_alerts SET lease_until=NULL,next_at=now()+interval '30 seconds' WHERE order_id=$1 AND kind=$2 AND lease_id=$3", [id, kind, lease]);
    }
  }
  return !(await db.query("SELECT 1 FROM shop_alerts WHERE order_id=$1 AND kind='paid' AND sent_at IS NULL", [id])).rows.length;
}
async function publicOrder(order: any, db: Database) {
  const orderNumber = order.order_number || await ensureOrderNumber(db, order.id, order.uid);
  const expires = order.expires_at ? new Date(order.expires_at).getTime() : new Date(order.created_at).getTime() + 420000;
  const status = ['creating','pending'].includes(order.status) && Date.now() >= expires ? 'expired' : order.status;
  return { id: order.id, orderNumber, requestedAmount: (order.requested / 100).toFixed(2),
    taxAmount: order.payable ? ((order.payable - order.requested) / 100).toFixed(2) : null, status, packageId: order.package_id, uid: order.uid, nickname: order.nickname, level: order.player_level,
    diamonds: order.diamonds, payableAmount: order.payable ? (order.payable / 100).toFixed(2) : null,
    expiresAt: new Date(expires).toISOString(), serverTime: new Date().toISOString(),
    qr: status === 'pending' && order.upi_uri ? await QRCode.toDataURL(order.upi_uri, { width: 300, margin: 2, errorCorrectionLevel: 'M' }) : null };
}
type Options = { db?: Database; gateway?: Pick<Gateway, 'create' | 'get'>; transport?: typeof fetch; env?: NodeJS.ProcessEnv };
export function paymentRouter(options: Options = {}) {
  const router = express.Router(), env = options.env || process.env;
  const db = () => options.db || database();
  const gateway = () => options.gateway || new Gateway(env);
  const alerts = (id: string) => flushAlerts(db(), id, options.transport, env);
  const handler = (fn: (req: express.Request, res: express.Response) => Promise<any>): express.RequestHandler => async (req, res) => {
    res.set('Cache-Control', 'no-store');
    try { await fn(req, res); }
    catch (e) {
      const known = e instanceof PaymentError;
      // Never log request bodies, API credentials, database URLs or provider responses.
      if (!known) console.error('Payment operation failed');
      res.status(known ? e.status : 503).json({ error: known ? e.message : 'Payment service unavailable. Retry this same order.' });
    }
  };
  const token = (req: express.Request) => {
    const value = req.get('X-Order-Token') || '';
    if (!TOKEN.test(value)) throw new PaymentError(401, 'Order access required');
    return hash(value);
  };
  router.post('/webhook', express.raw({ type: 'application/json', limit: '64kb' }), handler(async (req, res) => {
    if (!Buffer.isBuffer(req.body) || !validWebhook(req.body, req.get('X-FFSHOP-Timestamp') || '', req.get('X-FFSHOP-Signature') || '', env.PAYMENT_WEBHOOK_SECRET || ''))
      throw new PaymentError(401, 'Invalid webhook signature');
    let event: any;
    try { event = JSON.parse(req.body.toString('utf8')); } catch { throw new PaymentError(400, 'Invalid webhook'); }
    const p = event.payment;
    if (!p || !UUID.test(p.external_id || '')) throw new PaymentError(400, 'Invalid webhook order');
    if (!['paid','expired','cancelled'].includes(p.status) || event.type !== `payment.${p.status}` ||
      event.id !== `${p.status}_${p.id}` || req.get('X-FFSHOP-Event') !== event.id) throw new PaymentError(400, 'Invalid webhook event');
    const order = await row(db(), p.external_id);
    // Another site/API key can share the gateway's global webhook. Never adopt unknown orders.
    if (!order) return res.status(200).json({ ignored: true });
    if (!order.gateway_id) throw new PaymentError(503, 'Order creation pending. Retry webhook.');
    if (p.id !== order.gateway_id || p.requested_amount_paise !== order.requested || p.payable_amount_paise !== order.payable)
      throw new PaymentError(400, 'Webhook payment mismatch');
    if (p.status === 'paid') {
      if (!Number.isSafeInteger(p.paid_at_ms) || p.paid_at_ms < new Date(order.gateway_created).getTime() || p.paid_at_ms >= new Date(order.expires_at).getTime())
        throw new PaymentError(400, 'Invalid payment time');
      // HMAC-authenticated receipt remains usable after the gateway's short retention period.
      await markPaid(db(), order.id, new Date(p.paid_at_ms).toISOString());
    } else {
      await db().query("UPDATE shop_orders SET status=$2 WHERE id=$1 AND status IN ('pending','creating')", [order.id, p.status]);
    }
    if (!await alerts(order.id)) throw new PaymentError(503, 'Notification queued. Retry webhook.');
    res.json({ received: true });
  }));
  router.use(express.json({ limit: '8kb' }));
  router.post('/create', handler(async (req, res) => {
    const access = token(req), input = validateInput(req.body), fingerprint = hash(JSON.stringify(input));
    if (!env.SUCCESS_TELEGRAM_BOT_TOKEN || !env.SUCCESS_TELEGRAM_CHAT_ID || !env.PAYMENT_WEBHOOK_SECRET)
      throw new PaymentError(503, 'Payment notifications are not configured');
    const g = gateway(), store = db();
    await store.query(`INSERT INTO shop_orders(id,token_hash,request_hash,package_id,uid,nickname,player_level,customer_name,mobile,email,requested,diamonds)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) ON CONFLICT(id) DO NOTHING`,
      [input.id, access, fingerprint, input.packageId, input.uid, input.nickname, input.level, input.name, input.mobile, input.email, input.requested, input.diamonds]);
    await store.transaction(async tx => {
      const order = (await tx.query('SELECT * FROM shop_orders WHERE id=$1 FOR UPDATE', [input.id])).rows[0];
      if (order.token_hash !== access || order.request_hash !== fingerprint) throw new PaymentError(409, 'This checkout attempt already belongs to a different order');
      if (order.gateway_id || order.status !== 'creating') return;
      // Persisted intent prevents a retry recreating an old gateway order after its deletion.
      if (Date.now() >= new Date(order.created_at).getTime() + 420000) {
        await tx.query("UPDATE shop_orders SET status='expired' WHERE id=$1", [input.id]); return;
      }
      const p = await g.create(order);
      validatePayment(p, order, true);
      if (env.PAYMENT_GATEWAY_PROFILE && p.profile !== env.PAYMENT_GATEWAY_PROFILE) throw new PaymentError(502, 'Unexpected receiving account');
      await tx.query(`UPDATE shop_orders SET gateway_id=$2,profile=$3,payable=$4,upi_uri=$5,gateway_created=$6,expires_at=$7,status='pending' WHERE id=$1`,
        [input.id, p.id, p.profile, paise(p.payable_amount), p.upi_uri, p.created_at, p.expires_at]);
      if (p.status === 'paid') await markPaid(tx, input.id, p.paid_at!);
      else if (p.status !== 'pending') await tx.query('UPDATE shop_orders SET status=$2 WHERE id=$1', [input.id, p.status]);
    });
    await alerts(input.id);
    res.json(await publicOrder(await row(store, input.id), store));
  }));
  router.post('/cancel/:id', handler(async (req, res) => {
    const access = token(req), id = String(req.params.id);
    if (!UUID.test(id)) throw new PaymentError(404, 'Order not found');
    const store = db();
    await store.transaction(async tx => {
      const order = (await tx.query('SELECT * FROM shop_orders WHERE id=$1 FOR UPDATE', [id])).rows[0];
      if (!order || order.token_hash !== access) throw new PaymentError(404, 'Order not found');
      if (['paid','cancelled','expired'].includes(order.status)) return;
      // Reconcile before cancelling. A confirmed payment must never be overwritten.
      if (order.gateway_id) {
        try {
          const payment = await gateway().get(order.gateway_id);
          validatePayment(payment, order);
          if (payment.status === 'paid') { await markPaid(tx, id, payment.paid_at!); return; }
          if (payment.status === 'expired') {
            await tx.query("UPDATE shop_orders SET status='expired' WHERE id=$1", [id]); return;
          }
        } catch (e) {
          if (!(e instanceof PaymentError && e.status === 404 && Date.now() >= new Date(order.expires_at).getTime())) throw e;
        }
      }
      // The existing gateway has no merchant cancel API. Keep its reservation intact;
      // stop this website order/QR. An authentic receipt may still settle a real credit.
      await tx.query("UPDATE shop_orders SET status='cancelled' WHERE id=$1 AND status IN ('creating','pending')", [id]);
    });
    await alerts(id);
    res.json(await publicOrder(await row(store, id), store));
  }));
  router.get('/status/:id', handler(async (req, res) => {
    const access = token(req);
    if (!UUID.test(String(req.params.id))) throw new PaymentError(404, 'Order not found');
    const store = db(), order = await row(store, String(req.params.id));
    if (!order || order.token_hash !== access) throw new PaymentError(404, 'Order not found');
    if (order.gateway_id && order.status !== 'paid') {
      try {
        const p = await gateway().get(order.gateway_id);
        validatePayment(p, order);
        if (p.status === 'paid') await markPaid(store, order.id, p.paid_at!);
        else if (p.status !== 'pending') await store.query("UPDATE shop_orders SET status=$2 WHERE id=$1 AND status<>'paid'", [order.id, p.status]);
      } catch (e) {
        if (!(e instanceof PaymentError && e.status === 404 && Date.now() >= new Date(order.expires_at).getTime())) throw e;
        await store.query("UPDATE shop_orders SET status='expired' WHERE id=$1 AND status<>'paid'", [order.id]);
      }
    }
    await alerts(order.id);
    res.json(await publicOrder(await row(store, order.id), store));
  }));
  router.get('/retry-alerts', handler(async (req, res) => {
    if (!env.CRON_SECRET || req.get('Authorization') !== `Bearer ${env.CRON_SECRET}`) throw new PaymentError(401, 'Unauthorized');
    const due = await db().query("SELECT DISTINCT order_id FROM shop_alerts WHERE kind='paid' AND sent_at IS NULL AND next_at<=now() LIMIT 20");
    for (let i = 0; i < due.rows.length; i += 5) await Promise.all(due.rows.slice(i, i + 5).map(r => alerts(r.order_id)));
    res.json({ checked: due.rows.length });
  }));
  return router;
}
