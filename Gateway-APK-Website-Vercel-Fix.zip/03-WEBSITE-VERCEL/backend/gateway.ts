import { createHmac, timingSafeEqual, createHash } from 'node:crypto';
export class PaymentError extends Error {
  constructor(public status: number, message: string) { super(message); }
}
export const hash = (value: string) => createHash('sha256').update(value).digest('hex');
export function paise(value: unknown): number {
  if (typeof value !== 'string' || !/^\d{1,8}\.\d{2}$/.test(value)) throw new PaymentError(502, 'Invalid gateway amount');
  const [whole, fraction] = value.split('.');
  return Number(whole) * 100 + Number(fraction);
}
export interface GatewayPayment {
  id: string; external_id: string; status: string; profile: string;
  requested_amount: string; payable_amount: string; upi_uri: string;
  created_at: string; expires_at: string; paid_at: string | null;
}
export class Gateway {
  private origin: string;
  constructor(private env = process.env, private transport: typeof fetch = fetch) {
    const url = new URL(env.PAYMENT_GATEWAY_URL || 'https://unconfigured.invalid');
    if (!env.PAYMENT_GATEWAY_URL || !env.PAYMENT_GATEWAY_API_KEY || url.protocol !== 'https:' || url.username || url.password || url.pathname !== '/' || url.search || url.hash)
      throw new PaymentError(503, 'Payment gateway is not configured');
    this.origin = url.origin;
  }
  async request(path: string, body?: object, idem?: string): Promise<GatewayPayment> {
    const response = await this.transport(this.origin + path, {
      method: body ? 'POST' : 'GET', cache: 'no-store', redirect: 'error', signal: AbortSignal.timeout(10000),
      headers: { Authorization: `Bearer ${this.env.PAYMENT_GATEWAY_API_KEY}`, 'Content-Type': 'application/json', ...(idem ? { 'Idempotency-Key': idem } : {}) },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
    if (!response.ok) throw new PaymentError(response.status === 404 ? 404 : 502, 'Gateway unavailable. Retry this same order.');
    return response.json();
  }
  create(order: any) {
    return this.request('/api/v1/payments', {
      name: order.customer_name, amount: order.requested / 100, external_id: order.id,
      ...(this.env.PAYMENT_GATEWAY_PROFILE ? { profile: this.env.PAYMENT_GATEWAY_PROFILE } : {}),
    }, hash('ggdiamond-order:' + order.id));
  }
  get(id: string) { return this.request('/api/v1/payments/' + encodeURIComponent(id)); }
}
export function validatePayment(p: GatewayPayment, order: any, initial = false) {
  const created = Date.parse(p.created_at), expires = Date.parse(p.expires_at);
  if (!/^[a-zA-Z0-9_-]{1,128}$/.test(p.id) || p.external_id !== order.id || paise(p.requested_amount) !== order.requested ||
    !['pending','paid','expired','cancelled'].includes(p.status) || !['paytm','phonepe','hdfc','bharatpe','gpay'].includes(p.profile) ||
    !Number.isFinite(created) || expires - created !== 420000 ||
    paise(p.payable_amount) <= order.requested || paise(p.payable_amount) > order.requested + 199)
    throw new PaymentError(502, 'Gateway payment does not match this order');
  if (!initial && (p.id !== order.gateway_id || paise(p.payable_amount) !== order.payable || p.profile !== order.profile ||
    expires !== new Date(order.expires_at).getTime() || created !== new Date(order.gateway_created).getTime()))
    throw new PaymentError(502, 'Gateway payment mapping mismatch');
  if (p.status === 'paid' && (!p.paid_at || Date.parse(p.paid_at) < created || Date.parse(p.paid_at) >= expires || !Number.isFinite(Date.parse(p.paid_at))))
    throw new PaymentError(502, 'Invalid payment confirmation time');
  if (initial) {
    const uri = new URL(p.upi_uri);
    if (uri.protocol !== 'upi:' || uri.hostname !== 'pay' || !uri.searchParams.get('pa') || uri.searchParams.get('cu') !== 'INR' || uri.searchParams.get('am') !== p.payable_amount)
      throw new PaymentError(502, 'Invalid payment QR');
  }
}
export function validWebhook(raw: Buffer, timestamp: string, signature: string, secret: string, now = Date.now()) {
  if (!secret || !/^\d{10}$/.test(timestamp) || !/^[a-f0-9]{64}$/.test(signature) || Math.abs(now / 1000 - Number(timestamp)) > 300) return false;
  const expected = createHmac('sha256', secret).update(timestamp + '.').update(raw).digest();
  return timingSafeEqual(expected, Buffer.from(signature, 'hex'));
}
