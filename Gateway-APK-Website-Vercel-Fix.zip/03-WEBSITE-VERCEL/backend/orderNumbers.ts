import { randomInt } from 'node:crypto';
import type { Database } from './database';

// A permanent display reference; internal UUIDs continue to authorize/reconcile payments.
export async function ensureOrderNumber(db: Database, id: string, uid: string, digits = () => randomInt(100000, 1000000)): Promise<string> {
  for (let attempt = 0; attempt < 32; attempt++) {
    const number = `GORDNO${uid}${digits()}`;
    try {
      const updated = await db.query('UPDATE shop_orders SET order_number=$2 WHERE id=$1 AND order_number IS NULL RETURNING order_number', [id, number]);
      if (updated.rows[0]) return updated.rows[0].order_number;
      const existing = (await db.query('SELECT order_number FROM shop_orders WHERE id=$1', [id])).rows[0];
      if (existing?.order_number) return existing.order_number;
      throw new Error('Order not found');
    } catch (error) {
      if ((error as { code?: string }).code !== '23505') throw error;
      // Database uniqueness handles concurrent allocation, including rare random collisions.
    }
  }
  throw new Error('Unable to allocate a unique order number; retry the same order');
}
