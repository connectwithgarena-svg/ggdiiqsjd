import { Pool } from 'pg';
export interface Database {
  query(sql: string, params?: any[]): Promise<{ rows: any[]; rowCount?: number | null }>;
  transaction<T>(fn: (db: Database) => Promise<T>): Promise<T>;
}
let pool: Pool | undefined;
export function database(): Database {
  if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is not configured');
  pool ??= new Pool({ connectionString: process.env.DATABASE_URL, max: 3, connectionTimeoutMillis: 10000, idleTimeoutMillis: 10000 });
  return {
    query: (sql, params) => pool!.query(sql, params),
    async transaction(fn) {
      const client = await pool!.connect();
      try {
        await client.query('BEGIN');
        const db: Database = { query: (sql, params) => client.query(sql, params), transaction: fn => fn(db) };
        const result = await fn(db);
        await client.query('COMMIT');
        return result;
      } catch (e) { await client.query('ROLLBACK'); throw e; }
      finally { client.release(); }
    },
  };
}
