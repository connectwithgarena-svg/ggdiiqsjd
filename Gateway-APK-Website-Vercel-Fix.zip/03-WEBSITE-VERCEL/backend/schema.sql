CREATE TABLE IF NOT EXISTS shop_orders (
  id uuid PRIMARY KEY,
  token_hash text NOT NULL,
  request_hash text NOT NULL,
  package_id text NOT NULL,
  uid text NOT NULL,
  nickname text NOT NULL,
  player_level integer NOT NULL,
  customer_name text NOT NULL,
  mobile text NOT NULL,
  email text NOT NULL,
  requested integer NOT NULL CHECK (requested > 0),
  diamonds integer NOT NULL,
  status text NOT NULL DEFAULT 'creating' CHECK (status IN ('creating','pending','paid','expired','cancelled')),
  created_at timestamptz NOT NULL DEFAULT now(),
  gateway_id text UNIQUE,
  profile text,
  payable integer,
  upi_uri text,
  gateway_created timestamptz,
  expires_at timestamptz,
  paid_at timestamptz,
  CHECK (payable IS NULL OR payable BETWEEN requested + 1 AND requested + 199)
);
CREATE TABLE IF NOT EXISTS shop_alerts (
  order_id uuid NOT NULL REFERENCES shop_orders(id),
  kind text NOT NULL CHECK (kind IN ('created','paid')),
  sent_at timestamptz,
  lease_until timestamptz,
  lease_id uuid,
  next_at timestamptz NOT NULL DEFAULT now(),
  attempts integer NOT NULL DEFAULT 0,
  PRIMARY KEY (order_id, kind)
);
CREATE INDEX IF NOT EXISTS shop_alerts_due ON shop_alerts(next_at) WHERE sent_at IS NULL;
-- PostgreSQL: run once on the website database before deploying this version.
-- Safe to rerun; existing order IDs and payment mappings are preserved.
ALTER TABLE shop_orders ADD COLUMN IF NOT EXISTS order_number text;
CREATE UNIQUE INDEX IF NOT EXISTS shop_orders_order_number_unique ON shop_orders(order_number);
