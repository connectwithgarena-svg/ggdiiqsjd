# GGDiamond website — inline QR checkout

Existing React/Vite website with server-verified FFShop payments and Telegram order alerts.

**Deployment and environment setup:** [INTEGRATION.md](INTEGRATION.md).

```sh
npm ci
npm run db:migrate
npm run dev
```

Copy `.env.example` to an ignored `.env` and supply your own values before local use. Vercel variables are configured in the project dashboard. Run `backend/schema.sql` once against PostgreSQL.

Validation: `npm run lint`, `npm test`, `npm run build`.
