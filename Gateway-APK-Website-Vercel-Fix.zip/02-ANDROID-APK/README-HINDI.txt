FF Shop Relay 1.5 — signed APK, Android8+.
Android source: ../01-PAYMENT-GATEWAY/source/android/
APK वही पहले से verified signed build है। Install/update करके अपने gateway से pair करें, notification access और background/battery permissions दें।
पहले से paired इसी Relay1.5 को दोबारा install/pair करना जरूरी नहीं है। पुरानी और नई relay एक साथ चालू न रखें।
Server credentials पहले से configured नहीं हैं। Physical phone/live merchant test बाकी है।
