# पूरा payment package — पहले यह पढ़ें

## Folders
1. 01-PAYMENT-GATEWAY: latest FF Shop2.0/schema7 SQL-fix gateway, Pages upload ZIP, full gateway + Android source, migrations, licences और instructions।
2. 02-ANDROID-APK: signed FF-Shop-Relay-1.5.apk, Android8+। यही verified existing build है।
3. 03-WEBSITE-VERCEL: complete latest website — GORDNO + UID + 6 digits, QR के नीचे order number, Tax breakdown, separate QR page, Back/cancel flow और separate success Telegram bot।
4. 04-MAINTENANCE-BROWSER-SETUP: Worker/config, browser से deployment के लिए।
5. 05-DATABASE: website PostgreSQL update और gateway D1 diagnostic/conditional upgrades। दोनों databases अलग हैं।

## Website — Vercel
- Folder03 के अंदर की files website GitHub repository root में upload करें। Combined ZIP या ऊपर के folders Vercel root में मत डालें।
- Existing website: PostgreSQL/Neon SQL Editor में 05-DATABASE/WEBSITE-PostgreSQL-order-number-update.sql Run करें, फिर उसी Vercel project को redeploy करें।
- Fresh website DB: 03-WEBSITE-VERCEL/backend/schema.sql Run करें।
- Website folder में .env.example, SETUP-HINDI.md और INTEGRATION.md हैं। अपने gateway API key, PostgreSQL URL, webhook secret और Telegram values Vercel env में लगाएँ।
- Vite; Node24; install npm ci; build npm run build; output dist।

## Gateway — Cloudflare
- पहले से working schema7 gateway पर database upgrade दोबारा नहीं चलाना है। Existing scheduler/bindings बनाए रखें।
- Deploy के लिए केवल 01-PAYMENT-GATEWAY/01-PAGES-UPLOAD.zip Pages में upload करें।
- DB update से पहले backup/current schema check करें। schema5 के लिए schema5 upgrade, schema6 के लिए main02 update, schema7 पर skip। Fresh-only SQL existing DB पर नहीं चलाएँ। Full flow gateway की 04-START-HERE-HINDI.md में है।
- Browser-only maintenance setup चाहिए तो folder04 की files अलग GitHub repo root में रखें। wrangler.json में अपना D1 name/ID और existing Worker name रखें। Cloudflare Workers Builds में import करके deploy command npx wrangler deploy रखें। Existing Durable Object migration history preserve करें।
- Pages में LIFECYCLE external Durable Object binding उसी Worker की LifecycleClock class से जोड़कर Pages redeploy करें। पहले से working Worker को बदलने की जरूरत नहीं है।
- Gateway webhook URL और website वाला same webhook secret configure रखें।

## Checks और सीमाएँ
Code बदला नहीं है। Previous checks: gateway80 tests, Android18 tests/build/lint/signature, website32 tests/build/typecheck और synthetic browser। Current source hashes वही हैं; combined ZIP integrity/files अलग से जाँचे गए हैं।
Live payment/phone/Telegram/Vercel deployment test नहीं किया गया। CodeRabbit review disabled है।
Real secrets, private signing key, customer/payment DB dump, node_modules और local build cache शामिल नहीं हैं। यह source/deployment package है, live DB backup नहीं।
