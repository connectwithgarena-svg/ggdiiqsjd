ALTER TABLE shop_orders ADD COLUMN IF NOT EXISTS order_number text;
CREATE UNIQUE INDEX IF NOT EXISTS shop_orders_order_number_unique ON shop_orders(order_number);
