# Missing late_at repair

The original2.0 main update assumed schema6. Running it on schema5 reproduces `no such column: late_at` in the copy SELECT. Depending on how SQL was submitted, earlier statements may have removed triggers and left an empty payments_v20 staging table. The actual remote state has not been inspected.

First export/back up D1 and run diagnostics.sql (read-only). If payments_v20 exists, also run `SELECT COUNT(*) AS staging_rows FROM payments_v20;`.

- Schema5, BOTH late_at and late_evidence absent, original payments present, staging absent or EMPTY: use corrected upgrade-from-schema5.sql, once, as a complete file.
- Schema3/4 with neither late column: use corrected upgrade-from-schema3-or4.sql; same staging conditions.
- Intact schema6: corrected02-DATABASE-UPDATE.sql.
- Schema7, only one late column, populated staging, missing original payments, or metadata/columns disagreeing: inspect before choosing SQL. Do not drop a populated table or run fresh-database SQL over this database.

Do not add only late_at or edit schema_version by hand. Other tables/triggers are required. Successful schema7 upgrade activates the previously requested deletion lifecycle, so old overdue records become eligible for cleanup.

Changes: prerequisite guard before dropping payment triggers; tolerate already-removed triggers during schema6 recovery; resume an empty staging table without deleting data; refuse populated staging before dropping triggers.

Verification: full build and80tests passed. Three new regressions cover wrong-upgrade preservation, original missing-column/empty-staging recovery with existing orders and foreign keys, and refusal to discard populated staging.8nested archives/23checksums/79source/11Pages files verified. Packaged SQL fresh/schema3/4/5/6 paths verified. TypeScript/runtime/Android inputs unchanged; relevant prior checks reused. CodeRabbit review is disabled for this task, so no review ran. No live D1 repair/deployment was performed; remote diagnostics are still needed.
