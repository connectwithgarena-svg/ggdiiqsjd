# Vercel API startup error — corrected files

`ERR_MODULE_NOT_FOUND: Cannot find module /var/task/server` के लिए API और पूरी server import chain में explicit `.js` paths का fix है।

1. Website ZIP extract करें। उसकी अंदर की files website GitHub repository root में upload/replace करें। केवल api/index.ts बदलना पर्याप्त नहीं है; server.ts और backend/payments.ts भी corrected files से replace करें। पूरा source upload करना आसान है।
2. उसी Vercel project में नया deployment बनाएं/redeploy करें। Existing env values रखें। नया database SQL इस API fix के लिए नहीं चाहिए। GORDNO वाला पहले का PostgreSQL migration अभी तक नहीं किया है तो SETUP-HINDI.md के अनुसार उसे apply करें।
3. Deployment ready होने के बाद अपने website domain पर /api/reviews खोलें। JSON response मिलना चाहिए, function startup error नहीं। फिर checkout पर QR creation test करें।
4. Gateway/APK में इस fix के लिए कोई change नहीं है। Combined ZIP से deploy करते समय 03-WEBSITE-VERCEL के अंदर की files website repo root में डालें। Combined ZIP का पूरा folder Vercel root में मत डालें।

32 tests, native emitted JavaScript API smoke, typecheck और production build पास हैं। Live deployment/payment अभी user के account से होना बाकी है। CodeRabbit review task में disabled है।
