// Build first. Use the previously verified, signed APK; no private keys bundled.
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { resolve } from "node:path";
import { createHash } from "node:crypto";
import { zipSync } from "fflate";
const args = process.argv.slice(2),
  apk = args[args.indexOf("--apk") + 1],
  out = args[args.indexOf("--out") + 1];
if (!args.includes("--apk") || !args.includes("--out") || !apk || !out)
  throw Error(
    "Usage: node scripts/package.mjs --apk signed.apk --out final.zip",
  );
const files = {};
const load = async (name, path) =>
  (files[name] = new Uint8Array(await readFile(path)));
for (const name of ["LICENSE", "NOTICE", "PROVIDERS.md", "PRIVACY.md"])
  await load(name, "../" + name);
for (const name of ["PAYMENT-LOGIC.md", "RELEASE-NOTES.md"])
  await load(name, name);
for (const [name, path] of [
  ["03-WEBSITE-INTEGRATION.md", "WEBSITE-INTEGRATION.md"],
  ["04-START-HERE-HINDI.md", "START-HERE-HINDI.md"],
  ["source.zip", "dist/source.zip"],
  ["05-MAINTENANCE-WORKER.js", "build/jobs.js"],
  ["extras/setup-key.html", "web/setup-key.html"],
  ["FF-Shop-Relay-1.5.apk", apk],
])
  await load(name, path);
const pageFiles = {};
for (const name of [
  "index.html",
  "app.js",
  "style.css",
  "_worker.js",
  "_headers",
  "_routes.json",
  "source.zip",
  "deployment-check.html",
  "deployment-check.js",
  "integration-guide.html",
  "PRIVACY.md",
])
  pageFiles[name] = new Uint8Array(await readFile("dist/" + name));
files["01-PAGES-UPLOAD.zip"] = zipSync(pageFiles, { level: 9 });
await load("diagnostics.sql", "scripts/diagnostics.sql");
const migrations = await Promise.all(
  [1, 2, 3, 4, 5, 6, 7].map((n) => readFile(`migrations/000${n}.sql`, "utf8")),
);
const consoleSQL = (text) =>
  text
    .replace(/CREATE TRIGGER[\s\S]*?END;/g, (s) => s.replace(/\n/g, " "))
    .split(/\r?\n/)
    .filter((s) => s.trim() && !s.trim().startsWith("--"))
    .join("\n") + "\n";
for (const [name, start] of [
  ["02-DATABASE-UPDATE.sql", 6],
  ["extras/upgrade-from-schema5.sql", 5],
  ["extras/upgrade-from-schema3-or4.sql", 3],
  ["extras/database-FRESH-ONLY.sql", 0],
  ["extras/upgrade-from-1.3.sql", 1],
  ["extras/upgrade-from-1.4.sql", 2],
])
  files[name] = new TextEncoder().encode(
    consoleSQL(migrations.slice(start).join("\n")),
  );
const helper = {};
for (const name of ["ffshop-client.mjs", "README.md"])
  helper[name] = new Uint8Array(await readFile("website-integration/" + name));
helper["LICENSE"] = files.LICENSE;
helper["NOTICE"] = files.NOTICE;
files["WEBSITE-SERVER-HELPER.zip"] = zipSync(helper, { level: 9 });
files["00-READ-FIRST.txt"] = new TextEncoder().encode(
  "FF SHOP2.0\n\nBackup D1; apply the correct one-time schema7 migration per04-START-HERE-HINDI.md. Required: deploy LifecycleClock Durable Object from maintenance Worker and bind Pages LIFECYCLE to that Worker. Then upload01-PAGES-UPLOAD.zip. Readiness2.0.0/schema7/lifecycle must PASS. Random adjustment1..199paise; QR7min; unpaid expires immediately; expired deletes15min later; paid deletes15min after payment. No grace or late success. Amount released only on deletion. Physical alarm execution may be delayed by Cloudflare.\n",
);
const schedulerExample = JSON.parse(
  await readFile("wrangler.jobs.example.json", "utf8"),
);
schedulerExample.main = "05-MAINTENANCE-WORKER.js";
files["06-SCHEDULER-CONFIG.example.json"] = new TextEncoder().encode(
  JSON.stringify(schedulerExample, null, 2) + "\n",
);
files["SHA256SUMS.txt"] = new TextEncoder().encode(
  Object.keys(files)
    .sort()
    .map(
      (name) =>
        createHash("sha256").update(files[name]).digest("hex") + "  " + name,
    )
    .join("\n") + "\n",
);
await mkdir(resolve(out, ".."), { recursive: true });
await writeFile(out, zipSync(files, { level: 9 }));
console.log(
  "Final numbered package written: " +
    resolve(out) +
    " (" +
    Object.keys(files).length +
    " files)",
);
