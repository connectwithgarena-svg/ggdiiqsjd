-- Apply once after schema6. Backup first; old orders become eligible for lifecycle cleanup.
-- Stop before changing any payment table/trigger if the prerequisite upgrade was skipped.
CREATE TABLE IF NOT EXISTS ffshop_schema6_required (ok INTEGER CONSTRAINT schema6_required_use_matching_upgrade CHECK(ok=1)) STRICT;
INSERT INTO ffshop_schema6_required SELECT CASE WHEN (SELECT value FROM settings WHERE key='schema_version')='6' AND (SELECT COUNT(*) FROM pragma_table_info('payments') WHERE name IN ('late_at','late_evidence'))=2 AND (SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name IN ('receipt_claims','receipt_references','payment_returns'))=3 THEN 1 ELSE 0 END;
DROP TABLE ffshop_schema6_required;
PRAGMA defer_foreign_keys=ON;
CREATE TABLE IF NOT EXISTS payments_v20(id TEXT PRIMARY KEY,scope TEXT NOT NULL,idem TEXT NOT NULL,request_hash TEXT NOT NULL,requested INTEGER NOT NULL CHECK(requested>0 AND requested%100=0),payable INTEGER NOT NULL CHECK(payable>requested AND payable-requested<=599),profile TEXT NOT NULL REFERENCES profiles(id),upi TEXT NOT NULL,payee TEXT NOT NULL,name TEXT NOT NULL,external_id TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','paid','expired','cancelled')),created INTEGER NOT NULL,expires INTEGER NOT NULL,grace INTEGER NOT NULL,reuse INTEGER NOT NULL,paid_at INTEGER,evidence TEXT,late_at INTEGER,late_evidence TEXT,UNIQUE(scope,idem),CHECK(created<expires AND expires<=grace AND grace<reuse),CHECK((status='paid' AND paid_at IS NOT NULL AND evidence IS NOT NULL) OR (status!='paid' AND paid_at IS NULL AND evidence IS NULL))) STRICT;
CREATE TABLE IF NOT EXISTS ffshop_empty_staging_required (ok INTEGER CONSTRAINT staging_contains_data_stop_and_inspect CHECK(ok=1)) STRICT;
INSERT INTO ffshop_empty_staging_required SELECT CASE WHEN EXISTS(SELECT 1 FROM payments_v20) THEN 0 ELSE 1 END;
DROP TABLE ffshop_empty_staging_required;
DROP TRIGGER IF EXISTS confirm_payment;
DROP TRIGGER IF EXISTS queue_paid;
DROP TRIGGER IF EXISTS queue_late;
DROP TRIGGER IF EXISTS queue_failure;
DROP TRIGGER IF EXISTS guard_late_review;
DROP TRIGGER IF EXISTS guard_external_order;
DROP TRIGGER IF EXISTS guard_new_payment_amount;
DROP TRIGGER IF EXISTS guard_destination;
DROP TRIGGER IF EXISTS guard_profile_removal;

INSERT INTO payments_v20 SELECT id,scope,idem,request_hash,requested,payable,profile,upi,payee,name,external_id,status,created,created+420000,created+420000,CASE WHEN status='paid' THEN max(paid_at+900000,created+420001) ELSE created+1320000 END,paid_at,evidence,late_at,late_evidence FROM payments;
DROP TABLE payments;
ALTER TABLE payments_v20 RENAME TO payments;
CREATE INDEX payments_created ON payments(created DESC);
CREATE INDEX payments_pending ON payments(status,expires);
CREATE INDEX payments_deletion ON payments(reuse);
CREATE INDEX payments_external ON payments(scope,external_id);
UPDATE slots SET until=(SELECT reuse FROM payments WHERE id=slots.payment_id);
CREATE TRIGGER guard_new_payment_amount BEFORE INSERT ON payments WHEN NEW.payable-NEW.requested NOT BETWEEN 1 AND 199 BEGIN SELECT RAISE(ABORT,'invalid_payment_adjustment'); END;
CREATE TRIGGER confirm_payment AFTER INSERT ON events WHEN NEW.payment_id IS NOT NULL BEGIN
 UPDATE payments SET status='paid',paid_at=NEW.posted,evidence=NEW.id WHERE id=NEW.payment_id AND status='pending' AND NEW.posted>=created AND NEW.posted<expires AND NEW.received<expires;
 UPDATE events SET status=CASE WHEN EXISTS(SELECT 1 FROM payments WHERE id=NEW.payment_id AND evidence=NEW.id) THEN 'matched' ELSE 'corroborated' END WHERE id=NEW.id;
END;
CREATE TRIGGER paid_deletion AFTER UPDATE OF status ON payments WHEN NEW.status='paid' AND OLD.status!='paid' BEGIN
 UPDATE payments SET reuse=max(NEW.paid_at+900000,expires+1) WHERE id=NEW.id;
 UPDATE slots SET until=(SELECT reuse FROM payments WHERE id=NEW.id) WHERE payment_id=NEW.id;
END;
CREATE TRIGGER cancel_deletion AFTER UPDATE OF status ON payments WHEN NEW.status='cancelled' AND OLD.status!='cancelled' BEGIN
 UPDATE payments SET reuse=max(CAST(unixepoch('subsec')*1000 AS INTEGER)+900000,expires+1) WHERE id=NEW.id;
 UPDATE slots SET until=(SELECT reuse FROM payments WHERE id=NEW.id) WHERE payment_id=NEW.id;
END;
CREATE TRIGGER guard_external_order BEFORE INSERT ON payments WHEN NEW.external_id!='' AND EXISTS(SELECT 1 FROM payments WHERE scope=NEW.scope AND external_id=NEW.external_id) BEGIN SELECT RAISE(ABORT,'duplicate_external_order'); END;
CREATE TRIGGER guard_destination BEFORE UPDATE OF upi ON profiles WHEN NEW.upi!=OLD.upi AND EXISTS(SELECT 1 FROM slots JOIN payments ON payments.id=slots.payment_id WHERE profile=OLD.id) BEGIN SELECT RAISE(ABORT,'pending_destination_change'); END;
CREATE TRIGGER guard_profile_removal BEFORE UPDATE OF removed ON profiles WHEN NEW.removed=1 AND OLD.removed=0 AND EXISTS(SELECT 1 FROM slots JOIN payments ON payments.id=slots.payment_id WHERE profile=OLD.id) BEGIN SELECT RAISE(ABORT,'pending_destination_change'); END;
CREATE TRIGGER IF NOT EXISTS queue_paid AFTER UPDATE OF status ON payments WHEN NEW.status='paid' AND OLD.status!='paid' BEGIN
 INSERT INTO deliveries(id,payment_id,endpoint,secret,payload,next_at)
 SELECT 'paid_'||NEW.id,NEW.id,json_extract(value,'$.endpoint'),json_extract(value,'$.secret'),json_object('id','paid_'||NEW.id,'type','payment.paid','payment',json_object('id',NEW.id,'external_id',NEW.external_id,'status','paid','requested_amount_paise',NEW.requested,'payable_amount_paise',NEW.payable,'paid_at_ms',NEW.paid_at)),NEW.paid_at FROM settings WHERE key='webhook' AND json_extract(value,'$.endpoint')!='';
END;
CREATE TRIGGER queue_failure AFTER UPDATE OF status ON payments WHEN NEW.status IN ('expired','cancelled') AND OLD.status='pending' AND NEW.late_at IS NULL BEGIN
 INSERT INTO deliveries(id,payment_id,endpoint,secret,payload,next_at)
 SELECT NEW.status||'_'||NEW.id,NEW.id,json_extract(value,'$.endpoint'),json_extract(value,'$.secret'),json_object('id',NEW.status||'_'||NEW.id,'type','payment.'||NEW.status,'payment',json_object('id',NEW.id,'external_id',NEW.external_id,'status',NEW.status,'requested_amount_paise',NEW.requested,'payable_amount_paise',NEW.payable)),CAST(unixepoch('subsec')*1000 AS INTEGER) FROM settings WHERE key='webhook' AND json_extract(value,'$.endpoint')!='';
END;
INSERT INTO settings(key,value) VALUES('schema_version','7') ON CONFLICT(key) DO UPDATE SET value=excluded.value;
PRAGMA defer_foreign_keys=OFF;
