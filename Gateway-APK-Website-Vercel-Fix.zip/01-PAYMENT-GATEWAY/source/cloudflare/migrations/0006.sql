-- Apply once after schema 5. Back up D1 first.
ALTER TABLE payments ADD COLUMN late_at INTEGER;
ALTER TABLE payments ADD COLUMN late_evidence TEXT;
CREATE TABLE receipt_claims(id TEXT PRIMARY KEY,first_event TEXT NOT NULL) STRICT;
DROP TRIGGER IF EXISTS confirm_payment;
CREATE TRIGGER confirm_payment AFTER INSERT ON events WHEN NEW.payment_id IS NOT NULL BEGIN
 UPDATE payments SET status='paid',paid_at=NEW.posted,evidence=NEW.id WHERE id=NEW.payment_id AND status='pending' AND late_at IS NULL AND NEW.posted>=created AND NEW.posted<=expires AND NEW.received<=grace;
 UPDATE payments SET late_at=NEW.posted,late_evidence=NEW.id WHERE id=NEW.payment_id AND status IN ('pending','expired') AND late_at IS NULL AND NEW.posted>expires AND NEW.posted<reuse AND NEW.received<reuse;
 UPDATE events SET status=CASE WHEN EXISTS(SELECT 1 FROM payments WHERE id=NEW.payment_id AND evidence=NEW.id) THEN 'matched' WHEN EXISTS(SELECT 1 FROM payments WHERE id=NEW.payment_id AND late_evidence=NEW.id) THEN 'late_matched' ELSE 'corroborated' END WHERE id=NEW.id;
END;
CREATE TRIGGER queue_late AFTER UPDATE OF late_at ON payments WHEN NEW.late_at IS NOT NULL AND OLD.late_at IS NULL BEGIN
 INSERT INTO deliveries(id,payment_id,endpoint,secret,payload,next_at)
 SELECT 'late_'||NEW.id,NEW.id,json_extract(value,'$.endpoint'),json_extract(value,'$.secret'),json_object('id','late_'||NEW.id,'type','payment.late_payment','payment',json_object('id',NEW.id,'external_id',NEW.external_id,'status','late_payment','requested_amount_paise',NEW.requested,'payable_amount_paise',NEW.payable,'paid_at_ms',NEW.late_at)),NEW.late_at FROM settings WHERE key='webhook' AND json_extract(value,'$.endpoint')!='';
END;
CREATE TRIGGER queue_failure AFTER UPDATE OF status ON payments WHEN NEW.status IN ('expired','cancelled') AND OLD.status='pending' AND NEW.late_at IS NULL BEGIN
 INSERT INTO deliveries(id,payment_id,endpoint,secret,payload,next_at)
 SELECT NEW.status||'_'||NEW.id,NEW.id,json_extract(value,'$.endpoint'),json_extract(value,'$.secret'),json_object('id',NEW.status||'_'||NEW.id,'type','payment.'||NEW.status,'payment',json_object('id',NEW.id,'external_id',NEW.external_id,'status',NEW.status,'requested_amount_paise',NEW.requested,'payable_amount_paise',NEW.payable)),CAST(unixepoch('subsec')*1000 AS INTEGER) FROM settings WHERE key='webhook' AND json_extract(value,'$.endpoint')!='';
END;
CREATE TRIGGER guard_late_review BEFORE UPDATE OF status ON payments WHEN NEW.status='paid' AND OLD.late_at IS NOT NULL BEGIN SELECT RAISE(ABORT,'late_credit_requires_manual_reconciliation'); END;
INSERT INTO settings(key,value) VALUES('schema_version','6') ON CONFLICT(key) DO UPDATE SET value=excluded.value;
CREATE INDEX payments_external ON payments(scope,external_id);
CREATE TRIGGER guard_external_order BEFORE INSERT ON payments WHEN NEW.external_id!='' AND EXISTS(SELECT 1 FROM payments WHERE scope=NEW.scope AND external_id=NEW.external_id) BEGIN SELECT RAISE(ABORT,'duplicate_external_order'); END;
DROP TRIGGER IF EXISTS guard_destination;
CREATE TRIGGER guard_destination BEFORE UPDATE OF upi ON profiles WHEN NEW.upi!=OLD.upi AND EXISTS(SELECT 1 FROM payments WHERE profile=OLD.id AND reuse>unixepoch('subsec')*1000) BEGIN SELECT RAISE(ABORT,'pending_destination_change'); END;
DROP TRIGGER IF EXISTS guard_profile_removal;
CREATE TRIGGER guard_profile_removal BEFORE UPDATE OF removed ON profiles WHEN NEW.removed=1 AND OLD.removed=0 AND EXISTS(SELECT 1 FROM payments WHERE profile=OLD.id AND reuse>unixepoch('subsec')*1000) BEGIN SELECT RAISE(ABORT,'pending_destination_change'); END;
CREATE TABLE receipt_references(profile TEXT NOT NULL,reference TEXT NOT NULL,first_event TEXT NOT NULL,PRIMARY KEY(profile,reference)) STRICT;
INSERT OR IGNORE INTO receipt_references SELECT profile,upper(reference),'manual:'||id FROM reviews;
CREATE TRIGGER claim_manual_reference BEFORE INSERT ON reviews BEGIN
 INSERT INTO receipt_references VALUES(NEW.profile,upper(NEW.reference),'manual:'||NEW.id);
END;
