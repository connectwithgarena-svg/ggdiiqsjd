import { Env, sha, sql, one, fail } from "./core";

// BharatPe exposes minute-resolution receipt rows without a transaction ID/date.
// Match an unseen row to the unique amount and order window; retain row hashes
// across devices/events so refreshes cannot reuse an already observed credit.
export function bharatPeList(
  e: any,
): { amount: number; minute: number; key: string }[] | null {
  if (
    e.package_name !== "com.bharatpe.app" ||
    (e.title || "").trim() ||
    (e.text || "").trim()
  )
    return null;
  const lines = (e.big_text || "")
    .normalize("NFKC")
    .split(/\r?\n/)
    .map((s: string) => s.trim())
    .filter(Boolean);
  if (
    lines.pop() !== "Refresh" ||
    lines.pop() !== "Close" ||
    !lines.length ||
    lines.length % 3 ||
    lines.length > 30
  )
    return null;
  const day =
    Math.floor((e.posted_at_ms + 19800000) / 86400000) * 86400000 - 19800000;
  const result: { amount: number; minute: number; key: string }[] = [];
  for (let i = 0; i < lines.length; i += 3) {
    const time = /^(0?[1-9]|1[0-2]):([0-5]\d)\s+(AM|PM)$/i.exec(lines[i]);
    const name = lines[i + 1];
    const money = /^₹\s*(\d{1,6})(?:\.(\d{1,2}))?$/.exec(lines[i + 2]);
    if (
      !time ||
      !money ||
      !/^[\p{L}\p{M} .'-]{1,120}$/u.test(name) ||
      !/\p{L}/u.test(name) ||
      /\b(refund|settlement|failed|pending|reversed|cashback|reward|debited|sent|request|cancelled)\b/i.test(
        name,
      )
    )
      return null;
    const clockMinute =
      ((Number(time[1]) % 12) + (time[3].toUpperCase() === "PM" ? 12 : 0)) *
        60 +
      Number(time[2]);
    let minute = day + clockMinute * 60000;
    if (minute > e.posted_at_ms) minute -= 86400000;
    const amount =
      Number(money[1]) * 100 + Number((money[2] || "").padEnd(2, "0"));
    if (
      amount <= 0 ||
      (result.length && minute > result[result.length - 1].minute)
    )
      return null;
    // The full inferred minute distinguishes genuinely new credits after reuse.
    // Rows with an original old minute still cannot match a newer order.
    const key = JSON.stringify([
      minute,
      name.replace(/\s+/g, " ").toLowerCase(),
      amount,
    ]);
    if (result.some((r) => r.key === key)) return null;
    result.push({ amount, minute, key });
  }
  return result;
}

export async function ingestBharatPeList(
  env: Env,
  device: any,
  event: any,
  eventId: string,
  hash: string,
  list: NonNullable<ReturnType<typeof bharatPeList>>,
) {
  const fingerprints = await Promise.all(
    list.map((r) => sha("bharatpe-row\n" + r.key)),
  );
  const rowIds = await Promise.all(
    list.map((_, i) => sha(eventId + ":row:" + i)),
  );
  const respond = async (duplicate: boolean) => {
    const stored = await one(env, "SELECT * FROM events WHERE id=?", eventId);
    if (!stored) return null;
    if (stored.hash !== hash)
      fail(409, "event_conflict", "Event ID reused with different content");
    const matched = await one(
      env,
      `SELECT COUNT(*) AS n FROM events WHERE id IN (${rowIds.map(() => "?").join(",")}) AND status='matched'`,
      ...rowIds,
    );
    return {
      event_id: event.event_id,
      relay_event_id: eventId,
      status: stored.status,
      duplicate,
      transitioned: !duplicate && matched.n > 0,
    };
  };
  const replay = await respond(true);
  if (replay) return replay;
  const now = Date.now();
  const auth =
    "EXISTS(SELECT 1 FROM devices WHERE id=? AND enabled=1 AND epoch=?)";
  const rootGuard =
    "EXISTS(SELECT 1 FROM events WHERE id=? AND hash=? AND received=?)";
  const statements = [
    sql(
      env,
      `INSERT OR IGNORE INTO events(id,device_id,source_id,hash,package,profile,posted,received,reason,status)
     SELECT ?,?,?,?,?,?,?,?,'bharatpe_time_amount_checked','processed' WHERE ${auth}`,
      eventId,
      device.id,
      event.event_id,
      hash,
      event.package_name,
      "bharatpe",
      event.posted_at_ms,
      now,
      device.id,
      device.epoch,
    ),
  ];
  for (let index = 0; index < list.length; index++) {
    const row = list[index],
      fingerprint = fingerprints[index];
    // Claim every observed row, including unmatched/old rows. A later order or
    // another phone must not reinterpret an earlier observation as a new credit.
    statements.push(
      sql(
        env,
        `INSERT OR IGNORE INTO bharatpe_rows(id,first_event,received)
       SELECT ?,?,? WHERE ${rootGuard}`,
        fingerprint,
        eventId,
        now,
        eventId,
        hash,
        now,
      ),
    );
    statements.push(
      sql(
        env,
        `INSERT OR IGNORE INTO events(id,device_id,source_id,hash,package,profile,amount,posted,received,reason,status,payment_id)
       SELECT ?,?,?,?,?,?,?,?,?,
         CASE WHEN EXISTS(SELECT 1 FROM bharatpe_rows WHERE id=? AND first_event!=?)
           THEN 'bharatpe_row_replayed' ELSE 'bharatpe_amount_or_time_mismatch' END,
         'unmatched',
         (SELECT p.id FROM payments p JOIN slots s ON s.payment_id=p.id
          WHERE p.profile='bharatpe' AND p.payable=? AND s.amount=p.payable
          AND p.created<=? AND ?<p.expires AND ?<p.expires AND s.until>?
          AND p.created<? AND ?<p.expires AND p.status='pending'
          AND EXISTS(SELECT 1 FROM bharatpe_rows WHERE id=? AND first_event=?)
          AND (SELECT COUNT(*) FROM json_each(?) WHERE json_extract(value,'$.amount')=p.payable AND json_extract(value,'$.minute')+60000>p.created AND json_extract(value,'$.minute')<p.reuse)=1)
       WHERE ${rootGuard}`,
        rowIds[index],
        device.id,
        event.event_id + ":row:" + index,
        fingerprint,
        event.package_name,
        "bharatpe",
        row.amount,
        Math.max(row.minute, Math.min(event.posted_at_ms, row.minute + 59999)),
        now,
        fingerprint,
        eventId,
        row.amount,
        event.posted_at_ms,
        event.posted_at_ms,
        now,
        now,
        // A displayed minute can overlap the creation minute. The signed
        // notification timestamp must still be at/after creation and before expiry.
        row.minute + 60000,
        row.minute,
        fingerprint,
        eventId,
        JSON.stringify(list),
        eventId,
        hash,
        now,
      ),
    );
  }
  const results = await env.DB.batch(statements);
  const response = await respond(results[0].meta.changes === 0);
  if (!response) fail(401, "unknown_relay_device", "Phone has been revoked");
  return response;
}
