import { advanceLifecycle, armLifecycle } from "./lifecycle";
import { normalizeReturnURL } from "./website";
import { bharatPeList, ingestBharatPeList } from "./bharatpe";
import {
  Env,
  fail,
  text,
  sha,
  id,
  sql,
  one,
  rows,
  analyzeNotification,
  viewPayment,
} from "./core";
export async function createPayment(
  env: Env,
  body: any,
  key: string | null,
  scope: string,
) {
  if (!key || key.length > 128 || !/^[\w-]+$/.test(key))
    fail(400, "idempotency_required", "Send a unique Idempotency-Key");
  if (
    !Number.isSafeInteger(body.amount) ||
    body.amount < 1 ||
    body.amount > 100000
  )
    fail(
      400,
      "invalid_amount",
      "Amount must be whole rupees between 1 and 100000",
    );
  const name = text(body.name),
    external =
      body.external_id === undefined ? "" : text(body.external_id, 120);
  if (
    body.profile !== undefined &&
    !["paytm", "phonepe", "hdfc", "bharatpe", "gpay"].includes(body.profile)
  )
    fail(400, "provider", "Select a supported business account");
  const returnURL =
    body.return_url === undefined ? "" : normalizeReturnURL(body.return_url);
  const identity: unknown[] =
    body.profile === undefined
      ? [body.amount, name, external]
      : [body.amount, name, external, body.profile];
  if (returnURL) identity.push({ return_url: returnURL });
  const requestHash = await sha(JSON.stringify(identity));
  if (!env.LIFECYCLE)
    fail(
      503,
      "lifecycle_unconfigured",
      "Configure the lifecycle scheduler first",
    );
  await advanceLifecycle(env);
  const existing = await one(
    env,
    "SELECT * FROM payments WHERE scope=? AND (idem=? OR (external_id=? AND external_id!='')) ORDER BY created DESC LIMIT 1",
    scope,
    key,
    external,
  );
  if (existing) {
    await armLifecycle(env);
    if (existing.request_hash !== requestHash)
      fail(409, "idempotency_conflict", "Key already used for another order");
    return {
      payment: viewPayment(existing, env.PUBLIC_ORIGIN),
      replayed: true,
    };
  }
  if (returnURL) {
    const website = await one(
      env,
      "SELECT value FROM settings WHERE key='website_origin'",
    );
    if (
      !website ||
      new URL(returnURL).origin !== website.value ||
      website.value === env.PUBLIC_ORIGIN
    )
      fail(
        400,
        "return_origin",
        "Save your website origin in Integrations before using its return URL",
      );
  }
  const profile = body.profile
    ? await one(
        env,
        "SELECT * FROM profiles WHERE id=? AND enabled=1 AND removed=0",
        body.profile,
      )
    : await one(
        env,
        "SELECT * FROM profiles WHERE active=1 AND enabled=1 AND removed=0",
      );
  if (!profile)
    fail(
      409,
      "no_profile",
      "Save and activate a merchant QR destination first",
    );
  const now = Date.now(),
    paymentId = id(),
    requested = body.amount * 100;
  // Reserve through the seven-minute window plus fifteen minutes after expiry.
  const expires = now + 7 * 60000,
    grace = expires,
    reuse = expires + 15 * 60000;

  const used = new Set(
    (
      await rows(
        env,
        "SELECT amount FROM slots WHERE amount BETWEEN ? AND ?",
        requested + 1,
        requested + 199,
      )
    ).map((r: any) => r.amount),
  );
  // Shuffle all 199 integer-paise adjustments without modulo bias.
  const candidates = Array.from({ length: 199 }, (_, i) => i + 1);
  for (let i = candidates.length - 1; i > 0; i--) {
    const range = i + 1,
      limit = Math.floor(0x100000000 / range) * range;
    let draw: number;
    do {
      draw = crypto.getRandomValues(new Uint32Array(1))[0];
    } while (draw >= limit);
    const j = draw % range;
    [candidates[i], candidates[j]] = [candidates[j], candidates[i]];
  }
  for (const offset of candidates.filter((n) => !used.has(requested + n))) {
    try {
      await env.DB.batch([
        sql(
          env,
          `INSERT INTO payments(id,scope,idem,request_hash,requested,payable,profile,upi,payee,name,external_id,created,expires,grace,reuse) SELECT ?,?,?,?,?,?,id,upi,payee,?,?,?,?,?,? FROM profiles WHERE id=? AND enabled=1 AND removed=0 AND (?=1 OR active=1) AND upi=?`,
          paymentId,
          scope,
          key,
          requestHash,
          requested,
          requested + offset,
          name,
          external,
          now,
          expires,
          grace,
          reuse,
          profile.id,
          body.profile ? 1 : 0,
          profile.upi,
        ),
        sql(
          env,
          "INSERT INTO slots(amount,payment_id,until) VALUES(?,?,?)",
          requested + offset,
          paymentId,
          reuse,
        ),
        ...(returnURL
          ? [
              sql(
                env,
                "INSERT INTO payment_returns(payment_id,url) VALUES(?,?)",
                paymentId,
                returnURL,
              ),
            ]
          : []),
      ]);
      await armLifecycle(env);
      return {
        payment: viewPayment(
          await one(env, "SELECT * FROM payments WHERE id=?", paymentId),
          env.PUBLIC_ORIGIN,
        ),
        replayed: false,
      };
    } catch (err) {
      const replay = await one(
        env,
        "SELECT * FROM payments WHERE scope=? AND (idem=? OR (external_id=? AND external_id!='')) ORDER BY created DESC LIMIT 1",
        scope,
        key,
        external,
      );
      if (replay) {
        await armLifecycle(env);
        if (replay.request_hash !== requestHash)
          fail(
            409,
            "idempotency_conflict",
            "Key already used for another order",
          );
        return {
          payment: viewPayment(replay, env.PUBLIC_ORIGIN),
          replayed: true,
        };
      }
      if (!/UNIQUE constraint failed: slots.amount/.test(String(err)))
        throw err;
    }
  }
  fail(
    409,
    "amount_capacity",
    "No unique payable amount available. Try again later.",
  );
}
export async function ingest(env: Env, device: any, event: any) {
  if (
    event.schema_version !== 1 ||
    typeof event.event_id !== "string" ||
    !/^[A-Za-z0-9_-]{16,128}$/.test(event.event_id) ||
    typeof event.package_name !== "string" ||
    event.package_name.length > 150 ||
    !Number.isSafeInteger(event.posted_at_ms)
  )
    fail(400, "invalid_event", "Invalid event");
  for (const field of ["title", "text", "big_text", "custom_text"])
    if (
      event[field] !== undefined &&
      (typeof event[field] !== "string" || event[field].length > 8192)
    )
      fail(400, "invalid_event", "Notification too long");
  const now = Date.now();
  if (
    event.posted_at_ms < device.epoch ||
    event.posted_at_ms > now + 60000 ||
    event.posted_at_ms < now - 86400000
  )
    fail(400, "invalid_event_time", "Notification outside allowed time window");
  const hash = await sha(
    JSON.stringify([
      event.package_name,
      event.posted_at_ms,
      event.title || "",
      event.text || "",
      event.big_text || "",
      ...(event.custom_text === undefined ? [] : [event.custom_text]),
    ]),
  );
  // Current Relay sends custom layout text in big_text. Also accept a signed
  // custom_text field from older relays, preserving conflicting/negative text.
  const evidence = {
    ...event,
    big_text: [
      ...new Set(
        [event.big_text, event.custom_text]
          .filter(
            (value): value is string =>
              typeof value === "string" && !!value.trim(),
          )
          .map((value) => value.trim()),
      ),
    ].join("\n"),
  };
  const eventId = await sha(device.id + "\n" + event.event_id),
    analysis =
      event.package_name === "com.bharatpe.app" &&
      /^(?:\d{1,2}:\d{2}\s*(?:AM|PM)|Close|Refresh)\s*$/im.test(
        evidence.big_text,
      )
        ? { observation: null, reason: "bharatpe_unrecognized_list" }
        : analyzeNotification(evidence),
    obs = analysis.observation;
  const list = bharatPeList(evidence);
  if (list) return ingestBharatPeList(env, device, event, eventId, hash, list);
  // Permanent content claims prevent the same receipt on another device or
  // under a fresh event ID from settling another order. No timestamp in the key.
  const fields = [
    ...new Set(
      [evidence.title, evidence.text, evidence.big_text]
        .map((v) => (v || "").normalize("NFKC").trim().replace(/\s+/g, " "))
        .filter(Boolean),
    ),
  ];
  const receiptText = fields
    .filter((v) => !fields.some((other) => other !== v && other.includes(v)))
    .sort()
    .join("\n");
  const references = [
    ...receiptText.matchAll(
      /\b(?:UTR|UPI\s+(?:ref(?:erence)?|transaction)\s*(?:no\.?|id)?|transaction\s+id)\s*[:#-]?\s*([A-Za-z0-9]{6,40})\b/gi,
    ),
  ].map((m) => m[1].toUpperCase());
  const receiptId = await sha(
    JSON.stringify([
      obs?.profile || event.package_name,
      references.length
        ? ["reference", [...new Set(references)].sort()]
        : ["content", receiptText, event.posted_at_ms],
    ]),
  );
  // Honor explicit receipt dates rather than treating a refreshed notification
  // as a new transfer. Unsupported/contradictory dated formats need review.
  let paymentTime = event.posted_at_ms;
  const iso = [
    ...receiptText.matchAll(
      /\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2})\b/g,
    ),
  ];
  const dated = [
    ...receiptText.matchAll(
      /\b(\d{1,2}) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) (\d{4}) (\d{1,2}):([0-5]\d) (AM|PM)\b/gi,
    ),
  ];
  const times = iso.map((m) => Date.parse(m[0]));
  for (const m of dated) {
    const month = "jan feb mar apr may jun jul aug sep oct nov dec"
      .split(" ")
      .indexOf(m[2].toLowerCase());
    const hour = Number(m[4]);
    times.push(
      hour < 1 || hour > 12
        ? NaN
        : Date.UTC(
            Number(m[3]),
            month,
            Number(m[1]),
            (hour % 12) + (m[6].toUpperCase() === "PM" ? 12 : 0),
            Number(m[5]),
          ) - 19800000,
    );
  }
  if (times.length) {
    paymentTime = times.every(
      (t) => Number.isFinite(t) && t === times[0] && t <= event.posted_at_ms,
    )
      ? times[0]
      : -1;
  } else if (/\b\d{1,4}[/-]\d{1,2}[/-]\d{1,4}\b/.test(receiptText))
    paymentTime = -1;
  // SQL selects the candidate and applies its transition in the same transaction.
  // Device authorization is checked again in SQL to close revocation races.
  const results = await env.DB.batch([
    sql(
      env,
      `INSERT OR IGNORE INTO receipt_claims(id,first_event) SELECT ?,? WHERE EXISTS(SELECT 1 FROM devices WHERE id=? AND enabled=1 AND epoch=?)`,
      receiptId,
      eventId,
      device.id,
      device.epoch,
    ),
    sql(
      env,
      `INSERT OR IGNORE INTO receipt_references(profile,reference,first_event) SELECT ?,value,? FROM json_each(?) WHERE ? IS NOT NULL AND EXISTS(SELECT 1 FROM devices WHERE id=? AND enabled=1 AND epoch=?)`,
      obs?.profile ?? null,
      eventId,
      JSON.stringify(references),
      obs?.profile ?? null,
      device.id,
      device.epoch,
    ),
    sql(
      env,
      `INSERT OR IGNORE INTO events(id,device_id,source_id,hash,package,profile,amount,posted,received,reason,status,payment_id)
 SELECT ?,?,?,?,?,?,?,?, ?,?,CASE WHEN ? IS NULL OR NOT EXISTS(SELECT 1 FROM profiles WHERE id=?) THEN 'ignored' ELSE 'unmatched' END,
 (SELECT p.id FROM payments p JOIN slots s ON s.payment_id=p.id WHERE p.profile=? AND s.amount=? AND p.created<=? AND ?<p.expires AND ?<p.expires AND p.status IN ('pending','paid') AND s.until>? AND EXISTS(SELECT 1 FROM receipt_claims WHERE id=? AND first_event=?) AND NOT EXISTS(SELECT 1 FROM receipt_references WHERE profile=? AND reference IN (SELECT value FROM json_each(?)) AND first_event!=?))
 WHERE EXISTS(SELECT 1 FROM devices WHERE id=? AND enabled=1 AND epoch=?)`,
      eventId,
      device.id,
      event.event_id,
      hash,
      event.package_name,
      obs?.profile ?? null,
      obs?.amount ?? null,
      paymentTime,
      now,
      obs
        ? "Check business account, exact amount and order time window"
        : analysis.reason,
      obs?.profile ?? null,
      obs?.profile ?? null,
      obs?.profile ?? null,
      obs?.amount ?? null,
      paymentTime,
      paymentTime,
      now,
      now,
      receiptId,
      eventId,
      obs?.profile ?? null,
      JSON.stringify(references),
      eventId,
      device.id,
      device.epoch,
    ),
  ]);
  const result = results[2];
  const stored = await one(env, "SELECT * FROM events WHERE id=?", eventId);
  if (!stored) fail(401, "unknown_relay_device", "Phone has been revoked");
  if (stored.hash !== hash)
    fail(409, "event_conflict", "Event ID reused with different content");
  return {
    event_id: event.event_id,
    relay_event_id: eventId,
    status: stored.status,
    payment_id: stored.payment_id || undefined,
    duplicate: result.meta.changes === 0,
    transitioned: result.meta.changes > 0 && stored.status === "matched",
  };
}
