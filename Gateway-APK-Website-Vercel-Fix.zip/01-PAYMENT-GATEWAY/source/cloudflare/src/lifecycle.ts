import { Env, sql, one, fail } from "./core";

// The deadline is authoritative even if an alarm invocation is delayed.
export async function advanceLifecycle(env: Env, now = Date.now()) {
  await env.DB.batch([
    sql(
      env,
      "UPDATE payments SET status='expired' WHERE status='pending' AND expires<=?",
      now,
    ),
    // Remove FK children first; the whole cleanup is atomic with amount release.
    ...["payment_returns", "reviews", "deliveries", "events", "slots"].map(
      (table) =>
        sql(
          env,
          `DELETE FROM ${table} WHERE payment_id IN (SELECT id FROM payments WHERE reuse<=?)`,
          now,
        ),
    ),
    sql(env, "DELETE FROM payments WHERE reuse<=?", now),
  ]);
}

export async function armLifecycle(env: Env) {
  if (!env.LIFECYCLE)
    fail(
      503,
      "lifecycle_unconfigured",
      "Configure the lifecycle Durable Object binding first",
    );
  const response = await env.LIFECYCLE.get(
    env.LIFECYCLE.idFromName("orders"),
  ).fetch("https://lifecycle.internal/arm", { method: "POST" });
  if (!response.ok)
    fail(
      503,
      "lifecycle_unavailable",
      "Lifecycle scheduler unavailable; retry with the same order key",
    );
}

export class LifecycleClock {
  constructor(
    private state: DurableObjectState,
    private env: Env,
  ) {}
  async schedule() {
    const next = await one(
      this.env,
      `SELECT MIN(deadline) AS deadline FROM (
      SELECT MIN(expires) AS deadline FROM payments WHERE status='pending'
      UNION ALL SELECT MIN(reuse) AS deadline FROM payments)`,
    );
    if (next?.deadline != null)
      await this.state.storage.setAlarm(Math.max(Date.now(), next.deadline));
    else await this.state.storage.deleteAlarm();
  }
  async fetch() {
    await this.state.blockConcurrencyWhile(async () => {
      await advanceLifecycle(this.env);
      await this.schedule();
    });
    return new Response("scheduled");
  }
  async alarm() {
    await this.state.blockConcurrencyWhile(async () => {
      await advanceLifecycle(this.env);
      await this.schedule();
    });
  }
}
