import { test } from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import vm from "node:vm";

// Run the shipped checkout with a controlled clock, DOM and network.
const app = await readFile("web/app.js", "utf8");
const checkout = app.slice(
  app.indexOf("async function checkout()"),
  app.indexOf("(location.pathname.startsWith"),
);
async function fixture() {
  let now = Date.parse("2026-09-30T12:00:00Z"),
    tick,
    expiry,
    initial = true;
  const elements = new Map();
  const element = (id) => {
    if (!elements.has(id)) elements.set(id, { hidden: false, textContent: "" });
    return elements.get(id);
  };
  const payment = {
    id: "fixture",
    status: "pending",
    profile: "bharatpe",
    created_at: new Date(now).toISOString(),
    expires_at: new Date(now + 7 * 60000).toISOString(),
    payable_amount: "550.70",
    requested_amount: "550.00",
    upi_uri: "upi://pay?pa=fixture@invalid&am=550.70",
    payee: "Fixture",
    upi: "fixture@invalid",
  };
  const context = {
    Date: class extends Date {
      static now() {
        return now;
      }
    },
    location: { pathname: "/pay/fixture" },
    document: { hidden: false, getElementById: element },
    root: { innerHTML: "" },
    money: String,
    esc: String,
    bharatTiming: () => "",
    icon: () => "",
    qr: async () => {},
    api: async () => {
      if (initial) {
        initial = false;
        return payment;
      }
      throw Error("offline");
    },
    setTimeout: (fn, delay) => { expiry={fn,delay}; return 2; },
    setInterval: (fn) => {
      tick = fn;
      return 1;
    },
    clearInterval: () => {},
    URL,
  };
  vm.createContext(context);
  await vm.runInContext("let timer;" + checkout + ";checkout()", context);
  return {
    context,
    element,
    payment,
    advance: (ms) => {
      now += ms;
    },
    tick: () => tick(),
    expire: () => expiry.fn(),
    expiryDelay: () => expiry.delay,
  };
}
test("checkout expires at seven minutes even when polling fails or the tab is hidden", async () => {
  const f = await fixture();
  assert.equal(f.element("payment-method").hidden, false);
  f.advance(7 * 60000 - 1);
  await f.tick();
  assert.equal(f.element("payment-method").hidden, false);
  f.context.document.hidden = true;
  f.advance(1);
  await f.tick();
  assert.equal(f.element("payment-method").hidden, true);
  assert.match(f.element("status-detail").textContent, /Do not pay/);
});
test("an in-flight status request cannot keep an expired QR visible", async () => {
  const f = await fixture();
  let finish;
  f.context.api = () =>
    new Promise((resolve) => {
      finish = resolve;
    });
  const pending = f.tick();
  f.advance(7 * 60000);
  await f.tick();
  assert.equal(f.element("payment-method").hidden, true);
  finish(f.payment);
  await pending;
  assert.equal(f.element("payment-method").hidden, true);
});

 test("QR has a separate deadline timer even between polling ticks",async()=>{
 const f=await fixture();assert.equal(f.expiryDelay(),420000);
 f.advance(419999);await f.tick();assert.equal(f.element("payment-method").hidden,false);
 f.advance(1);f.expire();assert.equal(f.element("payment-method").hidden,true);
 assert.equal(f.element("payment-state").textContent,"Payment expired");
 });
