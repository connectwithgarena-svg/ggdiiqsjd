SELECT value AS schema_version FROM settings WHERE key='schema_version';
PRAGMA table_info(payments);
SELECT name FROM sqlite_master WHERE type='table' AND name IN ('payments','payments_v20','receipt_claims','receipt_references','payment_returns');
SELECT name FROM sqlite_master WHERE type='trigger' AND name IN ('confirm_payment','queue_paid','queue_failure','guard_destination','guard_profile_removal','claim_manual_reference');
