# FF Shop2.0 — business notifications

| App | Android package | Profile |
|---|---|---|
| Paytm for Business | `com.paytm.business` | `paytm` |
| PhonePe Business | `com.phonepe.app.business` | `phonepe` |
| HDFC Bank SmartHub Vyapar | `com.hdfc.smarthub` | `hdfc` |
| BharatPe for Business | `com.bharatpe.app` | `bharatpe` |
| Google Pay for Business | `com.google.android.apps.nbu.paisa.merchant` | `gpay` |

All five identifiers were checked against their official Google Play listings on 2026-09-30. This confirms app identity, not live notification formats. Google Pay Business capture is experimental until verified on the merchant phone. Consumer Google Pay/PhonePe packages and arbitrary apps are excluded. Each provider requires explicit phone opt-in; only Paytm is selected initially.

One receiving account per business app. The dashboard stores the QR's receiving UPI destination; it does not log in to merchant accounts. Pending payments protect account removal/UPI changes. Existing orders retain their original provider and destination.

## Capture

The reader captures standard title/text/expanded text, InboxStyle text lines, and visible custom RemoteViews TextViews when standard text is absent. It also handles custom layouts without extras. The local inspector uses the exact same extractor. Limits: 4096 characters per field, 64 inbox lines, 256 custom views/depth20. Negative/repeated amounts remain visible to the parser; malformed or partial fields are discarded. Group summaries and pre-enrollment/old notifications are excluded.

Remote adapter-backed/image-only notifications can have no accessible text even while visibly showing an amount. Android does not expose every app's UI through NotificationListenerService. This app has no Accessibility/screenshot/OCR scraping. Inspect the notification; if text is unavailable, use authenticated merchant-history review.

## Matching

The paired phone signs evidence; the server checks signature, enrollment, time, package, exact adjusted amount and order window. Recognized positive English and strict Hindi receipts are tested using synthetic fixtures for all five providers. Generic amount-only lists, multiple amounts in ordinary receipts, integer-only amounts and negative/ambiguous wording remain unconfirmed. The explicitly supported BharatPe custom list exception is described below.

No physical merchant apps or real bank transfer was available in the sandbox. Before accepting customer orders, send a small generated exact-total payment through every enabled provider, inspect captured fields and check dashboard status. An unrecognized receipt remains pending. A package name or matching amount alone is not bank settlement proof.

For manual review, inspect the receiving merchant's real history, enter exact credited amount and a unique transaction reference, and confirm it belongs to this order. Reference reuse and concurrent callbacks are guarded. Never fulfil based only on a customer screenshot.

## BharatPe custom transaction list (1.9)

The supported layout is repeating `hh:mm AM/PM / payer / ₹amount` rows followed by `Close / Refresh`. Only empty standard title/text and `com.bharatpe.app` are eligible. Current Relay sends visible custom text in `big_text`; the server also supports signed `custom_text`. Different fields are preserved together so conflicting/negative text is not silently discarded. The screenshot-shaped `₹1.1` parses as 110 paise. Group summaries stay excluded.

For all providers, new orders have unique random1–199paise adjustments and a seven-minute payment window. BharatPe rows now match from the first snapshot, including the creation minute, without requiring a prior baseline or overlapping earlier list. The exact amount and provider must agree, the IST displayed minute must overlap the order window, and the signed notification cannot predate creation. Receipt time and gateway arrival must both be inside the seven-minute QR window. After expiry a receipt cannot confirm the order. Old minutes, wrong amounts, cancelled orders and previously observed rows cannot confirm a new order. Two eligible rows for one reserved amount require reconciliation. Commas, unfamiliar footers, extra status text, duplicate indistinguishable rows and nonchronological lists fail closed.

Every parsed row is remembered by a hash of normalized payer, displayed clock minute and amount, globally across devices, even when it did not match an order. The full inferred minute is part of the fingerprint, allowing a genuinely new receipt after amount reuse while old original timestamps remain outside the new order window. Do not delete the ledger to free amount slots. Atomic row claims and payment/callback transitions prevent event retries, changed event IDs and concurrent phones from repeating a confirmation. Historical baseline tables remain compatible but are no longer a matching prerequisite.

**Precision limit:** this layout has no date, seconds or bank transaction ID. The date is inferred from the signed notification time; matching within the creation minute uses minute overlap, not exact bank seconds. A never-seen historical row refreshed at the same clock minute is not distinguishable from a new receipt from these fields alone. A genuinely new receipt with a new full-minute timestamp can match a later order after amount reuse. Use merchant history for disputed or ambiguous credits. These are phone-signed observations, not bank-signed settlement records; verify a small real payment on each enabled merchant app before relying on the integration.
