#2.0 — requested payment lifecycle

Random1..199paise adjustments, global payable-amount reservation, exclusive7-minute payment window without grace/late success, permanent expiry+15minute deletion, paid_at+15minute deletion, amount reuse after deletion. Schema7 and external LifecycleClock Durable Object binding required. No Android changes. Tests cover actual alarm execution and timestamp boundaries. See PAYMENT-LOGIC.md and START-HERE-HINDI.md.

## Historical releases (superseded behavior)

#1.9 — separate late credits and stronger replay prevention

Schema6 required (apply once). See PAYMENT-LOGIC.md for current semantics and START-HERE-HINDI.md for upgrade paths. Added backend late_payment/public expired, expiry/cancellation/late signed events, order-reference dedup, permanent generic receipt/reference claims, manual/automatic shared reference protection, explicit receipt-date checks, and ambiguous BharatPe-row rejection. QR remains seven minutes, reservations24hours. No Android changes. Notifications cannot guarantee bank settlement.

## Historical releases

# FF Shop 1.8

- Seven-minute payment/QR window for every new provider order; five additional minutes only for delivery of a receipt posted before expiry. Existing order deadlines are preserved.
- Sequential globally reserved paise start at .70, increment through .99, wrap to .01 and stop at .69. All 99 offsets are considered under contention. Amounts remain quarantined for 24 hours, including paid/cancelled orders.
- BharatPe first-snapshot and creation-minute matching uses exact amount, provider, signed notification time and displayed IST minute. Removes baseline/overlap/next-minute prerequisites; preserves permanent row claims, signed-event replay protection and atomic webhook enqueue.
- Handles one-decimal custom values such as ₹1.1 as ₹1.10. Supports signed legacy custom_text with length/type checks and event-hash binding.
- Checkout expires the QR independently of status-request success, with bounded polling requests.
- Schema5 and signed Relay1.5 are unchanged. No new migration for an existing schema5 deployment. Numbered bundle includes current matching source and existing signed APK.

Tests use synthetic local Workerd/D1 and checkout clock/network fixtures. Real merchant transfer verification remains a phone-side acceptance step. BharatPe has no date/seconds/transaction ID in this custom layout: creation-minute overlap is supported, but bank-second precision and unseen historical rows cannot be established from these fields alone. See PROVIDERS.md.
