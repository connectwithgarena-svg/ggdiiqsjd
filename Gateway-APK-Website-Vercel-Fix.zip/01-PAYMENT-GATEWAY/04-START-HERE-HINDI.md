# FF Shop2.0 — seven-minute expiry and permanent deletion

## Backup aur SQL

1. Existing D1 backup/export lo. Is release mein old overdue orders bhi permanently delete honge. `SELECT value FROM settings WHERE key='schema_version';` check karo.
2. Schema6: `02-DATABASE-UPDATE.sql` **ek baar**. Schema7: SQL skip. Schema5: `extras/upgrade-from-schema5.sql`. Schema3/4: `extras/upgrade-from-schema3-or4.sql`. Older schema2/1: named1.4/1.3 upgrade. Fresh DB only: `extras/database-FRESH-ONLY.sql`. Full SQL file together apply karo. Wrangler/manual migrations metadata ko reconcile karo; do not reapply migration7.

## Required scheduler deployment

3. Durable Object **LifecycleClock** zaroori hai. Purana cron-only Worker enough nahi hai. Source zip extract karke cloudflare directory mein existing private `wrangler.jobs.json` update karo using `wrangler.jobs.example.json`: same maintenance Worker name, same D1 UUID, `durable_objects.bindings=[{name:"LIFECYCLE",class_name:"LifecycleClock"}]` and migration `{tag:"v1",new_sqlite_classes:["LifecycleClock"]}`. Agar pehle se DO migrations hain, unique new tag use karo aur existing entries preserve karo. Run `npx wrangler deploy --config wrangler.jobs.json` (with your Cloudflare authentication). Cron `*/5 * * * *` recovery/callbacks ke liye rakho. Source main is `src/jobs.ts`; outer ZIP example `06-SCHEDULER-CONFIG.example.json` uses bundled05-MAINTENANCE-WORKER.js.
4. Pages par external Durable Object binding add karo: name `LIFECYCLE`, class `LifecycleClock`, script name **your actual maintenance Worker name**. Preserve `DB`, PUBLIC_ORIGIN and ADMIN_KEY_HASH. `wrangler.example.json` shows the binding; production/preview environments each need correct binding if used.
5. `01-PAGES-UPLOAD.zip` existing Pages Production par upload karo. `/deployment-check.html`: version2.0.0/schema7 and lifecycle PASS. A missing lifecycle binding returns503 on new-order creation.
6. Compatible signed Relay1.5 unchanged. No Android install is needed for an existing paired Relay1.5.

## Test flow

Base₹550 gets random₹550.01–₹551.99. Same payable amount cannot be allocated while reserved. QR7minutes; unpaid EXPIRED immediately at deadline. Delete15minutes after expiry (creation+22min). PAID deletion uses payment time+15min. Amount releases only after deletion. After deletion, GET returns404 and retries with old order keys can create a new record, so the shop must keep its own fulfilment/order state.

Cloudflare alarms can be delayed/retried, so exact-millisecond physical deletion cannot be promised. Deadline/status checks have no added grace. No live deployment is performed by preparing this package.

Only the inner01-PAGES-UPLOAD.zip goes to Pages. Read03-WEBSITE-INTEGRATION.md. Keep secrets/private config out of source archives.

## Error: no such column late_at

Main02-DATABASE-UPDATE.sql schema6 se7 ke liye hai. Schema5 ke liye extras/upgrade-from-schema5.sql use karo; schema3/4 ke liye extras/upgrade-from-schema3-or4.sql. Pehle diagnostics.sql chala kar actual columns aur version dekho. Sirf schema_version setting badalna ya ek late_at column add karna complete repair nahi hai.

Corrected scripts allow recovery when the failed2.0 migration left an EMPTY payments_v20 table and removed triggers, while original payments still exists. Schema5 with BOTH late columns absent can use the corrected schema5 upgrade. A populated staging table, only one late column, or missing original payments needs inspection before any further SQL. Do not drop populated tables. Back up D1; successful migration activates the requested permanent-deletion lifecycle. The new prerequisite check stops before dropping triggers when the wrong upgrade is selected.
